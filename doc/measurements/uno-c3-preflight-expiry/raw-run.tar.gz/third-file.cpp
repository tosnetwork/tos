// Temporary lifecycle-control source; never linked into production.
struct ExpiryControlledEngine {
  unsigned long proof_work() const { return 1; }
};
