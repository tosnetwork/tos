from pathlib import Path
import subprocess,json,hashlib,re,resource,datetime
repo=Path('/home/tomi/tos-m2'); copy=Path('/tmp/uno-x2-merged-source'); build=Path('/tmp/uno-x2-merged-build'); out=Path('/tmp/uno-x2-merged-audit/corrected');out.mkdir(exist_ok=False)
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
tree=(out.parent/'tree.txt').read_text().strip();assert tree=='63aacc17989a9ff1fad17c2bcb05e0d5d8c14eb8'
path='crypto/block/workchain-resource-policy.h'
original=subprocess.check_output(['git','show',tree+':'+path],cwd=repo)
assert copy.resolve()!=repo.resolve() and (copy/path).read_bytes()==original
sha=lambda x:hashlib.sha256(x).hexdigest()
command=[str(build/'test-workchain-block'),'--filter','EngineConfigurationAcceptedCadence','--verbosity','0']
rebuild=['cmake','--build',str(build),'--target','test-workchain-block','tos_block','smc-envelope','-j32']
r={'parents':['33af64ee8775e89035c5c364615ff6e3ada853a8','203354611ba872d84687a1787bfdebf2cab5c730'],'merged_tree':tree,'integration_merge_commit_created':False,'source_path':path,'source_blob_oid':subprocess.check_output(['git','rev-parse',tree+':'+path],cwd=repo,text=True).strip(),'original_sha256':sha(original),'command':command,'explicit_rebuild_command':rebuild,'executables_run':['test-workchain-block (registered test runner executes EngineConfigurationAcceptedCadence in-process)'],'scope':'D51 recorded cadence only, on the previously independently checked merged tree. No authenticity of historical K records, current-rate installation comparison or new integration merge claim.','controls':[]}
criteria=Path('/home/tomi/memo/UNO_M1_ACCEPTANCE_CRITERIA_20260910.md').read_bytes();r['criteria_sha256']=sha(criteria);r['criteria_commit']='29484352'
index=0
def run(label,cmd):
 global index
 index+=1
 p=subprocess.run(cmd,capture_output=True)
 for st in ['stdout','stderr']:(out/f'{index:02d}-{label}.{st}.log').write_bytes(getattr(p,st))
 return p

def checkpass(label):
 p=run(label,command);assert p.returncode==0,(label,p.returncode)
 text=(p.stdout+p.stderr).decode(errors='replace')
 assert 'Test_WorkchainBlock_EngineConfigurationAcceptedCadence' in text and 'Running test' in text
 return p
checkpass('baseline')
r['baseline_binary_sha256']=sha((build/'test-workchain-block').read_bytes())
s=original.decode()
controls=[
 ('omit-wire-field','  if (!tlb::pack_cell(result, record)) return td::Status::Error("cannot encode engine configuration");','  result = vm::CellBuilder().store_long(gen::UnoV2EngineConfiguration::cons_tag[0], 32).store_bits(record.instance_id.bits(), 256).store_ref(record.resource_policy).store_ref(record.parameters).finalize();',402,'cs.size() == 320 && cs.size_refs() == 2 ? 0 : 402','Only the 32-bit accepted-cadence wire field is omitted. Current generated tag, mandatory instance_id and both references remain: 288 bits rather than 320.'),
 ('discard-decoded-value','return WorkchainEngineParameters{record.k_accepted_target_rate_ms, record.instance_id, std::move(resources), std::move(record.parameters)};','return WorkchainEngineParameters{0, record.instance_id, std::move(resources), std::move(record.parameters)};',405,'decoded.ok().k_accepted_target_rate_ms == accepted ? 0 : 405','Decoder discards the accepted value and returns zero. Encoding/shape/tag/decoding-success checks precede 405 unchanged; first nonzero accepted input is 1.')]
for name,old,new,identity,expr,reason in controls:
 assert s.count(old)==1
 mutant=s.replace(old,new).encode()
 record={'name':name,'from':old,'to':new,'copy_before_sha256':sha((copy/path).read_bytes()),'mutant_sha256':sha(mutant),'expected_failure_identity':identity,'expected_assertion':expr,'reason':reason}
 try:
  (copy/path).write_bytes(mutant)
  p=run(name+'-build',rebuild);record['build_exit']=p.returncode;assert p.returncode==0
  record['mutant_binary_sha256']=sha((build/'test-workchain-block').read_bytes())
  p=run(name+'-run',command);record['run_exit']=p.returncode
  text=(p.stdout+p.stderr).decode(errors='replace')
  clean=re.sub(r'\x1b\[[0-9;]*m','',text)
  failures=[line for line in clean.splitlines() if line.startswith('[ 0]') and '[test-workchain-block.cpp:' in line and 'Expectation failed:' in line]
  assert p.returncode!=0 and len(failures)==1 and expr in failures[0] and f'({identity} != 0)' in failures[0],(name,p.returncode,failures)
  assert text.count('Running test Test_WorkchainBlock_EngineConfigurationAcceptedCadence...')==1
  record['actual_failure_assertion']=re.sub(r'\x1b\[[0-9;]*m','',failures[0])
 finally:(copy/path).write_bytes(original)
 p=run(name+'-restore-build',rebuild);record['restore_build_exit']=p.returncode;assert p.returncode==0
 checkpass(name+'-restored')
 record['restored_sha256']=sha((copy/path).read_bytes());record['restore_audit_sha256']=sha((copy/path).read_bytes().replace(old.encode(),new.encode()));record['restored_binary_sha256']=sha((build/'test-workchain-block').read_bytes())
 r['controls'].append(record);(out/'controls.json').write_text(json.dumps(r,indent=2)+'\n')
assert (copy/path).read_bytes()==original
subprocess.run(['git','diff','--exit-code'],cwd=copy,check=True,stdout=subprocess.DEVNULL)
r['restored_merged_worktree_matches_index']=True;r['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/'controls.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS: merged-tree 402 omitted cadence only; 405 discarded decoded value; both restored and explicitly rebuilt')
