import collections,gzip,hashlib,json,pathlib,re,subprocess
repo=pathlib.Path('/home/tomi/tos-m2');copy=pathlib.Path('/tmp/uno-genesis-domain-control');out=repo/'doc/measurements/uno-genesis-domain-paths';out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',str(repo),*a])
commit=git('rev-parse','HEAD').decode().strip();script='scripts/check-no-removed-execution-domains.sh';target='crypto/smartcont/uno-genesis-config.fif';other='crypto/smartcont/uno-genesis-operators.fif'
original=git('show',commit+':'+target);assert (repo/target).read_bytes()==(copy/target).read_bytes()==original
assert (repo/script).read_bytes()==(copy/script).read_bytes()==git('show',commit+':'+script)
def run(name,scanner,root):
 r=subprocess.run(['bash',str(scanner),str(root)],capture_output=True)
 for stream,data in [('stdout',r.stdout),('stderr',r.stderr)]: (out/(name+'.'+stream+'.log.gz')).write_bytes(gzip.compress(data,mtime=0))
 return r
old=pathlib.Path('/tmp/uno-genesis-domain-before.sh');old.write_bytes(git('show',commit+'^:'+script))
before=run('before-permission',old,repo);baseline=run('baseline',repo/script,repo)
assert before.returncode==baseline.returncode==1
lines=lambda r:collections.Counter(r.stderr.decode().splitlines())
removed=lines(before)-lines(baseline);assert removed and all(l.startswith((target+':',other+':')) for l in removed)
assert not (lines(baseline)-lines(before))
assert not any(l.startswith((target+':',other+':')) for l in lines(baseline))
oldtext='// Development-only resource bounds; M6 must re-accept measured limits.'
# Append a single comment without changing existing line numbers or syntax.
from_bytes=b'';to_bytes=b'\n// halo2\n';mutant=original+to_bytes
(copy/target).write_bytes(mutant);red=run('retired-control',copy/script,copy);assert red.returncode==1
added=lines(red)-lines(baseline);assert sum(added.values())==1,added
expected=f'{target}:{len(original.splitlines())+2}: retired implementation symbol: halo2: // halo2'
assert added==collections.Counter([expected]),added
assert not (lines(baseline)-lines(red))
(copy/target).write_bytes(original);restored=run('restored',copy/script,copy)
assert restored.returncode==baseline.returncode and restored.stdout==baseline.stdout and restored.stderr==baseline.stderr
assert (repo/target).read_bytes()==original and (copy/target).read_bytes()==original
classification=[];cache={}
for l in baseline.stderr.decode().splitlines():
 m=re.match(r'^([^:]+):(\d+):',l)
 if not m:continue
 p,n=m[1],int(m[2]);text=(repo/p).read_text().splitlines()[n-1]
 if p not in cache:
  r=subprocess.run(['git','-C',str(repo),'show','a27ff2c77:'+p],capture_output=True);cache[p]=r.stdout.decode(errors='replace').splitlines() if r.returncode==0 else []
 classification.append({'path':p,'line':n,'text':text,'present_verbatim_at_a27ff2c77':text in cache[p]})
r={'commit':commit,'scanner_sha256':sha((repo/script).read_bytes()),'approved_exact_paths':[target,other],'before_exit':before.returncode,'baseline_exit':baseline.returncode,'removed_diagnostics':list(removed.elements()),'control':{'path':target,'source_commit':commit,'original_sha256':sha(original),'copy_before_sha256':sha(original),'mutation':'append at byte offset','offset':len(original),'from':'','to':to_bytes.decode(),'mutant_sha256':sha(mutant),'restored_sha256':sha((copy/target).read_bytes()),'restore_audit_sha256':sha((copy/target).read_bytes()+to_bytes),'exit':red.returncode,'only_added_diagnostic':expected},'restored_exit':restored.returncode,'restored_streams_byte_equal':True,'remaining_diagnostics':classification,'remaining_counts':{'total':len(classification),'verbatim_at_a27ff2c77':sum(x['present_verbatim_at_a27ff2c77'] for x in classification),'new_or_rewritten_since_a27ff2c77':sum(not x['present_verbatim_at_a27ff2c77'] for x in classification)},'scope':'Global scan remains red on other unapproved paths. Control is attributable by exactly one added diagnostic at the injected line, while all other diagnostics remain identical. This is a text scanner, not a native compiled target; no native rebuild required. Full streams preserved; no source-tree mutations.'}
(out/'report.json.gz').write_bytes(gzip.compress((json.dumps(r,indent=2)+'\n').encode(),mtime=0));(out/'reproduce.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'remaining_counts':r['remaining_counts'],'removed_diagnostics':sum(removed.values()),'only_added_diagnostic':expected},indent=2))
