import hashlib,json,shlex,shutil,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent
B=Path('/tmp/uno-merged-default-build')
S=Path('/tmp/uno-a2-registry-jqOjoDbi/source')
OLD='/tmp/uno-merged-default-source'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd,name,cwd=R):
    (R/(name+'.argv.json')).write_text(json.dumps(cmd,indent=2))
    with (R/(name+'.log')).open('wb') as f:
        r=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
    print(name,r.returncode,flush=True)
    assert r.returncode==0,name
link=shlex.split((B/'CMakeFiles/test-tos-collator.dir/link.txt').read_text())
for arg in link:
    if arg.endswith(('.a','.o')):
        src=Path(arg) if arg.startswith('/') else B/arg
        dst=R/'build'/arg
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(src,dst)
frozen={str(p.relative_to(R)):sha(p) for p in (R/'build').rglob('*') if p.is_file()}
(R/'link-input-hashes.json').write_text(json.dumps(frozen,indent=2))
baseline=link.copy();baseline[baseline.index('-o')+1]=str(R/'baseline-test-tos-collator')
run(baseline,'baseline-link',R/'build')
assert sha(R/'baseline-test-tos-collator')=='61d28c73cf8f6d6f6ee5a2f892513a36f517b4396461e650a2b60d5a155758d4','baseline link drift'
# Generated include artifacts are frozen separately from the tracked tree.
gen=R/'generated';gen.mkdir(exist_ok=True)
shutil.copyfile(Path(OLD)/'crypto/block/block-auto.h',gen/'block-auto.h')
shutil.copytree(Path(OLD)/'tl/generate/auto',gen/'auto',dirs_exist_ok=True)
commands=json.loads((B/'compile_commands.json').read_text())
entry=next(x for x in commands if x['file'].endswith('/validator/manager-disk.cpp'))
cmd=shlex.split(entry['command'])
for arg in cmd:
    path=arg[2:] if arg.startswith('-I') else arg
    if path.startswith(str(B)) and Path(path).is_dir():
        src=Path(path);dst=R/'build'/src.relative_to(B)
        for p in src.rglob('*.h'):
            if 'CMakeFiles' in p.parts:continue
            q=dst/p.relative_to(src);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
shutil.copyfile('/home/tomi/tos/validator/manager-disk.cpp',R/'manager-disk.cpp')
cmd=[a.replace(OLD,str(S)).replace(str(B),str(R/'build')) for a in cmd]
cmd[cmd.index('-o')+1]=str(R/'manager-disk.cpp.o')
cmd[cmd.index('-c')+1]=str(R/'manager-disk.cpp')
cmd[1:1]=['-I'+str(gen),'-MMD','-MF',str(R/'manager.d')]
run(cmd,'compile-manager')
run(['/usr/bin/ar','r',str(R/'build/validator/libvalidator-disk.a'),str(R/'manager-disk.cpp.o')],'replace-manager')
run(['/usr/bin/ranlib',str(R/'build/validator/libvalidator-disk.a')],'index-manager')
newlink=link.copy();newlink[newlink.index('-o')+1]=str(R/'test-tos-collator')
run(newlink,'observed-link',R/'build')
(R/'binary-hashes.json').write_text(json.dumps({p.name:sha(p) for p in (R/'baseline-test-tos-collator',R/'test-tos-collator',R/'manager-disk.cpp')},indent=2))
