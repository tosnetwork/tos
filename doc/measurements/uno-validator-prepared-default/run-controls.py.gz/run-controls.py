from pathlib import Path
import subprocess,json,hashlib,re,xml.etree.ElementTree as ET
repo=Path('/home/tomi/tos-m2');copy=Path('/tmp/uno-prepared-default-source');build=Path('/tmp/uno-prepared-default-build');out=Path('/tmp/uno-prepared-default-audit');name='test-workchain-validator-prepared-expiry'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=copy,text=True).strip()
path='validator/impl/validate-query.cpp'; original=subprocess.check_output(['git','show',commit+':'+path],cwd=repo)
assert repo.resolve()!=copy.resolve() and original==(repo/path).read_bytes()==(copy/path).read_bytes()
reg=subprocess.check_output(['ctest','--test-dir',str(build),'--show-only=json-v1']);(out/'registration.json').write_bytes(reg)
tests=json.loads(reg)['tests'];selected=[t for t in tests if t['name']==name]
assert len(selected)==1 and not any(t['name']=='test-workchain-validator-local-visitors' for t in tests)
cache=(build/'CMakeCache.txt').read_text();assert 'CMAKE_PROJECT_TOS_INCLUDE:' not in cache
sha=lambda b:hashlib.sha256(b).hexdigest()
r={'source_commit':commit,'source_path':path,'source_blob_oid':subprocess.check_output(['git','rev-parse',commit+':'+path],cwd=repo,text=True).strip(),'original_sha256':sha(original),'default_registered_test':selected[0],'optional_native_test_absent':True,'optional_project_include_absent':True,'scope':'Default CMake-generated CTest registration, not a hand-written substitute. Pure source lifecycle guard. Actual executable chain: CTest -> Python3 -> read validator cpp; no native probe or fixture, no compiled mutant or runtime gate claim. No executable can retain the text mutation after restore.','controls':[]}

def run(label):
 xml=out/(label+'.xml')
 cmd=['ctest','--test-dir',str(build),'-R','^'+name+'$','--output-on-failure','--output-junit',str(xml)]
 p=subprocess.run(cmd,capture_output=True)
 for stream in ['stdout','stderr']:(out/(label+'.'+stream)).write_bytes(getattr(p,stream))
 rows=list(ET.parse(xml).getroot().iter('testcase'));assert len(rows)==1 and rows[0].get('name')==name and rows[0].find('skipped') is None
 text=rows[0].findtext('system-out','')
 ids=[json.loads(l)['failure_identity'] for l in text.splitlines() if l.startswith('{"failure_identity":')]
 return p.returncode,ids,rows[0].find('failure') is not None
assert run('baseline')==(0,[],False)
s=original.decode()
for visitor,identity,replacement in [('custom',1350,'return false;'),('ready',1351,'return td::Status::OK();')]:
 start=s.index('auto '+visitor+' = std::visit(td::overloaded(');arm=s.index('[](const block::ResolvedWorkchainAccountBinding&)',start);a=s.index('{',arm)+1;b=s.index('}',a)
 old=s[a:b];new='\n          '+replacement+'\n        ';assert 'WorkchainExecutionFailure::LocalUnavailable' in old
 mutant=(s[:a]+new+s[b:]).encode()
 try:
  (copy/path).write_bytes(mutant);result=run(visitor+'-connected');assert result==(8,[identity],True),result
 finally:(copy/path).write_bytes(original)
 assert run(visitor+'-restored')==(0,[],False)
 r['controls'].append({'name':visitor,'from':old,'to':new,'offset':a,'copy_before_sha256':sha(original),'mutant_sha256':sha(mutant),'restored_sha256':sha((copy/path).read_bytes()),'restore_audit_sha256':sha((copy/path).read_bytes()[:a]+new.encode()+(copy/path).read_bytes()[b:]),'ctest_exit':8,'failure_identity':identity,'restored_ctest_exit':0})
try:
 (copy/path).unlink();result=run('missing-source');assert result==(8,[1352],True),result
finally:(copy/path).write_bytes(original)
assert run('missing-source-restored')==(0,[],False)
r['dependency_control']={'action':'physically remove source file','failure_identity':1352,'ctest_exit':8,'restored_ctest_exit':0,'scope':'Dependency failure propagation, not a production decision guard'}
r['main_source_unchanged']=original==(repo/path).read_bytes();assert r['main_source_unchanged']
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS: real default registration; custom 1350, ready 1351, missing source 1352; all restored 0')
