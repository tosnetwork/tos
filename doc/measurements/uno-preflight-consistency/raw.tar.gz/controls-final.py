from pathlib import Path
import subprocess,shlex,json,hashlib
repo=Path('/home/tomi/tos-m2');build=Path('/tmp/uno-bounded-policy-private-build');out=Path(__file__).parent/'controls-final';out.mkdir(exist_ok=False);copy=out/'source';assert copy.resolve()!=repo.resolve()
header='crypto/block/workchain-resource-policy.h';test='crypto/test/test-workchain-block.cpp';dispatch='crypto/block/workchain-execution-dispatch.cpp'
original={f:(repo/f).read_bytes() for f in [header,test,dispatch,'crypto/block/workchain-input-admission.h']}
for f,data in original.items():p=copy/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands','test-workchain-block'],text=True).splitlines();(out/'ninja-commands.txt').write_text('\n'.join(commands))
objects={};compiles={}
for f in [test,dispatch]:
 matches=[x for x in commands if ' -c ' in x and x.endswith('/'+f)];assert len(matches)==1
 cmd=shlex.split(matches[0]);obj=out/(Path(f).stem+'.o');objects[f]=(cmd[cmd.index('-o')+1],obj)
 for flag,val in [('-o',str(obj)),('-MF',str(obj)+'.d'),('-MT',str(obj))]:cmd[cmd.index(flag)+1]=val
 cmd[cmd.index('-c')+1]=str(copy/f);pos=2 if Path(cmd[0]).name=='ccache' else 1;cmd[pos:pos]=['-I'+str(copy/'crypto'),'-I'+str(repo/'crypto/test')];compiles[f]=cmd
links=[x for x in commands if ' -o test-workchain-block ' in x];assert len(links)==1;link=shlex.split(links[0]);assert link[:2]==[':','&&'] and link[-2:]==['&&',':'];link=link[2:-2];binary=out/'test-workchain-block';link[link.index('-o')+1]=str(binary);link=[str(objects[test][1]) if x==objects[test][0] else x for x in link];link.insert(1,str(objects[dispatch][1]))
sha=lambda b:hashlib.sha256(b).hexdigest();report={'scope':'Config consistency and actual installation-call controls. No production execution gate opened. Both copied test and dispatch objects explicitly recompiled, then executable relinked after every restoration.','source_sha256':{f:sha(b) for f,b in original.items()},'controls':[],'commands':[]}
def run(label,cmd):
 r=subprocess.run(cmd,cwd=build,capture_output=True);(out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);report['commands'].append({'label':label,'argv':cmd,'exit':r.returncode});(out/'report.json').write_text(json.dumps(report,indent=2));return r
def rebuild(label):
 for f,cmd in compiles.items():assert run(label+'-'+Path(f).stem,cmd).returncode==0
 assert run(label+'-link',link).returncode==0
rebuild('baseline')
for flt in ['PreflightAllowanceConsistency','MultiAccountAdmissionVersionInstallation']:assert run('baseline-'+flt,[str(binary),'--filter',flt]).returncode==0
comparison='resources.preflight_allowance <= static_cast<std::uint64_t>(resources.block_preflight.hard_limit)'
mutants=[
 ('omit-zero',header,' &&\n         resources.preflight_allowance','', 'PreflightAllowanceConsistency','std::holds_alternative<block::ConfigInvalid>(zero)'),
 ('omit-budget',header,comparison,'true','PreflightAllowanceConsistency','std::holds_alternative<block::ConfigInvalid>(excessive)'),
 ('narrow',header,comparison,'static_cast<std::uint32_t>(resources.preflight_allowance) <= static_cast<std::uint64_t>(resources.block_preflight.hard_limit)','PreflightAllowanceConsistency','std::holds_alternative<block::ConfigInvalid>(excessive)'),
 ('reject-equality',header,comparison,'resources.preflight_allowance < static_cast<std::uint64_t>(resources.block_preflight.hard_limit)','PreflightAllowanceConsistency','std::holds_alternative<block::ResolvedBatchInputPolicy>(equal)'),
 ('wrong-code',header,'return ConfigInvalid{ConfigInvalidCode::PreflightAllowanceExceedsBlockBudget};','return ConfigInvalid{ConfigInvalidCode::ZeroLimit};','PreflightAllowanceConsistency','PreflightAllowanceExceedsBlockBudget'),
 ('remove-installation-call',dispatch,'      if (!workchain_batch_preflight_fits_block(parameters.resources)) {\n        return td::Status::Error("preflight allowance exceeds block budget in configuration");\n      }\n','', 'MultiAccountAdmissionVersionInstallation','installed.is_ok()')]
for name,f,before,after,flt,reason in mutants:
 s=original[f].decode();assert s.count(before)==1,(name,s.count(before));changed=s.replace(before,after).encode();(copy/f).write_bytes(changed);rebuild(name);r=run(name,[str(binary),'--filter',flt]);assert r.returncode!=0 and reason.encode() in r.stderr,(name,r.stderr[-1800:])
 (copy/f).write_bytes(original[f]);rebuild(name+'-restore')
 for check in ['PreflightAllowanceConsistency','MultiAccountAdmissionVersionInstallation']:assert run(name+'-restore-'+check,[str(binary),'--filter',check]).returncode==0
 assert all((repo/f).read_bytes()==b and (copy/f).read_bytes()==b for f,b in original.items())
 report['controls'].append({'name':name,'file':f,'mutation_sha256':sha(changed),'restored_sha256':sha(original[f]),'test':flt,'failure_reason':reason});(out/'report.json').write_text(json.dumps(report,indent=2));print(name,'caught/restored',flush=True)
