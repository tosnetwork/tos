#pragma once
#include <tl/tlblib.hpp>
/*
 *
 *  AUTO-GENERATED FROM `block.tlb`
 *
 */
// uses built-in type `#`
// uses built-in type `##`
// uses built-in type `#<`
// uses built-in type `#<=`
// uses built-in type `Any`
// uses built-in type `Cell`
// uses built-in type `int`
// uses built-in type `uint`
// uses built-in type `bits`
// uses built-in type `int8`
// uses built-in type `uint8`
// uses built-in type `uint13`
// uses built-in type `uint15`
// uses built-in type `int16`
// uses built-in type `uint16`
// uses built-in type `int32`
// uses built-in type `uint32`
// uses built-in type `uint48`
// uses built-in type `uint63`
// uses built-in type `int64`
// uses built-in type `uint64`
// uses built-in type `uint256`
// uses built-in type `int257`
// uses built-in type `bits256`
// uses built-in type `bits512`

namespace block {

namespace gen {
using namespace ::tlb;
using td::Ref;
using vm::CellSlice;
using vm::Cell;
using td::RefInt256;

//
// headers for type `Unit`
//

struct Unit final : TLB_Complex {
  enum { unit };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef Unit type_class;
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 0;
  }
  bool skip(vm::CellSlice& cs) const override {
    return true;
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return true;
  }
  bool fetch_enum_to(vm::CellSlice& cs, char& value) const;
  bool store_enum_from(vm::CellBuilder& cb, int value) const;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_unit(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_unit(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_unit(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_unit(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Unit";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const Unit t_Unit;

//
// headers for type `UnoV2SystemState`
//

struct UnoV2SystemState final : TLB_Complex {
  enum { uno_v2_system_state };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0xbbd85560U };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 192;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(192);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2SystemState";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2SystemState::Record {
  typedef UnoV2SystemState type_class;
  int layout_version;  	// layout_version : uint16
  unsigned long long base_compute;  	// base_compute : uint64
  unsigned long long registered_accounts;  	// registered_accounts : uint64
  int system_pending_count;  	// system_pending_count : uint16
};

extern const UnoV2SystemState t_UnoV2SystemState;

//
// headers for type `UnoV2CoordinatorState`
//

struct UnoV2CoordinatorState final : TLB_Complex {
  enum { uno_v2_coordinator_state };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x46ff26c1 };
  struct Record {
    typedef UnoV2CoordinatorState type_class;
    int layout_version;  	// layout_version : uint16
    Ref<Cell> system;  	// system : ^UnoV2SystemState
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 0x10030;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x10030);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_uno_v2_coordinator_state(vm::CellSlice& cs, int& layout_version, Ref<Cell>& system) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_uno_v2_coordinator_state(Ref<vm::Cell> cell_ref, int& layout_version, Ref<Cell>& system) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_uno_v2_coordinator_state(vm::CellBuilder& cb, int layout_version, Ref<Cell> system) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_uno_v2_coordinator_state(Ref<vm::Cell>& cell_ref, int layout_version, Ref<Cell> system) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2CoordinatorState";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const UnoV2CoordinatorState t_UnoV2CoordinatorState;

//
// headers for type `UnoV2ResourceInput`
//

struct UnoV2ResourceInput final : TLB_Complex {
  enum { uno_v2_resource_input };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0xc5defa2aU };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 320;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(320);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2ResourceInput";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2ResourceInput::Record {
  typedef UnoV2ResourceInput type_class;
  unsigned long long max_cells;  	// max_cells : uint64
  unsigned long long max_bits;  	// max_bits : uint64
  unsigned long long max_roots;  	// max_roots : uint64
  unsigned max_reads;  	// max_reads : uint32
  unsigned max_writes;  	// max_writes : uint32
  unsigned max_inbound;  	// max_inbound : uint32
};

extern const UnoV2ResourceInput t_UnoV2ResourceInput;

//
// headers for type `UnoV2ResourceState`
//

struct UnoV2ResourceState final : TLB_Complex {
  enum { uno_v2_resource_state };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x90aef2ddU };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 304;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(304);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2ResourceState";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2ResourceState::Record {
  typedef UnoV2ResourceState type_class;
  unsigned long long max_cells;  	// max_cells : uint64
  unsigned long long max_bits;  	// max_bits : uint64
  unsigned long long max_account_cells;  	// max_account_cells : uint64
  unsigned long long max_account_bits;  	// max_account_bits : uint64
  int max_account_depth;  	// max_account_depth : uint16
};

extern const UnoV2ResourceState t_UnoV2ResourceState;

//
// headers for type `UnoV2ResourceWorkOutput`
//

struct UnoV2ResourceWorkOutput final : TLB_Complex {
  enum { uno_v2_resource_work_output };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x7a310b92 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 384;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(384);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2ResourceWorkOutput";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2ResourceWorkOutput::Record {
  typedef UnoV2ResourceWorkOutput type_class;
  unsigned long long max_proof_units;  	// max_proof_units : uint64
  unsigned long long max_effect_cells;  	// max_effect_cells : uint64
  unsigned long long max_effect_bits;  	// max_effect_bits : uint64
  unsigned long long max_output_cells;  	// max_output_cells : uint64
  unsigned long long max_output_bits;  	// max_output_bits : uint64
  unsigned max_transfers;  	// max_transfers : uint32
};

extern const UnoV2ResourceWorkOutput t_UnoV2ResourceWorkOutput;

//
// headers for type `UnoV2ResourcePolicy`
//

struct UnoV2ResourcePolicy final : TLB_Complex {
  enum { uno_v2_resource_policy_bounded };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0xf37fed2fU };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 0x40080;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x40080);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2ResourcePolicy";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2ResourcePolicy::Record {
  typedef UnoV2ResourcePolicy type_class;
  unsigned admission_version;  	// admission_version : uint32
  unsigned long long preflight_allowance;  	// preflight_allowance : uint64
  Ref<Cell> input;  	// input : ^UnoV2ResourceInput
  Ref<Cell> state;  	// state : ^UnoV2ResourceState
  Ref<Cell> work_output;  	// work_output : ^UnoV2ResourceWorkOutput
  Ref<Cell> block_preflight;  	// block_preflight : ^ParamLimits
};

extern const UnoV2ResourcePolicy t_UnoV2ResourcePolicy;

//
// headers for type `UnoV2EngineConfiguration`
//

struct UnoV2EngineConfiguration final : TLB_Complex {
  enum { uno_v2_engine_configuration_issued };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x41868cd4 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 0x20140;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x20140);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2EngineConfiguration";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2EngineConfiguration::Record {
  typedef UnoV2EngineConfiguration type_class;
  unsigned k_accepted_target_rate_ms;  	// k_accepted_target_rate_ms : uint32
  td::BitArray<256> instance_id;  	// instance_id : bits256
  Ref<Cell> resource_policy;  	// resource_policy : ^UnoV2ResourcePolicy
  Ref<Cell> parameters;  	// parameters : ^Cell
};

extern const UnoV2EngineConfiguration t_UnoV2EngineConfiguration;

//
// headers for type `WorkchainInstanceRecord`
//

struct WorkchainInstanceRecord final : TLB_Complex {
  enum { workchain_instance_record };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x410ed06c };
  struct Record {
    typedef WorkchainInstanceRecord type_class;
    unsigned long long instance_seq;  	// instance_seq : uint64
    td::BitArray<256> creation_descriptor_hash;  	// creation_descriptor_hash : bits256
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 352;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(352);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_workchain_instance_record(vm::CellSlice& cs, unsigned long long& instance_seq, td::BitArray<256>& creation_descriptor_hash) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_workchain_instance_record(Ref<vm::Cell> cell_ref, unsigned long long& instance_seq, td::BitArray<256>& creation_descriptor_hash) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_workchain_instance_record(vm::CellBuilder& cb, unsigned long long instance_seq, td::BitArray<256> creation_descriptor_hash) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_workchain_instance_record(Ref<vm::Cell>& cell_ref, unsigned long long instance_seq, td::BitArray<256> creation_descriptor_hash) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainInstanceRecord";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const WorkchainInstanceRecord t_WorkchainInstanceRecord;

//
// headers for type `WorkchainInstanceLedger`
//

struct WorkchainInstanceLedger final : TLB_Complex {
  enum { workchain_instance_ledger };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x4a22c575 };
  struct Record {
    typedef WorkchainInstanceLedger type_class;
    Ref<CellSlice> entries;  	// entries : HashmapE 32 WorkchainInstanceRecord
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_workchain_instance_ledger(vm::CellSlice& cs, Ref<CellSlice>& entries) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_workchain_instance_ledger(Ref<vm::Cell> cell_ref, Ref<CellSlice>& entries) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_workchain_instance_ledger(vm::CellBuilder& cb, Ref<CellSlice> entries) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_workchain_instance_ledger(Ref<vm::Cell>& cell_ref, Ref<CellSlice> entries) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainInstanceLedger";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const WorkchainInstanceLedger t_WorkchainInstanceLedger;

//
// headers for type `WorkchainInstanceIdentity`
//

struct WorkchainInstanceIdentity final : TLB_Complex {
  enum { workchain_instance_identity_descriptor };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x39944312 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 416;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(416);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainInstanceIdentity";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct WorkchainInstanceIdentity::Record {
  typedef WorkchainInstanceIdentity type_class;
  int global_id;  	// global_id : int32
  int workchain_id;  	// workchain_id : int32
  td::BitArray<256> creation_descriptor_hash;  	// creation_descriptor_hash : bits256
  unsigned long long instance_seq;  	// instance_seq : uint64
};

extern const WorkchainInstanceIdentity t_WorkchainInstanceIdentity;

//
// headers for type `UnoV2HostDomain`
//

struct UnoV2HostDomain final : TLB_Complex {
  enum { uno_v2_host_domain };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x5ab37c9a };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 672;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(672);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2HostDomain";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2HostDomain::Record {
  typedef UnoV2HostDomain type_class;
  int global_id;  	// global_id : int32
  td::BitArray<256> genesis_hash;  	// genesis_hash : bits256
  td::BitArray<256> instance_id;  	// instance_id : bits256
  int workchain_id;  	// workchain_id : int32
  unsigned long long shard_id;  	// shard_id : uint64
};

extern const UnoV2HostDomain t_UnoV2HostDomain;

//
// headers for type `UnoV2HostPolicy`
//

struct UnoV2HostPolicy final : TLB_Complex {
  enum { uno_v2_host_policy };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0xf704b16cU };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 481;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(481);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2HostPolicy";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2HostPolicy::Record {
  typedef UnoV2HostPolicy type_class;
  td::BitArray<256> configuration_hash;  	// configuration_hash : bits256
  bool extended;  	// extended : Bool
  long long engine_selector;  	// engine_selector : int64
  unsigned long long vm_mode;  	// vm_mode : uint64
  unsigned descriptor_version;  	// descriptor_version : uint32
  unsigned admission_version;  	// admission_version : uint32
};

extern const UnoV2HostPolicy t_UnoV2HostPolicy;

//
// headers for type `UnoV2HostContext`
//

struct UnoV2HostContext final : TLB_Complex {
  enum { uno_v2_host_context };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x8a4ca5dcU };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 0x101a0;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x101a0);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2HostContext";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2HostContext::Record {
  typedef UnoV2HostContext type_class;
  td::BitArray<256> previous_shard_hash;  	// previous_shard_hash : bits256
  unsigned height;  	// height : uint32
  unsigned gen_utime;  	// gen_utime : uint32
  unsigned long long host_after_lt;  	// host_after_lt : uint64
  Ref<Cell> finality;  	// finality : ^Cell
};

extern const UnoV2HostContext t_UnoV2HostContext;

//
// headers for type `UnoV2HostIdentity`
//

struct UnoV2HostIdentity final : TLB_Complex {
  enum { uno_v2_host_identity };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x7d71caf4 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 0x30020;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x30020);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_uno_v2_host_identity(vm::CellSlice& cs, Ref<Cell>& domain, Ref<Cell>& policy, Ref<Cell>& context) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_uno_v2_host_identity(Ref<vm::Cell> cell_ref, Ref<Cell>& domain, Ref<Cell>& policy, Ref<Cell>& context) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_uno_v2_host_identity(vm::CellBuilder& cb, Ref<Cell> domain, Ref<Cell> policy, Ref<Cell> context) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_uno_v2_host_identity(Ref<vm::Cell>& cell_ref, Ref<Cell> domain, Ref<Cell> policy, Ref<Cell> context) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2HostIdentity";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2HostIdentity::Record {
  typedef UnoV2HostIdentity type_class;
  Ref<Cell> domain;  	// domain : ^UnoV2HostDomain
  Ref<Cell> policy;  	// policy : ^UnoV2HostPolicy
  Ref<Cell> context;  	// context : ^UnoV2HostContext
};

extern const UnoV2HostIdentity t_UnoV2HostIdentity;

//
// headers for type `UnoV2HostRead`
//

struct UnoV2HostRead final : TLB_Complex {
  enum { uno_v2_host_read };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x439e6964 };
  struct Record {
    typedef UnoV2HostRead type_class;
    Ref<CellSlice> old_account_hash;  	// old_account_hash : Maybe bits256
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_uno_v2_host_read(vm::CellSlice& cs, Ref<CellSlice>& old_account_hash) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_uno_v2_host_read(Ref<vm::Cell> cell_ref, Ref<CellSlice>& old_account_hash) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_uno_v2_host_read(vm::CellBuilder& cb, Ref<CellSlice> old_account_hash) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_uno_v2_host_read(Ref<vm::Cell>& cell_ref, Ref<CellSlice> old_account_hash) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2HostRead";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const UnoV2HostRead t_UnoV2HostRead;

//
// headers for type `UnoV2HostAccess`
//

struct UnoV2HostAccess final : TLB_Complex {
  enum { uno_v2_host_access };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x7bc07a6d };
  struct Record {
    typedef UnoV2HostAccess type_class;
    Ref<CellSlice> reads;  	// reads : HashmapE 256 ^UnoV2HostRead
    Ref<CellSlice> writes;  	// writes : HashmapE 256 True
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_uno_v2_host_access(vm::CellSlice& cs, Ref<CellSlice>& reads, Ref<CellSlice>& writes) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_uno_v2_host_access(Ref<vm::Cell> cell_ref, Ref<CellSlice>& reads, Ref<CellSlice>& writes) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_uno_v2_host_access(vm::CellBuilder& cb, Ref<CellSlice> reads, Ref<CellSlice> writes) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_uno_v2_host_access(Ref<vm::Cell>& cell_ref, Ref<CellSlice> reads, Ref<CellSlice> writes) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2HostAccess";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const UnoV2HostAccess t_UnoV2HostAccess;

//
// headers for type `UnoV2HostInput`
//

struct UnoV2HostInput final : TLB_Complex {
  enum { uno_v2_host_input };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x7c0766c8 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2HostInput";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2HostInput::Record {
  typedef UnoV2HostInput type_class;
  Ref<Cell> identity;  	// identity : ^UnoV2HostIdentity
  Ref<Cell> access;  	// access : ^UnoV2HostAccess
  Ref<Cell> candidate;  	// candidate : ^Cell
  Ref<CellSlice> inbox;  	// inbox : Maybe ^WorkchainBatchInbound
};

extern const UnoV2HostInput t_UnoV2HostInput;

//
// headers for type `UnoV2HostRecord`
//

struct UnoV2HostRecord final : TLB_Complex {
  enum { uno_v2_host_record };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x35739af6 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 832;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(832);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2HostRecord";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2HostRecord::Record {
  typedef UnoV2HostRecord type_class;
  td::BitArray<256> input_hash;  	// input_hash : bits256
  td::BitArray<256> effects_hash;  	// effects_hash : bits256
  td::BitArray<256> account_id;  	// account_id : bits256
  unsigned effect_index;  	// effect_index : uint32
};

extern const UnoV2HostRecord t_UnoV2HostRecord;

//
// headers for type `UnoV2NativeTransfer`
//

struct UnoV2NativeTransfer final : TLB_Complex {
  enum { uno_v2_native_transfer };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x6b953015 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_uno_v2_native_transfer(vm::CellSlice& cs, td::BitArray<256>& source, td::BitArray<256>& destination, Ref<CellSlice>& value) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_uno_v2_native_transfer(Ref<vm::Cell> cell_ref, td::BitArray<256>& source, td::BitArray<256>& destination, Ref<CellSlice>& value) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_uno_v2_native_transfer(vm::CellBuilder& cb, td::BitArray<256> source, td::BitArray<256> destination, Ref<CellSlice> value) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_uno_v2_native_transfer(Ref<vm::Cell>& cell_ref, td::BitArray<256> source, td::BitArray<256> destination, Ref<CellSlice> value) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2NativeTransfer";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2NativeTransfer::Record {
  typedef UnoV2NativeTransfer type_class;
  td::BitArray<256> source;  	// source : bits256
  td::BitArray<256> destination;  	// destination : bits256
  Ref<CellSlice> value;  	// value : CurrencyCollection
};

extern const UnoV2NativeTransfer t_UnoV2NativeTransfer;

//
// headers for type `UnoV2FeeSettlement`
//

struct UnoV2FeeSettlement final : TLB_Complex {
  enum { uno_v2_fee_settlement };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0xb02c852dU };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2FeeSettlement";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2FeeSettlement::Record {
  typedef UnoV2FeeSettlement type_class;
  td::BitArray<256> custody;  	// custody : bits256
  td::BitArray<256> coordinator;  	// coordinator : bits256
  Ref<CellSlice> state_fee;  	// state_fee : Tomis
  Ref<CellSlice> compute_fee;  	// compute_fee : Tomis
  Ref<CellSlice> tip;  	// tip : Tomis
};

extern const UnoV2FeeSettlement t_UnoV2FeeSettlement;

//
// headers for type `UnoV2NativeEffects`
//

struct UnoV2NativeEffects final : TLB_Complex {
  enum { uno_v2_native_effects, uno_v2_native_effects_fees };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[2] = { 0xbd47725, 0x67e2d380 };
  struct Record_uno_v2_native_effects {
    typedef UnoV2NativeEffects type_class;
    Ref<CellSlice> payout;  	// payout : Maybe ^Cell
    Ref<CellSlice> transfers;  	// transfers : HashmapE 32 ^UnoV2NativeTransfer
  };
  struct Record_uno_v2_native_effects_fees;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_uno_v2_native_effects& data) const;
  bool unpack_uno_v2_native_effects(vm::CellSlice& cs, Ref<CellSlice>& payout, Ref<CellSlice>& transfers) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_uno_v2_native_effects& data) const;
  bool cell_unpack_uno_v2_native_effects(Ref<vm::Cell> cell_ref, Ref<CellSlice>& payout, Ref<CellSlice>& transfers) const;
  bool pack(vm::CellBuilder& cb, const Record_uno_v2_native_effects& data) const;
  bool pack_uno_v2_native_effects(vm::CellBuilder& cb, Ref<CellSlice> payout, Ref<CellSlice> transfers) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_uno_v2_native_effects& data) const;
  bool cell_pack_uno_v2_native_effects(Ref<vm::Cell>& cell_ref, Ref<CellSlice> payout, Ref<CellSlice> transfers) const;
  bool unpack(vm::CellSlice& cs, Record_uno_v2_native_effects_fees& data) const;
  bool unpack_uno_v2_native_effects_fees(vm::CellSlice& cs, Ref<CellSlice>& payout, Ref<CellSlice>& transfers, Ref<Cell>& fees) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_uno_v2_native_effects_fees& data) const;
  bool cell_unpack_uno_v2_native_effects_fees(Ref<vm::Cell> cell_ref, Ref<CellSlice>& payout, Ref<CellSlice>& transfers, Ref<Cell>& fees) const;
  bool pack(vm::CellBuilder& cb, const Record_uno_v2_native_effects_fees& data) const;
  bool pack_uno_v2_native_effects_fees(vm::CellBuilder& cb, Ref<CellSlice> payout, Ref<CellSlice> transfers, Ref<Cell> fees) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_uno_v2_native_effects_fees& data) const;
  bool cell_pack_uno_v2_native_effects_fees(Ref<vm::Cell>& cell_ref, Ref<CellSlice> payout, Ref<CellSlice> transfers, Ref<Cell> fees) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2NativeEffects";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(2, 3);
  }
};

struct UnoV2NativeEffects::Record_uno_v2_native_effects_fees {
  typedef UnoV2NativeEffects type_class;
  Ref<CellSlice> payout;  	// payout : Maybe ^Cell
  Ref<CellSlice> transfers;  	// transfers : HashmapE 32 ^UnoV2NativeTransfer
  Ref<Cell> fees;  	// fees : ^UnoV2FeeSettlement
};

extern const UnoV2NativeEffects t_UnoV2NativeEffects;

//
// headers for type `UnoV2HostEffects`
//

struct UnoV2HostEffects final : TLB_Complex {
  enum { uno_v2_host_effects };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x4155a803 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "UnoV2HostEffects";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct UnoV2HostEffects::Record {
  typedef UnoV2HostEffects type_class;
  Ref<CellSlice> updates;  	// updates : HashmapE 256 ^Cell
  Ref<Cell> native;  	// native : ^UnoV2NativeEffects
  Ref<CellSlice> receipts;  	// receipts : Maybe ^Cell
  Ref<CellSlice> events;  	// events : Maybe ^Cell
  unsigned long long wire_bytes;  	// wire_bytes : uint64
  unsigned long long verification_units;  	// verification_units : uint64
  unsigned long long written_cells;  	// written_cells : uint64
};

extern const UnoV2HostEffects t_UnoV2HostEffects;

//
// headers for type `WorkchainNativeIngressTable`
//

struct WorkchainNativeIngressTable final : TLB_Complex {
  enum { workchain_native_ingress_table_v1 };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x57495431 };
  struct Record {
    typedef WorkchainNativeIngressTable type_class;
    Ref<CellSlice> policies;  	// policies : HashmapE 32 ^WorkchainNativeIngressPolicy
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_workchain_native_ingress_table_v1(vm::CellSlice& cs, Ref<CellSlice>& policies) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_workchain_native_ingress_table_v1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& policies) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_workchain_native_ingress_table_v1(vm::CellBuilder& cb, Ref<CellSlice> policies) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_workchain_native_ingress_table_v1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> policies) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainNativeIngressTable";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const WorkchainNativeIngressTable t_WorkchainNativeIngressTable;

//
// headers for type `WorkchainNativeIngressPolicy`
//

struct WorkchainNativeIngressPolicy final : TLB_Complex {
  enum { workchain_native_ingress_v2, workchain_native_ingress_v1 };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[2] = { 0x4abd5ab4, 0x57495031 };
  struct Record_workchain_native_ingress_v1;
  struct Record_workchain_native_ingress_v2;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_workchain_native_ingress_v1& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_workchain_native_ingress_v1& data) const;
  bool pack(vm::CellBuilder& cb, const Record_workchain_native_ingress_v1& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_workchain_native_ingress_v1& data) const;
  bool unpack(vm::CellSlice& cs, Record_workchain_native_ingress_v2& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_workchain_native_ingress_v2& data) const;
  bool pack(vm::CellBuilder& cb, const Record_workchain_native_ingress_v2& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_workchain_native_ingress_v2& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainNativeIngressPolicy";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(4, 0x30);
  }
};

struct WorkchainNativeIngressPolicy::Record_workchain_native_ingress_v1 {
  typedef WorkchainNativeIngressPolicy type_class;
  int workchain_id;  	// workchain_id : int32
  bool extended;  	// extended : Bool
  long long engine_selector;  	// engine_selector : int64
  unsigned long long vm_mode;  	// vm_mode : uint64
  unsigned descriptor_version;  	// descriptor_version : uint32
  td::BitArray<256> executor_address;  	// executor_address : bits256
  Ref<Cell> engine_configuration;  	// engine_configuration : ^Cell
};

struct WorkchainNativeIngressPolicy::Record_workchain_native_ingress_v2 {
  typedef WorkchainNativeIngressPolicy type_class;
  int workchain_id;  	// workchain_id : int32
  bool extended;  	// extended : Bool
  long long engine_selector;  	// engine_selector : int64
  unsigned long long vm_mode;  	// vm_mode : uint64
  unsigned descriptor_version;  	// descriptor_version : uint32
  td::BitArray<256> executor_address;  	// executor_address : bits256
  td::BitArray<256> custody_address;  	// custody_address : bits256
  Ref<Cell> engine_configuration;  	// engine_configuration : ^Cell
};

extern const WorkchainNativeIngressPolicy t_WorkchainNativeIngressPolicy;

//
// headers for type `WorkchainBatchInbound`
//

struct WorkchainBatchInbound final : TLB_Complex {
  enum { workchain_batch_inbound_v1 };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x57494e31 };
  struct Record {
    typedef WorkchainBatchInbound type_class;
    int count;  	// count : uint15
    Ref<CellSlice> envelopes;  	// envelopes : HashmapE 256 ^MsgEnvelope
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_workchain_batch_inbound_v1(vm::CellSlice& cs, int& count, Ref<CellSlice>& envelopes) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_workchain_batch_inbound_v1(Ref<vm::Cell> cell_ref, int& count, Ref<CellSlice>& envelopes) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_workchain_batch_inbound_v1(vm::CellBuilder& cb, int count, Ref<CellSlice> envelopes) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_workchain_batch_inbound_v1(Ref<vm::Cell>& cell_ref, int count, Ref<CellSlice> envelopes) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainBatchInbound";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const WorkchainBatchInbound t_WorkchainBatchInbound;

//
// headers for type `WorkchainBlockContext`
//

struct WorkchainBlockContext final : TLB_Complex {
  enum { workchain_block_context_v2 };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x57424332 };
  struct Record {
    typedef WorkchainBlockContext type_class;
    Ref<Cell> configuration;  	// configuration : ^Cell
    Ref<Cell> finality_context;  	// finality_context : ^Cell
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 0x20020;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x20020);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_workchain_block_context_v2(vm::CellSlice& cs, Ref<Cell>& configuration, Ref<Cell>& finality_context) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_workchain_block_context_v2(Ref<vm::Cell> cell_ref, Ref<Cell>& configuration, Ref<Cell>& finality_context) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_workchain_block_context_v2(vm::CellBuilder& cb, Ref<Cell> configuration, Ref<Cell> finality_context) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_workchain_block_context_v2(Ref<vm::Cell>& cell_ref, Ref<Cell> configuration, Ref<Cell> finality_context) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainBlockContext";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const WorkchainBlockContext t_WorkchainBlockContext;

//
// headers for type `WorkchainBlockOutputs`
//

struct WorkchainBlockOutputs final : TLB_Complex {
  enum { workchain_block_outputs_v1 };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x57424f31 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 0x40020;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x40020);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainBlockOutputs";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct WorkchainBlockOutputs::Record {
  typedef WorkchainBlockOutputs type_class;
  Ref<Cell> outbound_messages;  	// outbound_messages : ^Cell
  Ref<Cell> actions;  	// actions : ^Cell
  Ref<Cell> receipts;  	// receipts : ^Cell
  Ref<Cell> events;  	// events : ^Cell
};

extern const WorkchainBlockOutputs t_WorkchainBlockOutputs;

//
// headers for type `WorkchainBlockInput`
//

struct WorkchainBlockInput final : TLB_Complex {
  enum { workchain_block_input_v1, workchain_block_input_v2 };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[2] = { 0x57424931, 0x57424932 };
  struct Record_workchain_block_input_v2;
  struct Record_workchain_block_input_v1;
  int get_size(const vm::CellSlice& cs) const override {
    return 0x40020;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x40020);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_workchain_block_input_v2& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_workchain_block_input_v2& data) const;
  bool pack(vm::CellBuilder& cb, const Record_workchain_block_input_v2& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_workchain_block_input_v2& data) const;
  bool unpack(vm::CellSlice& cs, Record_workchain_block_input_v1& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_workchain_block_input_v1& data) const;
  bool pack(vm::CellBuilder& cb, const Record_workchain_block_input_v1& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_workchain_block_input_v1& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainBlockInput";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct WorkchainBlockInput::Record_workchain_block_input_v2 {
  typedef WorkchainBlockInput type_class;
  Ref<Cell> previous_shard_state;  	// previous_shard_state : ^Cell
  Ref<Cell> candidate;  	// candidate : ^Cell
  Ref<Cell> context;  	// context : ^WorkchainBlockContext
  Ref<Cell> inbound_messages;  	// inbound_messages : ^WorkchainBatchInbound
};

struct WorkchainBlockInput::Record_workchain_block_input_v1 {
  typedef WorkchainBlockInput type_class;
  Ref<Cell> previous_shard_state;  	// previous_shard_state : ^Cell
  Ref<Cell> candidate;  	// candidate : ^Cell
  Ref<Cell> configuration;  	// configuration : ^Cell
  Ref<Cell> finality_context;  	// finality_context : ^Cell
};

extern const WorkchainBlockInput t_WorkchainBlockInput;

//
// headers for type `WorkchainBlockResult`
//

struct WorkchainBlockResult final : TLB_Complex {
  enum { workchain_block_result_v2 };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x57425232 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 0x300e0;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x300e0);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainBlockResult";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct WorkchainBlockResult::Record {
  typedef WorkchainBlockResult type_class;
  unsigned long long wire_bytes;  	// wire_bytes : uint64
  unsigned long long verification_units;  	// verification_units : uint64
  unsigned long long written_cells;  	// written_cells : uint64
  Ref<Cell> new_engine_state;  	// new_engine_state : ^Cell
  Ref<Cell> outputs;  	// outputs : ^WorkchainBlockOutputs
  Ref<Cell> data_availability;  	// data_availability : ^Cell
};

extern const WorkchainBlockResult t_WorkchainBlockResult;

//
// headers for type `WorkchainBatchWitness`
//

struct WorkchainBatchWitness final : TLB_Complex {
  enum { workchain_batch_witness_v1 };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x57425731 };
  struct Record {
    typedef WorkchainBatchWitness type_class;
    Ref<Cell> candidate;  	// candidate : ^Cell
    Ref<Cell> effects;  	// effects : ^WorkchainBlockResult
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 0x20020;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x20020);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_workchain_batch_witness_v1(vm::CellSlice& cs, Ref<Cell>& candidate, Ref<Cell>& effects) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_workchain_batch_witness_v1(Ref<vm::Cell> cell_ref, Ref<Cell>& candidate, Ref<Cell>& effects) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_workchain_batch_witness_v1(vm::CellBuilder& cb, Ref<Cell> candidate, Ref<Cell> effects) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_workchain_batch_witness_v1(Ref<vm::Cell>& cell_ref, Ref<Cell> candidate, Ref<Cell> effects) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainBatchWitness";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const WorkchainBatchWitness t_WorkchainBatchWitness;

//
// headers for type `WorkchainExecutorState`
//

struct WorkchainExecutorState final : TLB_Complex {
  enum { workchain_executor_state_v1 };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x57424531 };
  struct Record {
    typedef WorkchainExecutorState type_class;
    Ref<Cell> engine_state;  	// engine_state : ^Cell
    Ref<CellSlice> latest_batch;  	// latest_batch : Maybe ^WorkchainBatchWitness
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_workchain_executor_state_v1(vm::CellSlice& cs, Ref<Cell>& engine_state, Ref<CellSlice>& latest_batch) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_workchain_executor_state_v1(Ref<vm::Cell> cell_ref, Ref<Cell>& engine_state, Ref<CellSlice>& latest_batch) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_workchain_executor_state_v1(vm::CellBuilder& cb, Ref<Cell> engine_state, Ref<CellSlice> latest_batch) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_workchain_executor_state_v1(Ref<vm::Cell>& cell_ref, Ref<Cell> engine_state, Ref<CellSlice> latest_batch) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainExecutorState";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const WorkchainExecutorState t_WorkchainExecutorState;

//
// headers for type `True`
//

struct True final : TLB_Complex {
  enum { true1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef True type_class;
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 0;
  }
  bool skip(vm::CellSlice& cs) const override {
    return true;
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return true;
  }
  bool fetch_enum_to(vm::CellSlice& cs, char& value) const;
  bool store_enum_from(vm::CellBuilder& cb, int value) const;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_true1(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_true1(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_true1(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_true1(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "True";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const True t_True;

//
// headers for type `Bool`
//

struct Bool final : TLB_Complex {
  enum { bool_false, bool_true };
  static constexpr int cons_len_exact = 1;
  struct Record_bool_false {
    typedef Bool type_class;
  };
  struct Record_bool_true {
    typedef Bool type_class;
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 1;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(1);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(1);
  }
  bool fetch_enum_to(vm::CellSlice& cs, char& value) const;
  bool store_enum_from(vm::CellBuilder& cb, int value) const;
  bool unpack(vm::CellSlice& cs, Record_bool_false& data) const;
  bool unpack_bool_false(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_bool_false& data) const;
  bool cell_unpack_bool_false(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_bool_false& data) const;
  bool pack_bool_false(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_bool_false& data) const;
  bool cell_pack_bool_false(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_bool_true& data) const;
  bool unpack_bool_true(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_bool_true& data) const;
  bool cell_unpack_bool_true(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_bool_true& data) const;
  bool pack_bool_true(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_bool_true& data) const;
  bool cell_pack_bool_true(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Bool";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

extern const Bool t_Bool;

//
// headers for type `BoolFalse`
//

struct BoolFalse final : TLB_Complex {
  enum { bool_false };
  static constexpr int cons_len_exact = 1;
  struct Record {
    typedef BoolFalse type_class;
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 1;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(1);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool fetch_enum_to(vm::CellSlice& cs, char& value) const;
  bool store_enum_from(vm::CellBuilder& cb, int value) const;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_bool_false(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_bool_false(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_bool_false(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_bool_false(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BoolFalse";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const BoolFalse t_BoolFalse;

//
// headers for type `BoolTrue`
//

struct BoolTrue final : TLB_Complex {
  enum { bool_true };
  static constexpr int cons_len_exact = 1;
  static constexpr unsigned char cons_tag[1] = { 1 };
  struct Record {
    typedef BoolTrue type_class;
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 1;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(1);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool fetch_enum_to(vm::CellSlice& cs, char& value) const;
  bool store_enum_from(vm::CellBuilder& cb, int value) const;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_bool_true(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_bool_true(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_bool_true(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_bool_true(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BoolTrue";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const BoolTrue t_BoolTrue;

//
// headers for type `Maybe`
//

struct Maybe final : TLB_Complex {
  enum { nothing, just };
  static constexpr int cons_len_exact = 1;
  const TLB &X_;
  Maybe(const TLB& X) : X_(X) {}
  struct Record_nothing {
    typedef Maybe type_class;
  };
  struct Record_just {
    typedef Maybe type_class;
    Ref<CellSlice> value;  	// value : X
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_nothing& data) const;
  bool unpack_nothing(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_nothing& data) const;
  bool cell_unpack_nothing(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_nothing& data) const;
  bool pack_nothing(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_nothing& data) const;
  bool cell_pack_nothing(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_just& data) const;
  bool unpack_just(vm::CellSlice& cs, Ref<CellSlice>& value) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_just& data) const;
  bool cell_unpack_just(Ref<vm::Cell> cell_ref, Ref<CellSlice>& value) const;
  bool pack(vm::CellBuilder& cb, const Record_just& data) const;
  bool pack_just(vm::CellBuilder& cb, Ref<CellSlice> value) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_just& data) const;
  bool cell_pack_just(Ref<vm::Cell>& cell_ref, Ref<CellSlice> value) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(Maybe " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

//
// headers for type `Either`
//

struct Either final : TLB_Complex {
  enum { left, right };
  static constexpr int cons_len_exact = 1;
  const TLB &X_, &Y_;
  Either(const TLB& X, const TLB& Y) : X_(X), Y_(Y) {}
  struct Record_left {
    typedef Either type_class;
    Ref<CellSlice> value;  	// value : X
  };
  struct Record_right {
    typedef Either type_class;
    Ref<CellSlice> value;  	// value : Y
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_left& data) const;
  bool unpack_left(vm::CellSlice& cs, Ref<CellSlice>& value) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_left& data) const;
  bool cell_unpack_left(Ref<vm::Cell> cell_ref, Ref<CellSlice>& value) const;
  bool pack(vm::CellBuilder& cb, const Record_left& data) const;
  bool pack_left(vm::CellBuilder& cb, Ref<CellSlice> value) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_left& data) const;
  bool cell_pack_left(Ref<vm::Cell>& cell_ref, Ref<CellSlice> value) const;
  bool unpack(vm::CellSlice& cs, Record_right& data) const;
  bool unpack_right(vm::CellSlice& cs, Ref<CellSlice>& value) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_right& data) const;
  bool cell_unpack_right(Ref<vm::Cell> cell_ref, Ref<CellSlice>& value) const;
  bool pack(vm::CellBuilder& cb, const Record_right& data) const;
  bool pack_right(vm::CellBuilder& cb, Ref<CellSlice> value) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_right& data) const;
  bool cell_pack_right(Ref<vm::Cell>& cell_ref, Ref<CellSlice> value) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(Either " << X_ << " " << Y_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

//
// headers for type `Both`
//

struct Both final : TLB_Complex {
  enum { pair };
  static constexpr int cons_len_exact = 0;
  const TLB &X_, &Y_;
  Both(const TLB& X, const TLB& Y) : X_(X), Y_(Y) {}
  struct Record {
    typedef Both type_class;
    Ref<CellSlice> first;  	// first : X
    Ref<CellSlice> second;  	// second : Y
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_pair(vm::CellSlice& cs, Ref<CellSlice>& first, Ref<CellSlice>& second) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_pair(Ref<vm::Cell> cell_ref, Ref<CellSlice>& first, Ref<CellSlice>& second) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_pair(vm::CellBuilder& cb, Ref<CellSlice> first, Ref<CellSlice> second) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_pair(Ref<vm::Cell>& cell_ref, Ref<CellSlice> first, Ref<CellSlice> second) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(Both " << X_ << " " << Y_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

//
// headers for type `Bit`
//

struct Bit final : TLB_Complex {
  enum { bit };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef Bit type_class;
    bool x;  	// ## 1
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 1;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(1);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(1);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_bit(vm::CellSlice& cs, bool& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_bit(Ref<vm::Cell> cell_ref, bool& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_bit(vm::CellBuilder& cb, bool x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_bit(Ref<vm::Cell>& cell_ref, bool x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Bit";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const Bit t_Bit;

//
// headers for type `Hashmap`
//

struct Hashmap final : TLB_Complex {
  enum { hm_edge };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  const TLB &X_;
  Hashmap(unsigned m, const TLB& X) : m_(m), X_(X) {}
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(Hashmap " << m_ << " " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct Hashmap::Record {
  typedef Hashmap type_class;
  unsigned n;  	// n : #
  unsigned l;  	// l : #
  unsigned m;  	// m : #
  Ref<CellSlice> label;  	// label : HmLabel ~l n
  Ref<CellSlice> node;  	// node : HashmapNode m X
};

//
// headers for type `HashmapNode`
//

struct HashmapNode final : TLB_Complex {
  enum { hmn_leaf, hmn_fork };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  const TLB &X_;
  HashmapNode(unsigned m, const TLB& X) : m_(m), X_(X) {}
  struct Record_hmn_leaf {
    typedef HashmapNode type_class;
    Ref<CellSlice> value;  	// value : X
  };
  struct Record_hmn_fork;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_hmn_leaf& data) const;
  bool unpack_hmn_leaf(vm::CellSlice& cs, Ref<CellSlice>& value) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_hmn_leaf& data) const;
  bool cell_unpack_hmn_leaf(Ref<vm::Cell> cell_ref, Ref<CellSlice>& value) const;
  bool pack(vm::CellBuilder& cb, const Record_hmn_leaf& data) const;
  bool pack_hmn_leaf(vm::CellBuilder& cb, Ref<CellSlice> value) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_hmn_leaf& data) const;
  bool cell_pack_hmn_leaf(Ref<vm::Cell>& cell_ref, Ref<CellSlice> value) const;
  bool unpack(vm::CellSlice& cs, Record_hmn_fork& data) const;
  bool unpack_hmn_fork(vm::CellSlice& cs, unsigned& n, Ref<Cell>& left, Ref<Cell>& right) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_hmn_fork& data) const;
  bool cell_unpack_hmn_fork(Ref<vm::Cell> cell_ref, unsigned& n, Ref<Cell>& left, Ref<Cell>& right) const;
  bool pack(vm::CellBuilder& cb, const Record_hmn_fork& data) const;
  bool pack_hmn_fork(vm::CellBuilder& cb, Ref<Cell> left, Ref<Cell> right) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_hmn_fork& data) const;
  bool cell_pack_hmn_fork(Ref<vm::Cell>& cell_ref, Ref<Cell> left, Ref<Cell> right) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(HashmapNode " << m_ << " " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct HashmapNode::Record_hmn_fork {
  typedef HashmapNode type_class;
  unsigned n;  	// n : #
  Ref<Cell> left;  	// left : ^(Hashmap n X)
  Ref<Cell> right;  	// right : ^(Hashmap n X)
};

//
// headers for type `HmLabel`
//

struct HmLabel final : TLB_Complex {
  enum { hml_short, hml_long, hml_same };
  static constexpr char cons_len[3] = { 1, 2, 2 };
  static constexpr unsigned char cons_tag[3] = { 0, 2, 3 };
  unsigned n_;
  HmLabel(unsigned n) : n_(n) {}
  struct Record_hml_short;
  struct Record_hml_long;
  struct Record_hml_same;
  bool skip(vm::CellSlice& cs) const override;
  bool skip(vm::CellSlice& cs, unsigned& m_) const;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool validate_skip(int *ops, vm::CellSlice& cs, bool weak, unsigned& m_) const;
  bool fetch_to(vm::CellSlice& cs, Ref<vm::CellSlice>& res, unsigned& m_) const;
  bool unpack(vm::CellSlice& cs, Record_hml_short& data, unsigned& m_) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_hml_short& data, unsigned& m_) const;
  bool pack(vm::CellBuilder& cb, const Record_hml_short& data, unsigned& m_) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_hml_short& data, unsigned& m_) const;
  bool unpack(vm::CellSlice& cs, Record_hml_long& data, unsigned& m_) const;
  bool unpack_hml_long(vm::CellSlice& cs, unsigned& m, unsigned& n, Ref<td::BitString>& s, unsigned& m_) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_hml_long& data, unsigned& m_) const;
  bool cell_unpack_hml_long(Ref<vm::Cell> cell_ref, unsigned& m, unsigned& n, Ref<td::BitString>& s, unsigned& m_) const;
  bool pack(vm::CellBuilder& cb, const Record_hml_long& data, unsigned& m_) const;
  bool pack_hml_long(vm::CellBuilder& cb, unsigned n, Ref<td::BitString> s, unsigned& m_) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_hml_long& data, unsigned& m_) const;
  bool cell_pack_hml_long(Ref<vm::Cell>& cell_ref, unsigned n, Ref<td::BitString> s, unsigned& m_) const;
  bool unpack(vm::CellSlice& cs, Record_hml_same& data, unsigned& m_) const;
  bool unpack_hml_same(vm::CellSlice& cs, unsigned& m, bool& v, unsigned& n, unsigned& m_) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_hml_same& data, unsigned& m_) const;
  bool cell_unpack_hml_same(Ref<vm::Cell> cell_ref, unsigned& m, bool& v, unsigned& n, unsigned& m_) const;
  bool pack(vm::CellBuilder& cb, const Record_hml_same& data, unsigned& m_) const;
  bool pack_hml_same(vm::CellBuilder& cb, bool v, unsigned n, unsigned& m_) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_hml_same& data, unsigned& m_) const;
  bool cell_pack_hml_same(Ref<vm::Cell>& cell_ref, bool v, unsigned n, unsigned& m_) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs, unsigned& m_) const;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(HmLabel ~m_ " << n_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(2, 13);
  }
};

struct HmLabel::Record_hml_short {
  typedef HmLabel type_class;
  unsigned m;  	// m : #
  unsigned n;  	// n : #
  Ref<CellSlice> len;  	// len : Unary ~n
  Ref<td::BitString> s;  	// s : n * Bit
};

struct HmLabel::Record_hml_long {
  typedef HmLabel type_class;
  unsigned m;  	// m : #
  unsigned n;  	// n : #<= m
  Ref<td::BitString> s;  	// s : n * Bit
};

struct HmLabel::Record_hml_same {
  typedef HmLabel type_class;
  unsigned m;  	// m : #
  bool v;  	// v : Bit
  unsigned n;  	// n : #<= m
};

//
// headers for type `Unary`
//

struct Unary final : TLB_Complex {
  enum { unary_zero, unary_succ };
  static constexpr int cons_len_exact = 1;
  struct Record_unary_zero {
    typedef Unary type_class;
  };
  struct Record_unary_succ {
    typedef Unary type_class;
    unsigned n;  	// n : #
    Ref<CellSlice> x;  	// x : Unary ~n
  };
  bool skip(vm::CellSlice& cs) const override;
  bool skip(vm::CellSlice& cs, unsigned& m_) const;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool validate_skip(int *ops, vm::CellSlice& cs, bool weak, unsigned& m_) const;
  bool fetch_to(vm::CellSlice& cs, Ref<vm::CellSlice>& res, unsigned& m_) const;
  bool unpack(vm::CellSlice& cs, Record_unary_zero& data, unsigned& m_) const;
  bool unpack_unary_zero(vm::CellSlice& cs, unsigned& m_) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_unary_zero& data, unsigned& m_) const;
  bool cell_unpack_unary_zero(Ref<vm::Cell> cell_ref, unsigned& m_) const;
  bool pack(vm::CellBuilder& cb, const Record_unary_zero& data, unsigned& m_) const;
  bool pack_unary_zero(vm::CellBuilder& cb, unsigned& m_) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_unary_zero& data, unsigned& m_) const;
  bool cell_pack_unary_zero(Ref<vm::Cell>& cell_ref, unsigned& m_) const;
  bool unpack(vm::CellSlice& cs, Record_unary_succ& data, unsigned& m_) const;
  bool unpack_unary_succ(vm::CellSlice& cs, unsigned& n, Ref<CellSlice>& x, unsigned& m_) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_unary_succ& data, unsigned& m_) const;
  bool cell_unpack_unary_succ(Ref<vm::Cell> cell_ref, unsigned& n, Ref<CellSlice>& x, unsigned& m_) const;
  bool pack(vm::CellBuilder& cb, const Record_unary_succ& data, unsigned& m_) const;
  bool pack_unary_succ(vm::CellBuilder& cb, Ref<CellSlice> x, unsigned& m_) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_unary_succ& data, unsigned& m_) const;
  bool cell_pack_unary_succ(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x, unsigned& m_) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs, unsigned& m_) const;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(Unary ~m_)";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

extern const Unary t_Unary;

//
// headers for type `HashmapE`
//

struct HashmapE final : TLB_Complex {
  enum { hme_empty, hme_root };
  static constexpr int cons_len_exact = 1;
  unsigned m_;
  const TLB &X_;
  HashmapE(unsigned m, const TLB& X) : m_(m), X_(X) {}
  struct Record_hme_empty {
    typedef HashmapE type_class;
  };
  struct Record_hme_root {
    typedef HashmapE type_class;
    unsigned n;  	// n : #
    Ref<Cell> root;  	// root : ^(Hashmap n X)
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_hme_empty& data) const;
  bool unpack_hme_empty(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_hme_empty& data) const;
  bool cell_unpack_hme_empty(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_hme_empty& data) const;
  bool pack_hme_empty(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_hme_empty& data) const;
  bool cell_pack_hme_empty(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_hme_root& data) const;
  bool unpack_hme_root(vm::CellSlice& cs, unsigned& n, Ref<Cell>& root) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_hme_root& data) const;
  bool cell_unpack_hme_root(Ref<vm::Cell> cell_ref, unsigned& n, Ref<Cell>& root) const;
  bool pack(vm::CellBuilder& cb, const Record_hme_root& data) const;
  bool pack_hme_root(vm::CellBuilder& cb, Ref<Cell> root) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_hme_root& data) const;
  bool cell_pack_hme_root(Ref<vm::Cell>& cell_ref, Ref<Cell> root) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(HashmapE " << m_ << " " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

//
// headers for type `BitstringSet`
//

struct BitstringSet final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  BitstringSet(unsigned m) : m_(m) {}
  struct Record {
    typedef BitstringSet type_class;
    unsigned n;  	// n : #
    Ref<CellSlice> x;  	// Hashmap n True
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, unsigned& n, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, unsigned& n, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(BitstringSet " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

//
// headers for type `HashmapAug`
//

struct HashmapAug final : TLB_Complex {
  enum { ahm_edge };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  const TLB &X_, &Y_;
  HashmapAug(unsigned m, const TLB& X, const TLB& Y) : m_(m), X_(X), Y_(Y) {}
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(HashmapAug " << m_ << " " << X_ << " " << Y_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct HashmapAug::Record {
  typedef HashmapAug type_class;
  unsigned n;  	// n : #
  unsigned l;  	// l : #
  unsigned m;  	// m : #
  Ref<CellSlice> label;  	// label : HmLabel ~l n
  Ref<CellSlice> node;  	// node : HashmapAugNode m X Y
};

//
// headers for type `HashmapAugNode`
//

struct HashmapAugNode final : TLB_Complex {
  enum { ahmn_leaf, ahmn_fork };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  const TLB &X_, &Y_;
  HashmapAugNode(unsigned m, const TLB& X, const TLB& Y) : m_(m), X_(X), Y_(Y) {}
  struct Record_ahmn_leaf {
    typedef HashmapAugNode type_class;
    Ref<CellSlice> extra;  	// extra : Y
    Ref<CellSlice> value;  	// value : X
  };
  struct Record_ahmn_fork;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_ahmn_leaf& data) const;
  bool unpack_ahmn_leaf(vm::CellSlice& cs, Ref<CellSlice>& extra, Ref<CellSlice>& value) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_ahmn_leaf& data) const;
  bool cell_unpack_ahmn_leaf(Ref<vm::Cell> cell_ref, Ref<CellSlice>& extra, Ref<CellSlice>& value) const;
  bool pack(vm::CellBuilder& cb, const Record_ahmn_leaf& data) const;
  bool pack_ahmn_leaf(vm::CellBuilder& cb, Ref<CellSlice> extra, Ref<CellSlice> value) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_ahmn_leaf& data) const;
  bool cell_pack_ahmn_leaf(Ref<vm::Cell>& cell_ref, Ref<CellSlice> extra, Ref<CellSlice> value) const;
  bool unpack(vm::CellSlice& cs, Record_ahmn_fork& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_ahmn_fork& data) const;
  bool pack(vm::CellBuilder& cb, const Record_ahmn_fork& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_ahmn_fork& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(HashmapAugNode " << m_ << " " << X_ << " " << Y_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct HashmapAugNode::Record_ahmn_fork {
  typedef HashmapAugNode type_class;
  unsigned n;  	// n : #
  Ref<Cell> left;  	// left : ^(HashmapAug n X Y)
  Ref<Cell> right;  	// right : ^(HashmapAug n X Y)
  Ref<CellSlice> extra;  	// extra : Y
};

//
// headers for type `HashmapAugE`
//

struct HashmapAugE final : TLB_Complex {
  enum { ahme_empty, ahme_root };
  static constexpr int cons_len_exact = 1;
  unsigned m_;
  const TLB &X_, &Y_;
  HashmapAugE(unsigned m, const TLB& X, const TLB& Y) : m_(m), X_(X), Y_(Y) {}
  struct Record_ahme_empty {
    typedef HashmapAugE type_class;
    Ref<CellSlice> extra;  	// extra : Y
  };
  struct Record_ahme_root;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_ahme_empty& data) const;
  bool unpack_ahme_empty(vm::CellSlice& cs, Ref<CellSlice>& extra) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_ahme_empty& data) const;
  bool cell_unpack_ahme_empty(Ref<vm::Cell> cell_ref, Ref<CellSlice>& extra) const;
  bool pack(vm::CellBuilder& cb, const Record_ahme_empty& data) const;
  bool pack_ahme_empty(vm::CellBuilder& cb, Ref<CellSlice> extra) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_ahme_empty& data) const;
  bool cell_pack_ahme_empty(Ref<vm::Cell>& cell_ref, Ref<CellSlice> extra) const;
  bool unpack(vm::CellSlice& cs, Record_ahme_root& data) const;
  bool unpack_ahme_root(vm::CellSlice& cs, unsigned& n, Ref<Cell>& root, Ref<CellSlice>& extra) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_ahme_root& data) const;
  bool cell_unpack_ahme_root(Ref<vm::Cell> cell_ref, unsigned& n, Ref<Cell>& root, Ref<CellSlice>& extra) const;
  bool pack(vm::CellBuilder& cb, const Record_ahme_root& data) const;
  bool pack_ahme_root(vm::CellBuilder& cb, Ref<Cell> root, Ref<CellSlice> extra) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_ahme_root& data) const;
  bool cell_pack_ahme_root(Ref<vm::Cell>& cell_ref, Ref<Cell> root, Ref<CellSlice> extra) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(HashmapAugE " << m_ << " " << X_ << " " << Y_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

struct HashmapAugE::Record_ahme_root {
  typedef HashmapAugE type_class;
  unsigned n;  	// n : #
  Ref<Cell> root;  	// root : ^(HashmapAug n X Y)
  Ref<CellSlice> extra;  	// extra : Y
};

//
// headers for type `VarHashmap`
//

struct VarHashmap final : TLB_Complex {
  enum { vhm_edge };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  const TLB &X_;
  VarHashmap(unsigned m, const TLB& X) : m_(m), X_(X) {}
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(VarHashmap " << m_ << " " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct VarHashmap::Record {
  typedef VarHashmap type_class;
  unsigned n;  	// n : #
  unsigned l;  	// l : #
  unsigned m;  	// m : #
  Ref<CellSlice> label;  	// label : HmLabel ~l n
  Ref<CellSlice> node;  	// node : VarHashmapNode m X
};

//
// headers for type `VarHashmapNode`
//

struct VarHashmapNode final : TLB_Complex {
  enum { vhmn_leaf, vhmn_fork, vhmn_cont };
  static constexpr char cons_len[3] = { 2, 2, 1 };
  static constexpr unsigned char cons_tag[3] = { 0, 1, 1 };
  unsigned m_;
  const TLB &X_;
  VarHashmapNode(unsigned m, const TLB& X) : m_(m), X_(X) {}
  struct Record_vhmn_leaf {
    typedef VarHashmapNode type_class;
    Ref<CellSlice> value;  	// value : X
  };
  struct Record_vhmn_fork;
  struct Record_vhmn_cont;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_vhmn_leaf& data) const;
  bool unpack_vhmn_leaf(vm::CellSlice& cs, Ref<CellSlice>& value) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vhmn_leaf& data) const;
  bool cell_unpack_vhmn_leaf(Ref<vm::Cell> cell_ref, Ref<CellSlice>& value) const;
  bool pack(vm::CellBuilder& cb, const Record_vhmn_leaf& data) const;
  bool pack_vhmn_leaf(vm::CellBuilder& cb, Ref<CellSlice> value) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vhmn_leaf& data) const;
  bool cell_pack_vhmn_leaf(Ref<vm::Cell>& cell_ref, Ref<CellSlice> value) const;
  bool unpack(vm::CellSlice& cs, Record_vhmn_fork& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vhmn_fork& data) const;
  bool pack(vm::CellBuilder& cb, const Record_vhmn_fork& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vhmn_fork& data) const;
  bool unpack(vm::CellSlice& cs, Record_vhmn_cont& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vhmn_cont& data) const;
  bool pack(vm::CellBuilder& cb, const Record_vhmn_cont& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vhmn_cont& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(VarHashmapNode " << m_ << " " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(2, 7);
  }
};

struct VarHashmapNode::Record_vhmn_fork {
  typedef VarHashmapNode type_class;
  unsigned n;  	// n : #
  Ref<Cell> left;  	// left : ^(VarHashmap n X)
  Ref<Cell> right;  	// right : ^(VarHashmap n X)
  Ref<CellSlice> value;  	// value : Maybe X
};

struct VarHashmapNode::Record_vhmn_cont {
  typedef VarHashmapNode type_class;
  unsigned n;  	// n : #
  bool branch;  	// branch : Bit
  Ref<Cell> child;  	// child : ^(VarHashmap n X)
  Ref<CellSlice> value;  	// value : X
};

//
// headers for type `VarHashmapE`
//

struct VarHashmapE final : TLB_Complex {
  enum { vhme_empty, vhme_root };
  static constexpr int cons_len_exact = 1;
  unsigned m_;
  const TLB &X_;
  VarHashmapE(unsigned m, const TLB& X) : m_(m), X_(X) {}
  struct Record_vhme_empty {
    typedef VarHashmapE type_class;
  };
  struct Record_vhme_root {
    typedef VarHashmapE type_class;
    unsigned n;  	// n : #
    Ref<Cell> root;  	// root : ^(VarHashmap n X)
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_vhme_empty& data) const;
  bool unpack_vhme_empty(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vhme_empty& data) const;
  bool cell_unpack_vhme_empty(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_vhme_empty& data) const;
  bool pack_vhme_empty(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vhme_empty& data) const;
  bool cell_pack_vhme_empty(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_vhme_root& data) const;
  bool unpack_vhme_root(vm::CellSlice& cs, unsigned& n, Ref<Cell>& root) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vhme_root& data) const;
  bool cell_unpack_vhme_root(Ref<vm::Cell> cell_ref, unsigned& n, Ref<Cell>& root) const;
  bool pack(vm::CellBuilder& cb, const Record_vhme_root& data) const;
  bool pack_vhme_root(vm::CellBuilder& cb, Ref<Cell> root) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vhme_root& data) const;
  bool cell_pack_vhme_root(Ref<vm::Cell>& cell_ref, Ref<Cell> root) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(VarHashmapE " << m_ << " " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

//
// headers for type `PfxHashmap`
//

struct PfxHashmap final : TLB_Complex {
  enum { phm_edge };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  const TLB &X_;
  PfxHashmap(unsigned m, const TLB& X) : m_(m), X_(X) {}
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(PfxHashmap " << m_ << " " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct PfxHashmap::Record {
  typedef PfxHashmap type_class;
  unsigned n;  	// n : #
  unsigned l;  	// l : #
  unsigned m;  	// m : #
  Ref<CellSlice> label;  	// label : HmLabel ~l n
  Ref<CellSlice> node;  	// node : PfxHashmapNode m X
};

//
// headers for type `PfxHashmapNode`
//

struct PfxHashmapNode final : TLB_Complex {
  enum { phmn_leaf, phmn_fork };
  static constexpr int cons_len_exact = 1;
  unsigned m_;
  const TLB &X_;
  PfxHashmapNode(unsigned m, const TLB& X) : m_(m), X_(X) {}
  struct Record_phmn_leaf {
    typedef PfxHashmapNode type_class;
    Ref<CellSlice> value;  	// value : X
  };
  struct Record_phmn_fork;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_phmn_leaf& data) const;
  bool unpack_phmn_leaf(vm::CellSlice& cs, Ref<CellSlice>& value) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_phmn_leaf& data) const;
  bool cell_unpack_phmn_leaf(Ref<vm::Cell> cell_ref, Ref<CellSlice>& value) const;
  bool pack(vm::CellBuilder& cb, const Record_phmn_leaf& data) const;
  bool pack_phmn_leaf(vm::CellBuilder& cb, Ref<CellSlice> value) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_phmn_leaf& data) const;
  bool cell_pack_phmn_leaf(Ref<vm::Cell>& cell_ref, Ref<CellSlice> value) const;
  bool unpack(vm::CellSlice& cs, Record_phmn_fork& data) const;
  bool unpack_phmn_fork(vm::CellSlice& cs, unsigned& n, Ref<Cell>& left, Ref<Cell>& right) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_phmn_fork& data) const;
  bool cell_unpack_phmn_fork(Ref<vm::Cell> cell_ref, unsigned& n, Ref<Cell>& left, Ref<Cell>& right) const;
  bool pack(vm::CellBuilder& cb, const Record_phmn_fork& data) const;
  bool pack_phmn_fork(vm::CellBuilder& cb, Ref<Cell> left, Ref<Cell> right) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_phmn_fork& data) const;
  bool cell_pack_phmn_fork(Ref<vm::Cell>& cell_ref, Ref<Cell> left, Ref<Cell> right) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(PfxHashmapNode " << m_ << " " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

struct PfxHashmapNode::Record_phmn_fork {
  typedef PfxHashmapNode type_class;
  unsigned n;  	// n : #
  Ref<Cell> left;  	// left : ^(PfxHashmap n X)
  Ref<Cell> right;  	// right : ^(PfxHashmap n X)
};

//
// headers for type `PfxHashmapE`
//

struct PfxHashmapE final : TLB_Complex {
  enum { phme_empty, phme_root };
  static constexpr int cons_len_exact = 1;
  unsigned m_;
  const TLB &X_;
  PfxHashmapE(unsigned m, const TLB& X) : m_(m), X_(X) {}
  struct Record_phme_empty {
    typedef PfxHashmapE type_class;
  };
  struct Record_phme_root {
    typedef PfxHashmapE type_class;
    unsigned n;  	// n : #
    Ref<Cell> root;  	// root : ^(PfxHashmap n X)
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_phme_empty& data) const;
  bool unpack_phme_empty(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_phme_empty& data) const;
  bool cell_unpack_phme_empty(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_phme_empty& data) const;
  bool pack_phme_empty(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_phme_empty& data) const;
  bool cell_pack_phme_empty(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_phme_root& data) const;
  bool unpack_phme_root(vm::CellSlice& cs, unsigned& n, Ref<Cell>& root) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_phme_root& data) const;
  bool cell_unpack_phme_root(Ref<vm::Cell> cell_ref, unsigned& n, Ref<Cell>& root) const;
  bool pack(vm::CellBuilder& cb, const Record_phme_root& data) const;
  bool pack_phme_root(vm::CellBuilder& cb, Ref<Cell> root) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_phme_root& data) const;
  bool cell_pack_phme_root(Ref<vm::Cell>& cell_ref, Ref<Cell> root) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(PfxHashmapE " << m_ << " " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

//
// headers for type `MsgAddressExt`
//

struct MsgAddressExt final : TLB_Complex {
  enum { addr_none, addr_extern };
  static constexpr int cons_len_exact = 2;
  struct Record_addr_none {
    typedef MsgAddressExt type_class;
  };
  struct Record_addr_extern {
    typedef MsgAddressExt type_class;
    unsigned len;  	// len : ## 9
    Ref<td::BitString> external_address;  	// external_address : bits len
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_addr_none& data) const;
  bool unpack_addr_none(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_addr_none& data) const;
  bool cell_unpack_addr_none(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_addr_none& data) const;
  bool pack_addr_none(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_addr_none& data) const;
  bool cell_pack_addr_none(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_addr_extern& data) const;
  bool unpack_addr_extern(vm::CellSlice& cs, unsigned& len, Ref<td::BitString>& external_address) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_addr_extern& data) const;
  bool cell_unpack_addr_extern(Ref<vm::Cell> cell_ref, unsigned& len, Ref<td::BitString>& external_address) const;
  bool pack(vm::CellBuilder& cb, const Record_addr_extern& data) const;
  bool pack_addr_extern(vm::CellBuilder& cb, unsigned len, Ref<td::BitString> external_address) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_addr_extern& data) const;
  bool cell_pack_addr_extern(Ref<vm::Cell>& cell_ref, unsigned len, Ref<td::BitString> external_address) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "MsgAddressExt";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(2, 3);
  }
};

extern const MsgAddressExt t_MsgAddressExt;

//
// headers for type `Anycast`
//

struct Anycast final : TLB_Complex {
  enum { anycast_info };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef Anycast type_class;
    unsigned depth;  	// depth : #<= 30
    Ref<td::BitString> rewrite_pfx;  	// rewrite_pfx : bits depth
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_anycast_info(vm::CellSlice& cs, unsigned& depth, Ref<td::BitString>& rewrite_pfx) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_anycast_info(Ref<vm::Cell> cell_ref, unsigned& depth, Ref<td::BitString>& rewrite_pfx) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_anycast_info(vm::CellBuilder& cb, unsigned depth, Ref<td::BitString> rewrite_pfx) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_anycast_info(Ref<vm::Cell>& cell_ref, unsigned depth, Ref<td::BitString> rewrite_pfx) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Anycast";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const Anycast t_Anycast;

//
// headers for type `MsgAddressInt`
//

struct MsgAddressInt final : TLB_Complex {
  enum { addr_std, addr_var };
  static constexpr int cons_len_exact = 2;
  static constexpr unsigned char cons_tag[2] = { 2, 3 };
  struct Record_addr_std;
  struct Record_addr_var;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_addr_std& data) const;
  bool unpack_addr_std(vm::CellSlice& cs, Ref<CellSlice>& anycast, int& workchain_id, td::BitArray<256>& address) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_addr_std& data) const;
  bool cell_unpack_addr_std(Ref<vm::Cell> cell_ref, Ref<CellSlice>& anycast, int& workchain_id, td::BitArray<256>& address) const;
  bool pack(vm::CellBuilder& cb, const Record_addr_std& data) const;
  bool pack_addr_std(vm::CellBuilder& cb, Ref<CellSlice> anycast, int workchain_id, td::BitArray<256> address) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_addr_std& data) const;
  bool cell_pack_addr_std(Ref<vm::Cell>& cell_ref, Ref<CellSlice> anycast, int workchain_id, td::BitArray<256> address) const;
  bool unpack(vm::CellSlice& cs, Record_addr_var& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_addr_var& data) const;
  bool pack(vm::CellBuilder& cb, const Record_addr_var& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_addr_var& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "MsgAddressInt";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(2, 12);
  }
};

struct MsgAddressInt::Record_addr_std {
  typedef MsgAddressInt type_class;
  Ref<CellSlice> anycast;  	// anycast : Maybe Anycast
  int workchain_id;  	// workchain_id : int8
  td::BitArray<256> address;  	// address : bits256
};

struct MsgAddressInt::Record_addr_var {
  typedef MsgAddressInt type_class;
  Ref<CellSlice> anycast;  	// anycast : Maybe Anycast
  unsigned addr_len;  	// addr_len : ## 9
  int workchain_id;  	// workchain_id : int32
  Ref<td::BitString> address;  	// address : bits addr_len
};

extern const MsgAddressInt t_MsgAddressInt;

//
// headers for type `MsgAddress`
//

struct MsgAddress final : TLB_Complex {
  enum { cons2, cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record_cons1 {
    typedef MsgAddress type_class;
    Ref<CellSlice> x;  	// MsgAddressInt
  };
  struct Record_cons2 {
    typedef MsgAddress type_class;
    Ref<CellSlice> x;  	// MsgAddressExt
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_cons1& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons1& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons1& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons1& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons2& data) const;
  bool unpack_cons2(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons2& data) const;
  bool cell_unpack_cons2(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons2& data) const;
  bool pack_cons2(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons2& data) const;
  bool cell_pack_cons2(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "MsgAddress";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

extern const MsgAddress t_MsgAddress;

//
// headers for type `VarUInteger`
//

struct VarUInteger final : TLB_Complex {
  enum { var_uint };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  VarUInteger(unsigned m) : m_(m) {}
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_var_uint(vm::CellSlice& cs, unsigned& n, unsigned& len, RefInt256& value) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_var_uint(Ref<vm::Cell> cell_ref, unsigned& n, unsigned& len, RefInt256& value) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_var_uint(vm::CellBuilder& cb, unsigned len, RefInt256 value) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_var_uint(Ref<vm::Cell>& cell_ref, unsigned len, RefInt256 value) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(VarUInteger " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct VarUInteger::Record {
  typedef VarUInteger type_class;
  unsigned n;  	// n : #
  unsigned len;  	// len : #< n
  RefInt256 value;  	// value : uint (8 * len)
};

//
// headers for type `VarInteger`
//

struct VarInteger final : TLB_Complex {
  enum { var_int };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  VarInteger(unsigned m) : m_(m) {}
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_var_int(vm::CellSlice& cs, unsigned& n, unsigned& len, RefInt256& value) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_var_int(Ref<vm::Cell> cell_ref, unsigned& n, unsigned& len, RefInt256& value) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_var_int(vm::CellBuilder& cb, unsigned len, RefInt256 value) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_var_int(Ref<vm::Cell>& cell_ref, unsigned len, RefInt256 value) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(VarInteger " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct VarInteger::Record {
  typedef VarInteger type_class;
  unsigned n;  	// n : #
  unsigned len;  	// len : #< n
  RefInt256 value;  	// value : int (8 * len)
};

//
// headers for type `Tomis`
//

struct Tomis final : TLB_Complex {
  enum { nanotomis };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef Tomis type_class;
    Ref<CellSlice> amount;  	// amount : VarUInteger 16
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_nanotomis(vm::CellSlice& cs, Ref<CellSlice>& amount) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_nanotomis(Ref<vm::Cell> cell_ref, Ref<CellSlice>& amount) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_nanotomis(vm::CellBuilder& cb, Ref<CellSlice> amount) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_nanotomis(Ref<vm::Cell>& cell_ref, Ref<CellSlice> amount) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Tomis";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const Tomis t_Tomis;

//
// headers for type `Coins`
//

struct Coins final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef Coins type_class;
    Ref<CellSlice> tomis;  	// tomis : Tomis
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& tomis) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& tomis) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> tomis) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> tomis) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Coins";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const Coins t_Coins;

//
// headers for type `ExtraCurrencyCollection`
//

struct ExtraCurrencyCollection final : TLB_Complex {
  enum { extra_currencies };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ExtraCurrencyCollection type_class;
    Ref<CellSlice> dict;  	// dict : HashmapE 32 (VarUInteger 32)
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_extra_currencies(vm::CellSlice& cs, Ref<CellSlice>& dict) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_extra_currencies(Ref<vm::Cell> cell_ref, Ref<CellSlice>& dict) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_extra_currencies(vm::CellBuilder& cb, Ref<CellSlice> dict) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_extra_currencies(Ref<vm::Cell>& cell_ref, Ref<CellSlice> dict) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ExtraCurrencyCollection";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ExtraCurrencyCollection t_ExtraCurrencyCollection;

//
// headers for type `CurrencyCollection`
//

struct CurrencyCollection final : TLB_Complex {
  enum { currencies };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef CurrencyCollection type_class;
    Ref<CellSlice> tomis;  	// tomis : Tomis
    Ref<CellSlice> other;  	// other : ExtraCurrencyCollection
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_currencies(vm::CellSlice& cs, Ref<CellSlice>& tomis, Ref<CellSlice>& other) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_currencies(Ref<vm::Cell> cell_ref, Ref<CellSlice>& tomis, Ref<CellSlice>& other) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_currencies(vm::CellBuilder& cb, Ref<CellSlice> tomis, Ref<CellSlice> other) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_currencies(Ref<vm::Cell>& cell_ref, Ref<CellSlice> tomis, Ref<CellSlice> other) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "CurrencyCollection";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const CurrencyCollection t_CurrencyCollection;

//
// headers for type `CommonMsgInfo`
//

struct CommonMsgInfo final : TLB_Complex {
  enum { int_msg_info, ext_in_msg_info, ext_out_msg_info };
  static constexpr char cons_len[3] = { 1, 2, 2 };
  static constexpr unsigned char cons_tag[3] = { 0, 2, 3 };
  struct Record_int_msg_info;
  struct Record_ext_in_msg_info;
  struct Record_ext_out_msg_info;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_int_msg_info& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_int_msg_info& data) const;
  bool pack(vm::CellBuilder& cb, const Record_int_msg_info& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_int_msg_info& data) const;
  bool unpack(vm::CellSlice& cs, Record_ext_in_msg_info& data) const;
  bool unpack_ext_in_msg_info(vm::CellSlice& cs, Ref<CellSlice>& src, Ref<CellSlice>& dest, Ref<CellSlice>& import_fee) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_ext_in_msg_info& data) const;
  bool cell_unpack_ext_in_msg_info(Ref<vm::Cell> cell_ref, Ref<CellSlice>& src, Ref<CellSlice>& dest, Ref<CellSlice>& import_fee) const;
  bool pack(vm::CellBuilder& cb, const Record_ext_in_msg_info& data) const;
  bool pack_ext_in_msg_info(vm::CellBuilder& cb, Ref<CellSlice> src, Ref<CellSlice> dest, Ref<CellSlice> import_fee) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_ext_in_msg_info& data) const;
  bool cell_pack_ext_in_msg_info(Ref<vm::Cell>& cell_ref, Ref<CellSlice> src, Ref<CellSlice> dest, Ref<CellSlice> import_fee) const;
  bool unpack(vm::CellSlice& cs, Record_ext_out_msg_info& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_ext_out_msg_info& data) const;
  bool pack(vm::CellBuilder& cb, const Record_ext_out_msg_info& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_ext_out_msg_info& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "CommonMsgInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(2, 13);
  }
};

struct CommonMsgInfo::Record_int_msg_info {
  typedef CommonMsgInfo type_class;
  bool ihr_disabled;  	// ihr_disabled : Bool
  bool bounce;  	// bounce : Bool
  bool bounced;  	// bounced : Bool
  Ref<CellSlice> src;  	// src : MsgAddressInt
  Ref<CellSlice> dest;  	// dest : MsgAddressInt
  Ref<CellSlice> value;  	// value : CurrencyCollection
  Ref<CellSlice> extra_flags;  	// extra_flags : VarUInteger 16
  Ref<CellSlice> fwd_fee;  	// fwd_fee : Tomis
  unsigned long long created_lt;  	// created_lt : uint64
  unsigned created_at;  	// created_at : uint32
};

struct CommonMsgInfo::Record_ext_in_msg_info {
  typedef CommonMsgInfo type_class;
  Ref<CellSlice> src;  	// src : MsgAddressExt
  Ref<CellSlice> dest;  	// dest : MsgAddressInt
  Ref<CellSlice> import_fee;  	// import_fee : Tomis
};

struct CommonMsgInfo::Record_ext_out_msg_info {
  typedef CommonMsgInfo type_class;
  Ref<CellSlice> src;  	// src : MsgAddressInt
  Ref<CellSlice> dest;  	// dest : MsgAddressExt
  unsigned long long created_lt;  	// created_lt : uint64
  unsigned created_at;  	// created_at : uint32
};

extern const CommonMsgInfo t_CommonMsgInfo;

//
// headers for type `CommonMsgInfoRelaxed`
//

struct CommonMsgInfoRelaxed final : TLB_Complex {
  enum { int_msg_info, ext_out_msg_info };
  static constexpr char cons_len[2] = { 1, 2 };
  static constexpr unsigned char cons_tag[2] = { 0, 3 };
  struct Record_int_msg_info;
  struct Record_ext_out_msg_info;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_int_msg_info& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_int_msg_info& data) const;
  bool pack(vm::CellBuilder& cb, const Record_int_msg_info& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_int_msg_info& data) const;
  bool unpack(vm::CellSlice& cs, Record_ext_out_msg_info& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_ext_out_msg_info& data) const;
  bool pack(vm::CellBuilder& cb, const Record_ext_out_msg_info& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_ext_out_msg_info& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "CommonMsgInfoRelaxed";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

struct CommonMsgInfoRelaxed::Record_int_msg_info {
  typedef CommonMsgInfoRelaxed type_class;
  bool ihr_disabled;  	// ihr_disabled : Bool
  bool bounce;  	// bounce : Bool
  bool bounced;  	// bounced : Bool
  Ref<CellSlice> src;  	// src : MsgAddress
  Ref<CellSlice> dest;  	// dest : MsgAddressInt
  Ref<CellSlice> value;  	// value : CurrencyCollection
  Ref<CellSlice> extra_flags;  	// extra_flags : VarUInteger 16
  Ref<CellSlice> fwd_fee;  	// fwd_fee : Tomis
  unsigned long long created_lt;  	// created_lt : uint64
  unsigned created_at;  	// created_at : uint32
};

struct CommonMsgInfoRelaxed::Record_ext_out_msg_info {
  typedef CommonMsgInfoRelaxed type_class;
  Ref<CellSlice> src;  	// src : MsgAddress
  Ref<CellSlice> dest;  	// dest : MsgAddressExt
  unsigned long long created_lt;  	// created_lt : uint64
  unsigned created_at;  	// created_at : uint32
};

extern const CommonMsgInfoRelaxed t_CommonMsgInfoRelaxed;

//
// headers for type `TickTock`
//

struct TickTock final : TLB_Complex {
  enum { tick_tock };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef TickTock type_class;
    bool tick;  	// tick : Bool
    bool tock;  	// tock : Bool
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 2;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(2);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(2);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_tick_tock(vm::CellSlice& cs, bool& tick, bool& tock) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_tick_tock(Ref<vm::Cell> cell_ref, bool& tick, bool& tock) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_tick_tock(vm::CellBuilder& cb, bool tick, bool tock) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_tick_tock(Ref<vm::Cell>& cell_ref, bool tick, bool tock) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "TickTock";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const TickTock t_TickTock;

//
// headers for type `StateInit`
//

struct StateInit final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "StateInit";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct StateInit::Record {
  typedef StateInit type_class;
  Ref<CellSlice> fixed_prefix_length;  	// fixed_prefix_length : Maybe (## 5)
  Ref<CellSlice> special;  	// special : Maybe TickTock
  Ref<CellSlice> code;  	// code : Maybe ^Cell
  Ref<CellSlice> data;  	// data : Maybe ^Cell
  Ref<CellSlice> library;  	// library : Maybe ^Cell
};

extern const StateInit t_StateInit;

//
// headers for type `StateInitWithLibs`
//

struct StateInitWithLibs final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "StateInitWithLibs";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct StateInitWithLibs::Record {
  typedef StateInitWithLibs type_class;
  Ref<CellSlice> fixed_prefix_length;  	// fixed_prefix_length : Maybe (## 5)
  Ref<CellSlice> special;  	// special : Maybe TickTock
  Ref<CellSlice> code;  	// code : Maybe ^Cell
  Ref<CellSlice> data;  	// data : Maybe ^Cell
  Ref<CellSlice> library;  	// library : HashmapE 256 SimpleLib
};

extern const StateInitWithLibs t_StateInitWithLibs;

//
// headers for type `SimpleLib`
//

struct SimpleLib final : TLB_Complex {
  enum { simple_lib };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef SimpleLib type_class;
    bool public1;  	// public : Bool
    Ref<Cell> root;  	// root : ^Cell
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 0x10001;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x10001);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_simple_lib(vm::CellSlice& cs, bool& public1, Ref<Cell>& root) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_simple_lib(Ref<vm::Cell> cell_ref, bool& public1, Ref<Cell>& root) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_simple_lib(vm::CellBuilder& cb, bool public1, Ref<Cell> root) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_simple_lib(Ref<vm::Cell>& cell_ref, bool public1, Ref<Cell> root) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "SimpleLib";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const SimpleLib t_SimpleLib;

//
// headers for type `Message`
//

struct Message final : TLB_Complex {
  enum { message };
  static constexpr int cons_len_exact = 0;
  const TLB &X_;
  Message(const TLB& X) : X_(X) {}
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_message(vm::CellSlice& cs, Ref<CellSlice>& info, Ref<CellSlice>& init, Ref<CellSlice>& body) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_message(Ref<vm::Cell> cell_ref, Ref<CellSlice>& info, Ref<CellSlice>& init, Ref<CellSlice>& body) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_message(vm::CellBuilder& cb, Ref<CellSlice> info, Ref<CellSlice> init, Ref<CellSlice> body) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_message(Ref<vm::Cell>& cell_ref, Ref<CellSlice> info, Ref<CellSlice> init, Ref<CellSlice> body) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(Message " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct Message::Record {
  typedef Message type_class;
  Ref<CellSlice> info;  	// info : CommonMsgInfo
  Ref<CellSlice> init;  	// init : Maybe (Either StateInit ^StateInit)
  Ref<CellSlice> body;  	// body : Either X ^X
};

//
// headers for type `MessageRelaxed`
//

struct MessageRelaxed final : TLB_Complex {
  enum { message };
  static constexpr int cons_len_exact = 0;
  const TLB &X_;
  MessageRelaxed(const TLB& X) : X_(X) {}
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_message(vm::CellSlice& cs, Ref<CellSlice>& info, Ref<CellSlice>& init, Ref<CellSlice>& body) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_message(Ref<vm::Cell> cell_ref, Ref<CellSlice>& info, Ref<CellSlice>& init, Ref<CellSlice>& body) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_message(vm::CellBuilder& cb, Ref<CellSlice> info, Ref<CellSlice> init, Ref<CellSlice> body) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_message(Ref<vm::Cell>& cell_ref, Ref<CellSlice> info, Ref<CellSlice> init, Ref<CellSlice> body) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(MessageRelaxed " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct MessageRelaxed::Record {
  typedef MessageRelaxed type_class;
  Ref<CellSlice> info;  	// info : CommonMsgInfoRelaxed
  Ref<CellSlice> init;  	// init : Maybe (Either StateInit ^StateInit)
  Ref<CellSlice> body;  	// body : Either X ^X
};

//
// headers for type `EitherStateInit`
//

struct EitherStateInit final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef EitherStateInit type_class;
    Ref<CellSlice> init;  	// init : Maybe (Either StateInit ^StateInit)
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& init) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& init) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> init) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> init) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "EitherStateInit";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const EitherStateInit t_EitherStateInit;

//
// headers for type `MessageAny`
//

struct MessageAny final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef MessageAny type_class;
    Ref<CellSlice> x;  	// Message Any
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "MessageAny";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const MessageAny t_MessageAny;

//
// headers for type `NewBounceOriginalInfo`
//

struct NewBounceOriginalInfo final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& value, unsigned long long& created_lt, unsigned& created_at) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& value, unsigned long long& created_lt, unsigned& created_at) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> value, unsigned long long created_lt, unsigned created_at) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> value, unsigned long long created_lt, unsigned created_at) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "NewBounceOriginalInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct NewBounceOriginalInfo::Record {
  typedef NewBounceOriginalInfo type_class;
  Ref<CellSlice> value;  	// value : CurrencyCollection
  unsigned long long created_lt;  	// created_lt : uint64
  unsigned created_at;  	// created_at : uint32
};

extern const NewBounceOriginalInfo t_NewBounceOriginalInfo;

//
// headers for type `NewBounceComputePhaseInfo`
//

struct NewBounceComputePhaseInfo final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef NewBounceComputePhaseInfo type_class;
    unsigned gas_used;  	// gas_used : uint32
    unsigned vm_steps;  	// vm_steps : uint32
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 64;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(64);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(64);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, unsigned& gas_used, unsigned& vm_steps) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, unsigned& gas_used, unsigned& vm_steps) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, unsigned gas_used, unsigned vm_steps) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, unsigned gas_used, unsigned vm_steps) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "NewBounceComputePhaseInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const NewBounceComputePhaseInfo t_NewBounceComputePhaseInfo;

//
// headers for type `NewBounceBody`
//

struct NewBounceBody final : TLB_Complex {
  enum { new_bounce_body };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0xfffffffeU };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "NewBounceBody";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct NewBounceBody::Record {
  typedef NewBounceBody type_class;
  Ref<Cell> original_body;  	// original_body : ^Cell
  Ref<Cell> original_info;  	// original_info : ^NewBounceOriginalInfo
  int bounced_by_phase;  	// bounced_by_phase : uint8
  int exit_code;  	// exit_code : int32
  Ref<CellSlice> compute_phase;  	// compute_phase : Maybe NewBounceComputePhaseInfo
};

extern const NewBounceBody t_NewBounceBody;

//
// headers for type `IntermediateAddress`
//

struct IntermediateAddress final : TLB_Complex {
  enum { interm_addr_regular, interm_addr_simple, interm_addr_ext };
  static constexpr char cons_len[3] = { 1, 2, 2 };
  static constexpr unsigned char cons_tag[3] = { 0, 2, 3 };
  struct Record_interm_addr_regular {
    typedef IntermediateAddress type_class;
    unsigned use_dest_bits;  	// use_dest_bits : #<= 96
  };
  struct Record_interm_addr_simple {
    typedef IntermediateAddress type_class;
    int workchain_id;  	// workchain_id : int8
    unsigned long long addr_pfx;  	// addr_pfx : uint64
  };
  struct Record_interm_addr_ext {
    typedef IntermediateAddress type_class;
    int workchain_id;  	// workchain_id : int32
    unsigned long long addr_pfx;  	// addr_pfx : uint64
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_interm_addr_regular& data) const;
  bool unpack_interm_addr_regular(vm::CellSlice& cs, unsigned& use_dest_bits) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_interm_addr_regular& data) const;
  bool cell_unpack_interm_addr_regular(Ref<vm::Cell> cell_ref, unsigned& use_dest_bits) const;
  bool pack(vm::CellBuilder& cb, const Record_interm_addr_regular& data) const;
  bool pack_interm_addr_regular(vm::CellBuilder& cb, unsigned use_dest_bits) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_interm_addr_regular& data) const;
  bool cell_pack_interm_addr_regular(Ref<vm::Cell>& cell_ref, unsigned use_dest_bits) const;
  bool unpack(vm::CellSlice& cs, Record_interm_addr_simple& data) const;
  bool unpack_interm_addr_simple(vm::CellSlice& cs, int& workchain_id, unsigned long long& addr_pfx) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_interm_addr_simple& data) const;
  bool cell_unpack_interm_addr_simple(Ref<vm::Cell> cell_ref, int& workchain_id, unsigned long long& addr_pfx) const;
  bool pack(vm::CellBuilder& cb, const Record_interm_addr_simple& data) const;
  bool pack_interm_addr_simple(vm::CellBuilder& cb, int workchain_id, unsigned long long addr_pfx) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_interm_addr_simple& data) const;
  bool cell_pack_interm_addr_simple(Ref<vm::Cell>& cell_ref, int workchain_id, unsigned long long addr_pfx) const;
  bool unpack(vm::CellSlice& cs, Record_interm_addr_ext& data) const;
  bool unpack_interm_addr_ext(vm::CellSlice& cs, int& workchain_id, unsigned long long& addr_pfx) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_interm_addr_ext& data) const;
  bool cell_unpack_interm_addr_ext(Ref<vm::Cell> cell_ref, int& workchain_id, unsigned long long& addr_pfx) const;
  bool pack(vm::CellBuilder& cb, const Record_interm_addr_ext& data) const;
  bool pack_interm_addr_ext(vm::CellBuilder& cb, int workchain_id, unsigned long long addr_pfx) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_interm_addr_ext& data) const;
  bool cell_pack_interm_addr_ext(Ref<vm::Cell>& cell_ref, int workchain_id, unsigned long long addr_pfx) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "IntermediateAddress";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(2, 13);
  }
};

extern const IntermediateAddress t_IntermediateAddress;

//
// headers for type `MsgMetadata`
//

struct MsgMetadata final : TLB_Complex {
  enum { msg_metadata };
  static constexpr int cons_len_exact = 4;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_msg_metadata(vm::CellSlice& cs, unsigned& depth, Ref<CellSlice>& initiator_addr, unsigned long long& initiator_lt) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_msg_metadata(Ref<vm::Cell> cell_ref, unsigned& depth, Ref<CellSlice>& initiator_addr, unsigned long long& initiator_lt) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_msg_metadata(vm::CellBuilder& cb, unsigned depth, Ref<CellSlice> initiator_addr, unsigned long long initiator_lt) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_msg_metadata(Ref<vm::Cell>& cell_ref, unsigned depth, Ref<CellSlice> initiator_addr, unsigned long long initiator_lt) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "MsgMetadata";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct MsgMetadata::Record {
  typedef MsgMetadata type_class;
  unsigned depth;  	// depth : uint32
  Ref<CellSlice> initiator_addr;  	// initiator_addr : MsgAddressInt
  unsigned long long initiator_lt;  	// initiator_lt : uint64
};

extern const MsgMetadata t_MsgMetadata;

//
// headers for type `MsgEnvelope`
//

struct MsgEnvelope final : TLB_Complex {
  enum { msg_envelope, msg_envelope_v2 };
  static constexpr int cons_len_exact = 4;
  static constexpr unsigned char cons_tag[2] = { 4, 5 };
  struct Record_msg_envelope;
  struct Record_msg_envelope_v2;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_msg_envelope& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_envelope& data) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_envelope& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_envelope& data) const;
  bool unpack(vm::CellSlice& cs, Record_msg_envelope_v2& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_envelope_v2& data) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_envelope_v2& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_envelope_v2& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "MsgEnvelope";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(4, 0x30);
  }
};

struct MsgEnvelope::Record_msg_envelope {
  typedef MsgEnvelope type_class;
  Ref<CellSlice> cur_addr;  	// cur_addr : IntermediateAddress
  Ref<CellSlice> next_addr;  	// next_addr : IntermediateAddress
  Ref<CellSlice> fwd_fee_remaining;  	// fwd_fee_remaining : Tomis
  Ref<Cell> msg;  	// msg : ^(Message Any)
};

struct MsgEnvelope::Record_msg_envelope_v2 {
  typedef MsgEnvelope type_class;
  Ref<CellSlice> cur_addr;  	// cur_addr : IntermediateAddress
  Ref<CellSlice> next_addr;  	// next_addr : IntermediateAddress
  Ref<CellSlice> fwd_fee_remaining;  	// fwd_fee_remaining : Tomis
  Ref<Cell> msg;  	// msg : ^(Message Any)
  Ref<CellSlice> emitted_lt;  	// emitted_lt : Maybe uint64
  Ref<CellSlice> metadata;  	// metadata : Maybe MsgMetadata
};

extern const MsgEnvelope t_MsgEnvelope;

//
// headers for type `InMsg`
//

struct InMsg final : TLB_Complex {
  enum { msg_import_ext, msg_import_deferred_fin, msg_import_deferred_tr, msg_import_ihr, msg_import_imm, msg_import_fin, msg_import_tr, msg_discard_fin, msg_discard_tr };
  static constexpr char cons_len[9] = { 3, 5, 5, 3, 3, 3, 3, 3, 3 };
  static constexpr unsigned char cons_tag[9] = { 0, 4, 5, 2, 3, 4, 5, 6, 7 };
  struct Record_msg_import_ext {
    typedef InMsg type_class;
    Ref<Cell> msg;  	// msg : ^(Message Any)
    Ref<Cell> transaction;  	// transaction : ^Transaction
  };
  struct Record_msg_import_ihr;
  struct Record_msg_import_imm;
  struct Record_msg_import_fin;
  struct Record_msg_import_tr;
  struct Record_msg_discard_fin;
  struct Record_msg_discard_tr;
  struct Record_msg_import_deferred_fin;
  struct Record_msg_import_deferred_tr {
    typedef InMsg type_class;
    Ref<Cell> in_msg;  	// in_msg : ^MsgEnvelope
    Ref<Cell> out_msg;  	// out_msg : ^MsgEnvelope
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_msg_import_ext& data) const;
  bool unpack_msg_import_ext(vm::CellSlice& cs, Ref<Cell>& msg, Ref<Cell>& transaction) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_import_ext& data) const;
  bool cell_unpack_msg_import_ext(Ref<vm::Cell> cell_ref, Ref<Cell>& msg, Ref<Cell>& transaction) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_import_ext& data) const;
  bool pack_msg_import_ext(vm::CellBuilder& cb, Ref<Cell> msg, Ref<Cell> transaction) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_import_ext& data) const;
  bool cell_pack_msg_import_ext(Ref<vm::Cell>& cell_ref, Ref<Cell> msg, Ref<Cell> transaction) const;
  bool unpack(vm::CellSlice& cs, Record_msg_import_ihr& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_import_ihr& data) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_import_ihr& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_import_ihr& data) const;
  bool unpack(vm::CellSlice& cs, Record_msg_import_imm& data) const;
  bool unpack_msg_import_imm(vm::CellSlice& cs, Ref<Cell>& in_msg, Ref<Cell>& transaction, Ref<CellSlice>& fwd_fee) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_import_imm& data) const;
  bool cell_unpack_msg_import_imm(Ref<vm::Cell> cell_ref, Ref<Cell>& in_msg, Ref<Cell>& transaction, Ref<CellSlice>& fwd_fee) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_import_imm& data) const;
  bool pack_msg_import_imm(vm::CellBuilder& cb, Ref<Cell> in_msg, Ref<Cell> transaction, Ref<CellSlice> fwd_fee) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_import_imm& data) const;
  bool cell_pack_msg_import_imm(Ref<vm::Cell>& cell_ref, Ref<Cell> in_msg, Ref<Cell> transaction, Ref<CellSlice> fwd_fee) const;
  bool unpack(vm::CellSlice& cs, Record_msg_import_fin& data) const;
  bool unpack_msg_import_fin(vm::CellSlice& cs, Ref<Cell>& in_msg, Ref<Cell>& transaction, Ref<CellSlice>& fwd_fee) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_import_fin& data) const;
  bool cell_unpack_msg_import_fin(Ref<vm::Cell> cell_ref, Ref<Cell>& in_msg, Ref<Cell>& transaction, Ref<CellSlice>& fwd_fee) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_import_fin& data) const;
  bool pack_msg_import_fin(vm::CellBuilder& cb, Ref<Cell> in_msg, Ref<Cell> transaction, Ref<CellSlice> fwd_fee) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_import_fin& data) const;
  bool cell_pack_msg_import_fin(Ref<vm::Cell>& cell_ref, Ref<Cell> in_msg, Ref<Cell> transaction, Ref<CellSlice> fwd_fee) const;
  bool unpack(vm::CellSlice& cs, Record_msg_import_tr& data) const;
  bool unpack_msg_import_tr(vm::CellSlice& cs, Ref<Cell>& in_msg, Ref<Cell>& out_msg, Ref<CellSlice>& transit_fee) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_import_tr& data) const;
  bool cell_unpack_msg_import_tr(Ref<vm::Cell> cell_ref, Ref<Cell>& in_msg, Ref<Cell>& out_msg, Ref<CellSlice>& transit_fee) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_import_tr& data) const;
  bool pack_msg_import_tr(vm::CellBuilder& cb, Ref<Cell> in_msg, Ref<Cell> out_msg, Ref<CellSlice> transit_fee) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_import_tr& data) const;
  bool cell_pack_msg_import_tr(Ref<vm::Cell>& cell_ref, Ref<Cell> in_msg, Ref<Cell> out_msg, Ref<CellSlice> transit_fee) const;
  bool unpack(vm::CellSlice& cs, Record_msg_discard_fin& data) const;
  bool unpack_msg_discard_fin(vm::CellSlice& cs, Ref<Cell>& in_msg, unsigned long long& transaction_id, Ref<CellSlice>& fwd_fee) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_discard_fin& data) const;
  bool cell_unpack_msg_discard_fin(Ref<vm::Cell> cell_ref, Ref<Cell>& in_msg, unsigned long long& transaction_id, Ref<CellSlice>& fwd_fee) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_discard_fin& data) const;
  bool pack_msg_discard_fin(vm::CellBuilder& cb, Ref<Cell> in_msg, unsigned long long transaction_id, Ref<CellSlice> fwd_fee) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_discard_fin& data) const;
  bool cell_pack_msg_discard_fin(Ref<vm::Cell>& cell_ref, Ref<Cell> in_msg, unsigned long long transaction_id, Ref<CellSlice> fwd_fee) const;
  bool unpack(vm::CellSlice& cs, Record_msg_discard_tr& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_discard_tr& data) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_discard_tr& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_discard_tr& data) const;
  bool unpack(vm::CellSlice& cs, Record_msg_import_deferred_fin& data) const;
  bool unpack_msg_import_deferred_fin(vm::CellSlice& cs, Ref<Cell>& in_msg, Ref<Cell>& transaction, Ref<CellSlice>& fwd_fee) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_import_deferred_fin& data) const;
  bool cell_unpack_msg_import_deferred_fin(Ref<vm::Cell> cell_ref, Ref<Cell>& in_msg, Ref<Cell>& transaction, Ref<CellSlice>& fwd_fee) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_import_deferred_fin& data) const;
  bool pack_msg_import_deferred_fin(vm::CellBuilder& cb, Ref<Cell> in_msg, Ref<Cell> transaction, Ref<CellSlice> fwd_fee) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_import_deferred_fin& data) const;
  bool cell_pack_msg_import_deferred_fin(Ref<vm::Cell>& cell_ref, Ref<Cell> in_msg, Ref<Cell> transaction, Ref<CellSlice> fwd_fee) const;
  bool unpack(vm::CellSlice& cs, Record_msg_import_deferred_tr& data) const;
  bool unpack_msg_import_deferred_tr(vm::CellSlice& cs, Ref<Cell>& in_msg, Ref<Cell>& out_msg) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_import_deferred_tr& data) const;
  bool cell_unpack_msg_import_deferred_tr(Ref<vm::Cell> cell_ref, Ref<Cell>& in_msg, Ref<Cell>& out_msg) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_import_deferred_tr& data) const;
  bool pack_msg_import_deferred_tr(vm::CellBuilder& cb, Ref<Cell> in_msg, Ref<Cell> out_msg) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_import_deferred_tr& data) const;
  bool cell_pack_msg_import_deferred_tr(Ref<vm::Cell>& cell_ref, Ref<Cell> in_msg, Ref<Cell> out_msg) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "InMsg";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect_ext(5, 0x11111131);
  }
};

struct InMsg::Record_msg_import_ihr {
  typedef InMsg type_class;
  Ref<Cell> msg;  	// msg : ^(Message Any)
  Ref<Cell> transaction;  	// transaction : ^Transaction
  Ref<CellSlice> ihr_fee;  	// ihr_fee : Tomis
  Ref<Cell> proof_created;  	// proof_created : ^Cell
};

struct InMsg::Record_msg_import_imm {
  typedef InMsg type_class;
  Ref<Cell> in_msg;  	// in_msg : ^MsgEnvelope
  Ref<Cell> transaction;  	// transaction : ^Transaction
  Ref<CellSlice> fwd_fee;  	// fwd_fee : Tomis
};

struct InMsg::Record_msg_import_fin {
  typedef InMsg type_class;
  Ref<Cell> in_msg;  	// in_msg : ^MsgEnvelope
  Ref<Cell> transaction;  	// transaction : ^Transaction
  Ref<CellSlice> fwd_fee;  	// fwd_fee : Tomis
};

struct InMsg::Record_msg_import_tr {
  typedef InMsg type_class;
  Ref<Cell> in_msg;  	// in_msg : ^MsgEnvelope
  Ref<Cell> out_msg;  	// out_msg : ^MsgEnvelope
  Ref<CellSlice> transit_fee;  	// transit_fee : Tomis
};

struct InMsg::Record_msg_discard_fin {
  typedef InMsg type_class;
  Ref<Cell> in_msg;  	// in_msg : ^MsgEnvelope
  unsigned long long transaction_id;  	// transaction_id : uint64
  Ref<CellSlice> fwd_fee;  	// fwd_fee : Tomis
};

struct InMsg::Record_msg_discard_tr {
  typedef InMsg type_class;
  Ref<Cell> in_msg;  	// in_msg : ^MsgEnvelope
  unsigned long long transaction_id;  	// transaction_id : uint64
  Ref<CellSlice> fwd_fee;  	// fwd_fee : Tomis
  Ref<Cell> proof_delivered;  	// proof_delivered : ^Cell
};

struct InMsg::Record_msg_import_deferred_fin {
  typedef InMsg type_class;
  Ref<Cell> in_msg;  	// in_msg : ^MsgEnvelope
  Ref<Cell> transaction;  	// transaction : ^Transaction
  Ref<CellSlice> fwd_fee;  	// fwd_fee : Tomis
};

extern const InMsg t_InMsg;

//
// headers for type `ImportFees`
//

struct ImportFees final : TLB_Complex {
  enum { import_fees };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ImportFees type_class;
    Ref<CellSlice> fees_collected;  	// fees_collected : Tomis
    Ref<CellSlice> value_imported;  	// value_imported : CurrencyCollection
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_import_fees(vm::CellSlice& cs, Ref<CellSlice>& fees_collected, Ref<CellSlice>& value_imported) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_import_fees(Ref<vm::Cell> cell_ref, Ref<CellSlice>& fees_collected, Ref<CellSlice>& value_imported) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_import_fees(vm::CellBuilder& cb, Ref<CellSlice> fees_collected, Ref<CellSlice> value_imported) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_import_fees(Ref<vm::Cell>& cell_ref, Ref<CellSlice> fees_collected, Ref<CellSlice> value_imported) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ImportFees";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ImportFees t_ImportFees;

//
// headers for type `InMsgDescr`
//

struct InMsgDescr final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef InMsgDescr type_class;
    Ref<CellSlice> x;  	// HashmapAugE 256 InMsg ImportFees
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "InMsgDescr";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const InMsgDescr t_InMsgDescr;

//
// headers for type `OutMsg`
//

struct OutMsg final : TLB_Complex {
  enum { msg_export_ext, msg_export_new, msg_export_imm, msg_export_tr, msg_export_deq_imm, msg_export_new_defer, msg_export_deferred_tr, msg_export_deq, msg_export_deq_short, msg_export_tr_req };
  static constexpr char cons_len[10] = { 3, 3, 3, 3, 3, 5, 5, 4, 4, 3 };
  static constexpr unsigned char cons_tag[10] = { 0, 1, 2, 3, 4, 20, 21, 12, 13, 7 };
  struct Record_msg_export_ext {
    typedef OutMsg type_class;
    Ref<Cell> msg;  	// msg : ^(Message Any)
    Ref<Cell> transaction;  	// transaction : ^Transaction
  };
  struct Record_msg_export_imm;
  struct Record_msg_export_new {
    typedef OutMsg type_class;
    Ref<Cell> out_msg;  	// out_msg : ^MsgEnvelope
    Ref<Cell> transaction;  	// transaction : ^Transaction
  };
  struct Record_msg_export_tr {
    typedef OutMsg type_class;
    Ref<Cell> out_msg;  	// out_msg : ^MsgEnvelope
    Ref<Cell> imported;  	// imported : ^InMsg
  };
  struct Record_msg_export_deq {
    typedef OutMsg type_class;
    Ref<Cell> out_msg;  	// out_msg : ^MsgEnvelope
    long long import_block_lt;  	// import_block_lt : uint63
  };
  struct Record_msg_export_deq_short;
  struct Record_msg_export_tr_req {
    typedef OutMsg type_class;
    Ref<Cell> out_msg;  	// out_msg : ^MsgEnvelope
    Ref<Cell> imported;  	// imported : ^InMsg
  };
  struct Record_msg_export_deq_imm {
    typedef OutMsg type_class;
    Ref<Cell> out_msg;  	// out_msg : ^MsgEnvelope
    Ref<Cell> reimport;  	// reimport : ^InMsg
  };
  struct Record_msg_export_new_defer {
    typedef OutMsg type_class;
    Ref<Cell> out_msg;  	// out_msg : ^MsgEnvelope
    Ref<Cell> transaction;  	// transaction : ^Transaction
  };
  struct Record_msg_export_deferred_tr {
    typedef OutMsg type_class;
    Ref<Cell> out_msg;  	// out_msg : ^MsgEnvelope
    Ref<Cell> imported;  	// imported : ^InMsg
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_msg_export_ext& data) const;
  bool unpack_msg_export_ext(vm::CellSlice& cs, Ref<Cell>& msg, Ref<Cell>& transaction) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_export_ext& data) const;
  bool cell_unpack_msg_export_ext(Ref<vm::Cell> cell_ref, Ref<Cell>& msg, Ref<Cell>& transaction) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_export_ext& data) const;
  bool pack_msg_export_ext(vm::CellBuilder& cb, Ref<Cell> msg, Ref<Cell> transaction) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_export_ext& data) const;
  bool cell_pack_msg_export_ext(Ref<vm::Cell>& cell_ref, Ref<Cell> msg, Ref<Cell> transaction) const;
  bool unpack(vm::CellSlice& cs, Record_msg_export_imm& data) const;
  bool unpack_msg_export_imm(vm::CellSlice& cs, Ref<Cell>& out_msg, Ref<Cell>& transaction, Ref<Cell>& reimport) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_export_imm& data) const;
  bool cell_unpack_msg_export_imm(Ref<vm::Cell> cell_ref, Ref<Cell>& out_msg, Ref<Cell>& transaction, Ref<Cell>& reimport) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_export_imm& data) const;
  bool pack_msg_export_imm(vm::CellBuilder& cb, Ref<Cell> out_msg, Ref<Cell> transaction, Ref<Cell> reimport) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_export_imm& data) const;
  bool cell_pack_msg_export_imm(Ref<vm::Cell>& cell_ref, Ref<Cell> out_msg, Ref<Cell> transaction, Ref<Cell> reimport) const;
  bool unpack(vm::CellSlice& cs, Record_msg_export_new& data) const;
  bool unpack_msg_export_new(vm::CellSlice& cs, Ref<Cell>& out_msg, Ref<Cell>& transaction) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_export_new& data) const;
  bool cell_unpack_msg_export_new(Ref<vm::Cell> cell_ref, Ref<Cell>& out_msg, Ref<Cell>& transaction) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_export_new& data) const;
  bool pack_msg_export_new(vm::CellBuilder& cb, Ref<Cell> out_msg, Ref<Cell> transaction) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_export_new& data) const;
  bool cell_pack_msg_export_new(Ref<vm::Cell>& cell_ref, Ref<Cell> out_msg, Ref<Cell> transaction) const;
  bool unpack(vm::CellSlice& cs, Record_msg_export_tr& data) const;
  bool unpack_msg_export_tr(vm::CellSlice& cs, Ref<Cell>& out_msg, Ref<Cell>& imported) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_export_tr& data) const;
  bool cell_unpack_msg_export_tr(Ref<vm::Cell> cell_ref, Ref<Cell>& out_msg, Ref<Cell>& imported) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_export_tr& data) const;
  bool pack_msg_export_tr(vm::CellBuilder& cb, Ref<Cell> out_msg, Ref<Cell> imported) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_export_tr& data) const;
  bool cell_pack_msg_export_tr(Ref<vm::Cell>& cell_ref, Ref<Cell> out_msg, Ref<Cell> imported) const;
  bool unpack(vm::CellSlice& cs, Record_msg_export_deq& data) const;
  bool unpack_msg_export_deq(vm::CellSlice& cs, Ref<Cell>& out_msg, long long& import_block_lt) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_export_deq& data) const;
  bool cell_unpack_msg_export_deq(Ref<vm::Cell> cell_ref, Ref<Cell>& out_msg, long long& import_block_lt) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_export_deq& data) const;
  bool pack_msg_export_deq(vm::CellBuilder& cb, Ref<Cell> out_msg, long long import_block_lt) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_export_deq& data) const;
  bool cell_pack_msg_export_deq(Ref<vm::Cell>& cell_ref, Ref<Cell> out_msg, long long import_block_lt) const;
  bool unpack(vm::CellSlice& cs, Record_msg_export_deq_short& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_export_deq_short& data) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_export_deq_short& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_export_deq_short& data) const;
  bool unpack(vm::CellSlice& cs, Record_msg_export_tr_req& data) const;
  bool unpack_msg_export_tr_req(vm::CellSlice& cs, Ref<Cell>& out_msg, Ref<Cell>& imported) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_export_tr_req& data) const;
  bool cell_unpack_msg_export_tr_req(Ref<vm::Cell> cell_ref, Ref<Cell>& out_msg, Ref<Cell>& imported) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_export_tr_req& data) const;
  bool pack_msg_export_tr_req(vm::CellBuilder& cb, Ref<Cell> out_msg, Ref<Cell> imported) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_export_tr_req& data) const;
  bool cell_pack_msg_export_tr_req(Ref<vm::Cell>& cell_ref, Ref<Cell> out_msg, Ref<Cell> imported) const;
  bool unpack(vm::CellSlice& cs, Record_msg_export_deq_imm& data) const;
  bool unpack_msg_export_deq_imm(vm::CellSlice& cs, Ref<Cell>& out_msg, Ref<Cell>& reimport) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_export_deq_imm& data) const;
  bool cell_unpack_msg_export_deq_imm(Ref<vm::Cell> cell_ref, Ref<Cell>& out_msg, Ref<Cell>& reimport) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_export_deq_imm& data) const;
  bool pack_msg_export_deq_imm(vm::CellBuilder& cb, Ref<Cell> out_msg, Ref<Cell> reimport) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_export_deq_imm& data) const;
  bool cell_pack_msg_export_deq_imm(Ref<vm::Cell>& cell_ref, Ref<Cell> out_msg, Ref<Cell> reimport) const;
  bool unpack(vm::CellSlice& cs, Record_msg_export_new_defer& data) const;
  bool unpack_msg_export_new_defer(vm::CellSlice& cs, Ref<Cell>& out_msg, Ref<Cell>& transaction) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_export_new_defer& data) const;
  bool cell_unpack_msg_export_new_defer(Ref<vm::Cell> cell_ref, Ref<Cell>& out_msg, Ref<Cell>& transaction) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_export_new_defer& data) const;
  bool pack_msg_export_new_defer(vm::CellBuilder& cb, Ref<Cell> out_msg, Ref<Cell> transaction) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_export_new_defer& data) const;
  bool cell_pack_msg_export_new_defer(Ref<vm::Cell>& cell_ref, Ref<Cell> out_msg, Ref<Cell> transaction) const;
  bool unpack(vm::CellSlice& cs, Record_msg_export_deferred_tr& data) const;
  bool unpack_msg_export_deferred_tr(vm::CellSlice& cs, Ref<Cell>& out_msg, Ref<Cell>& imported) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_msg_export_deferred_tr& data) const;
  bool cell_unpack_msg_export_deferred_tr(Ref<vm::Cell> cell_ref, Ref<Cell>& out_msg, Ref<Cell>& imported) const;
  bool pack(vm::CellBuilder& cb, const Record_msg_export_deferred_tr& data) const;
  bool pack_msg_export_deferred_tr(vm::CellBuilder& cb, Ref<Cell> out_msg, Ref<Cell> imported) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_msg_export_deferred_tr& data) const;
  bool cell_pack_msg_export_deferred_tr(Ref<vm::Cell>& cell_ref, Ref<Cell> out_msg, Ref<Cell> imported) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "OutMsg";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect_ext(5, 0x15311111);
  }
};

struct OutMsg::Record_msg_export_imm {
  typedef OutMsg type_class;
  Ref<Cell> out_msg;  	// out_msg : ^MsgEnvelope
  Ref<Cell> transaction;  	// transaction : ^Transaction
  Ref<Cell> reimport;  	// reimport : ^InMsg
};

struct OutMsg::Record_msg_export_deq_short {
  typedef OutMsg type_class;
  td::BitArray<256> msg_env_hash;  	// msg_env_hash : bits256
  int next_workchain;  	// next_workchain : int32
  unsigned long long next_addr_pfx;  	// next_addr_pfx : uint64
  unsigned long long import_block_lt;  	// import_block_lt : uint64
};

extern const OutMsg t_OutMsg;

//
// headers for type `EnqueuedMsg`
//

struct EnqueuedMsg final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef EnqueuedMsg type_class;
    unsigned long long enqueued_lt;  	// enqueued_lt : uint64
    Ref<Cell> out_msg;  	// out_msg : ^MsgEnvelope
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 0x10040;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x10040);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, unsigned long long& enqueued_lt, Ref<Cell>& out_msg) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, unsigned long long& enqueued_lt, Ref<Cell>& out_msg) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, unsigned long long enqueued_lt, Ref<Cell> out_msg) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, unsigned long long enqueued_lt, Ref<Cell> out_msg) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "EnqueuedMsg";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const EnqueuedMsg t_EnqueuedMsg;

//
// headers for type `OutMsgDescr`
//

struct OutMsgDescr final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef OutMsgDescr type_class;
    Ref<CellSlice> x;  	// HashmapAugE 256 OutMsg CurrencyCollection
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "OutMsgDescr";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const OutMsgDescr t_OutMsgDescr;

//
// headers for type `OutMsgQueue`
//

struct OutMsgQueue final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef OutMsgQueue type_class;
    Ref<CellSlice> x;  	// HashmapAugE 352 EnqueuedMsg uint64
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "OutMsgQueue";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const OutMsgQueue t_OutMsgQueue;

//
// headers for type `ProcessedUpto`
//

struct ProcessedUpto final : TLB_Complex {
  enum { processed_upto };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ProcessedUpto type_class;
    unsigned long long last_msg_lt;  	// last_msg_lt : uint64
    td::BitArray<256> last_msg_hash;  	// last_msg_hash : bits256
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 320;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(320);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(320);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_processed_upto(vm::CellSlice& cs, unsigned long long& last_msg_lt, td::BitArray<256>& last_msg_hash) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_processed_upto(Ref<vm::Cell> cell_ref, unsigned long long& last_msg_lt, td::BitArray<256>& last_msg_hash) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_processed_upto(vm::CellBuilder& cb, unsigned long long last_msg_lt, td::BitArray<256> last_msg_hash) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_processed_upto(Ref<vm::Cell>& cell_ref, unsigned long long last_msg_lt, td::BitArray<256> last_msg_hash) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ProcessedUpto";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ProcessedUpto t_ProcessedUpto;

//
// headers for type `ProcessedInfo`
//

struct ProcessedInfo final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ProcessedInfo type_class;
    Ref<CellSlice> x;  	// HashmapE 96 ProcessedUpto
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ProcessedInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ProcessedInfo t_ProcessedInfo;

//
// headers for type `IhrPendingSince`
//

struct IhrPendingSince final : TLB_Complex {
  enum { ihr_pending };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef IhrPendingSince type_class;
    unsigned long long import_lt;  	// import_lt : uint64
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 64;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(64);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(64);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_ihr_pending(vm::CellSlice& cs, unsigned long long& import_lt) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_ihr_pending(Ref<vm::Cell> cell_ref, unsigned long long& import_lt) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_ihr_pending(vm::CellBuilder& cb, unsigned long long import_lt) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_ihr_pending(Ref<vm::Cell>& cell_ref, unsigned long long import_lt) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "IhrPendingSince";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const IhrPendingSince t_IhrPendingSince;

//
// headers for type `IhrPendingInfo`
//

struct IhrPendingInfo final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef IhrPendingInfo type_class;
    Ref<CellSlice> x;  	// HashmapE 320 IhrPendingSince
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "IhrPendingInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const IhrPendingInfo t_IhrPendingInfo;

//
// headers for type `AccountDispatchQueue`
//

struct AccountDispatchQueue final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef AccountDispatchQueue type_class;
    Ref<CellSlice> messages;  	// messages : HashmapE 64 EnqueuedMsg
    long long count;  	// count : uint48
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& messages, long long& count) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& messages, long long& count) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> messages, long long count) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> messages, long long count) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "AccountDispatchQueue";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const AccountDispatchQueue t_AccountDispatchQueue;

//
// headers for type `DispatchQueue`
//

struct DispatchQueue final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef DispatchQueue type_class;
    Ref<CellSlice> x;  	// HashmapAugE 256 AccountDispatchQueue uint64
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "DispatchQueue";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const DispatchQueue t_DispatchQueue;

//
// headers for type `OutMsgQueueExtra`
//

struct OutMsgQueueExtra final : TLB_Complex {
  enum { out_msg_queue_extra };
  static constexpr int cons_len_exact = 4;
  struct Record {
    typedef OutMsgQueueExtra type_class;
    Ref<CellSlice> dispatch_queue;  	// dispatch_queue : DispatchQueue
    Ref<CellSlice> out_queue_size;  	// out_queue_size : Maybe uint48
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_out_msg_queue_extra(vm::CellSlice& cs, Ref<CellSlice>& dispatch_queue, Ref<CellSlice>& out_queue_size) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_out_msg_queue_extra(Ref<vm::Cell> cell_ref, Ref<CellSlice>& dispatch_queue, Ref<CellSlice>& out_queue_size) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_out_msg_queue_extra(vm::CellBuilder& cb, Ref<CellSlice> dispatch_queue, Ref<CellSlice> out_queue_size) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_out_msg_queue_extra(Ref<vm::Cell>& cell_ref, Ref<CellSlice> dispatch_queue, Ref<CellSlice> out_queue_size) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "OutMsgQueueExtra";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const OutMsgQueueExtra t_OutMsgQueueExtra;

//
// headers for type `OutMsgQueueInfo`
//

struct OutMsgQueueInfo final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& out_queue, Ref<CellSlice>& proc_info, Ref<CellSlice>& extra) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& out_queue, Ref<CellSlice>& proc_info, Ref<CellSlice>& extra) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> out_queue, Ref<CellSlice> proc_info, Ref<CellSlice> extra) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> out_queue, Ref<CellSlice> proc_info, Ref<CellSlice> extra) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "OutMsgQueueInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct OutMsgQueueInfo::Record {
  typedef OutMsgQueueInfo type_class;
  Ref<CellSlice> out_queue;  	// out_queue : OutMsgQueue
  Ref<CellSlice> proc_info;  	// proc_info : ProcessedInfo
  Ref<CellSlice> extra;  	// extra : Maybe OutMsgQueueExtra
};

extern const OutMsgQueueInfo t_OutMsgQueueInfo;

//
// headers for type `StorageExtraInfo`
//

struct StorageExtraInfo final : TLB_Complex {
  enum { storage_extra_none, storage_extra_info };
  static constexpr int cons_len_exact = 3;
  struct Record_storage_extra_none {
    typedef StorageExtraInfo type_class;
  };
  struct Record_storage_extra_info {
    typedef StorageExtraInfo type_class;
    RefInt256 dict_hash;  	// dict_hash : uint256
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_storage_extra_none& data) const;
  bool unpack_storage_extra_none(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_storage_extra_none& data) const;
  bool cell_unpack_storage_extra_none(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_storage_extra_none& data) const;
  bool pack_storage_extra_none(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_storage_extra_none& data) const;
  bool cell_pack_storage_extra_none(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_storage_extra_info& data) const;
  bool unpack_storage_extra_info(vm::CellSlice& cs, RefInt256& dict_hash) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_storage_extra_info& data) const;
  bool cell_unpack_storage_extra_info(Ref<vm::Cell> cell_ref, RefInt256& dict_hash) const;
  bool pack(vm::CellBuilder& cb, const Record_storage_extra_info& data) const;
  bool pack_storage_extra_info(vm::CellBuilder& cb, RefInt256 dict_hash) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_storage_extra_info& data) const;
  bool cell_pack_storage_extra_info(Ref<vm::Cell>& cell_ref, RefInt256 dict_hash) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "StorageExtraInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(3, 3);
  }
};

extern const StorageExtraInfo t_StorageExtraInfo;

//
// headers for type `StorageUsed`
//

struct StorageUsed final : TLB_Complex {
  enum { storage_used };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef StorageUsed type_class;
    Ref<CellSlice> cells;  	// cells : VarUInteger 7
    Ref<CellSlice> bits;  	// bits : VarUInteger 7
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_storage_used(vm::CellSlice& cs, Ref<CellSlice>& cells, Ref<CellSlice>& bits) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_storage_used(Ref<vm::Cell> cell_ref, Ref<CellSlice>& cells, Ref<CellSlice>& bits) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_storage_used(vm::CellBuilder& cb, Ref<CellSlice> cells, Ref<CellSlice> bits) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_storage_used(Ref<vm::Cell>& cell_ref, Ref<CellSlice> cells, Ref<CellSlice> bits) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "StorageUsed";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const StorageUsed t_StorageUsed;

//
// headers for type `StorageInfo`
//

struct StorageInfo final : TLB_Complex {
  enum { storage_info };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "StorageInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct StorageInfo::Record {
  typedef StorageInfo type_class;
  Ref<CellSlice> used;  	// used : StorageUsed
  Ref<CellSlice> storage_extra;  	// storage_extra : StorageExtraInfo
  unsigned last_paid;  	// last_paid : uint32
  Ref<CellSlice> due_payment;  	// due_payment : Maybe Tomis
};

extern const StorageInfo t_StorageInfo;

//
// headers for type `Account`
//

struct Account final : TLB_Complex {
  enum { account_none, account };
  static constexpr int cons_len_exact = 1;
  struct Record_account_none {
    typedef Account type_class;
  };
  struct Record_account;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_account_none& data) const;
  bool unpack_account_none(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_account_none& data) const;
  bool cell_unpack_account_none(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_account_none& data) const;
  bool pack_account_none(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_account_none& data) const;
  bool cell_pack_account_none(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_account& data) const;
  bool unpack_account(vm::CellSlice& cs, Ref<CellSlice>& addr, Ref<CellSlice>& storage_stat, Ref<CellSlice>& storage) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_account& data) const;
  bool cell_unpack_account(Ref<vm::Cell> cell_ref, Ref<CellSlice>& addr, Ref<CellSlice>& storage_stat, Ref<CellSlice>& storage) const;
  bool pack(vm::CellBuilder& cb, const Record_account& data) const;
  bool pack_account(vm::CellBuilder& cb, Ref<CellSlice> addr, Ref<CellSlice> storage_stat, Ref<CellSlice> storage) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_account& data) const;
  bool cell_pack_account(Ref<vm::Cell>& cell_ref, Ref<CellSlice> addr, Ref<CellSlice> storage_stat, Ref<CellSlice> storage) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Account";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

struct Account::Record_account {
  typedef Account type_class;
  Ref<CellSlice> addr;  	// addr : MsgAddressInt
  Ref<CellSlice> storage_stat;  	// storage_stat : StorageInfo
  Ref<CellSlice> storage;  	// storage : AccountStorage
};

extern const Account t_Account;

//
// headers for type `AccountStorage`
//

struct AccountStorage final : TLB_Complex {
  enum { account_storage };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_account_storage(vm::CellSlice& cs, unsigned long long& last_trans_lt, Ref<CellSlice>& balance, Ref<CellSlice>& state) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_account_storage(Ref<vm::Cell> cell_ref, unsigned long long& last_trans_lt, Ref<CellSlice>& balance, Ref<CellSlice>& state) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_account_storage(vm::CellBuilder& cb, unsigned long long last_trans_lt, Ref<CellSlice> balance, Ref<CellSlice> state) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_account_storage(Ref<vm::Cell>& cell_ref, unsigned long long last_trans_lt, Ref<CellSlice> balance, Ref<CellSlice> state) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "AccountStorage";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct AccountStorage::Record {
  typedef AccountStorage type_class;
  unsigned long long last_trans_lt;  	// last_trans_lt : uint64
  Ref<CellSlice> balance;  	// balance : CurrencyCollection
  Ref<CellSlice> state;  	// state : AccountState
};

extern const AccountStorage t_AccountStorage;

//
// headers for type `AccountState`
//

struct AccountState final : TLB_Complex {
  enum { account_uninit, account_frozen, account_active };
  static constexpr char cons_len[3] = { 2, 2, 1 };
  static constexpr unsigned char cons_tag[3] = { 0, 1, 1 };
  struct Record_account_uninit {
    typedef AccountState type_class;
  };
  struct Record_account_active {
    typedef AccountState type_class;
    Ref<CellSlice> x;  	// StateInit
  };
  struct Record_account_frozen {
    typedef AccountState type_class;
    td::BitArray<256> state_hash;  	// state_hash : bits256
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_account_uninit& data) const;
  bool unpack_account_uninit(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_account_uninit& data) const;
  bool cell_unpack_account_uninit(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_account_uninit& data) const;
  bool pack_account_uninit(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_account_uninit& data) const;
  bool cell_pack_account_uninit(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_account_active& data) const;
  bool unpack_account_active(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_account_active& data) const;
  bool cell_unpack_account_active(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_account_active& data) const;
  bool pack_account_active(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_account_active& data) const;
  bool cell_pack_account_active(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_account_frozen& data) const;
  bool unpack_account_frozen(vm::CellSlice& cs, td::BitArray<256>& state_hash) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_account_frozen& data) const;
  bool cell_unpack_account_frozen(Ref<vm::Cell> cell_ref, td::BitArray<256>& state_hash) const;
  bool pack(vm::CellBuilder& cb, const Record_account_frozen& data) const;
  bool pack_account_frozen(vm::CellBuilder& cb, td::BitArray<256> state_hash) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_account_frozen& data) const;
  bool cell_pack_account_frozen(Ref<vm::Cell>& cell_ref, td::BitArray<256> state_hash) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "AccountState";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(2, 7);
  }
};

extern const AccountState t_AccountState;

//
// headers for type `AccountStatus`
//

struct AccountStatus final : TLB_Complex {
  enum { acc_state_uninit, acc_state_frozen, acc_state_active, acc_state_nonexist };
  static constexpr int cons_len_exact = 2;
  struct Record_acc_state_uninit {
    typedef AccountStatus type_class;
  };
  struct Record_acc_state_frozen {
    typedef AccountStatus type_class;
  };
  struct Record_acc_state_active {
    typedef AccountStatus type_class;
  };
  struct Record_acc_state_nonexist {
    typedef AccountStatus type_class;
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 2;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(2);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(2);
  }
  bool fetch_enum_to(vm::CellSlice& cs, char& value) const;
  bool store_enum_from(vm::CellBuilder& cb, int value) const;
  bool unpack(vm::CellSlice& cs, Record_acc_state_uninit& data) const;
  bool unpack_acc_state_uninit(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_acc_state_uninit& data) const;
  bool cell_unpack_acc_state_uninit(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_acc_state_uninit& data) const;
  bool pack_acc_state_uninit(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_acc_state_uninit& data) const;
  bool cell_pack_acc_state_uninit(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_acc_state_frozen& data) const;
  bool unpack_acc_state_frozen(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_acc_state_frozen& data) const;
  bool cell_unpack_acc_state_frozen(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_acc_state_frozen& data) const;
  bool pack_acc_state_frozen(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_acc_state_frozen& data) const;
  bool cell_pack_acc_state_frozen(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_acc_state_active& data) const;
  bool unpack_acc_state_active(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_acc_state_active& data) const;
  bool cell_unpack_acc_state_active(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_acc_state_active& data) const;
  bool pack_acc_state_active(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_acc_state_active& data) const;
  bool cell_pack_acc_state_active(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_acc_state_nonexist& data) const;
  bool unpack_acc_state_nonexist(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_acc_state_nonexist& data) const;
  bool cell_unpack_acc_state_nonexist(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_acc_state_nonexist& data) const;
  bool pack_acc_state_nonexist(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_acc_state_nonexist& data) const;
  bool cell_pack_acc_state_nonexist(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "AccountStatus";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(2);
  }
};

extern const AccountStatus t_AccountStatus;

//
// headers for type `ShardAccount`
//

struct ShardAccount final : TLB_Complex {
  enum { account_descr };
  static constexpr int cons_len_exact = 0;
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 0x10140;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x10140);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_account_descr(vm::CellSlice& cs, Ref<Cell>& account, td::BitArray<256>& last_trans_hash, unsigned long long& last_trans_lt) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_account_descr(Ref<vm::Cell> cell_ref, Ref<Cell>& account, td::BitArray<256>& last_trans_hash, unsigned long long& last_trans_lt) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_account_descr(vm::CellBuilder& cb, Ref<Cell> account, td::BitArray<256> last_trans_hash, unsigned long long last_trans_lt) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_account_descr(Ref<vm::Cell>& cell_ref, Ref<Cell> account, td::BitArray<256> last_trans_hash, unsigned long long last_trans_lt) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ShardAccount";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ShardAccount::Record {
  typedef ShardAccount type_class;
  Ref<Cell> account;  	// account : ^Account
  td::BitArray<256> last_trans_hash;  	// last_trans_hash : bits256
  unsigned long long last_trans_lt;  	// last_trans_lt : uint64
};

extern const ShardAccount t_ShardAccount;

//
// headers for type `DepthBalanceInfo`
//

struct DepthBalanceInfo final : TLB_Complex {
  enum { depth_balance };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef DepthBalanceInfo type_class;
    unsigned split_depth;  	// split_depth : #<= 30
    Ref<CellSlice> balance;  	// balance : CurrencyCollection
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_depth_balance(vm::CellSlice& cs, unsigned& split_depth, Ref<CellSlice>& balance) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_depth_balance(Ref<vm::Cell> cell_ref, unsigned& split_depth, Ref<CellSlice>& balance) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_depth_balance(vm::CellBuilder& cb, unsigned split_depth, Ref<CellSlice> balance) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_depth_balance(Ref<vm::Cell>& cell_ref, unsigned split_depth, Ref<CellSlice> balance) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "DepthBalanceInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const DepthBalanceInfo t_DepthBalanceInfo;

//
// headers for type `ShardAccounts`
//

struct ShardAccounts final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ShardAccounts type_class;
    Ref<CellSlice> x;  	// HashmapAugE 256 ShardAccount DepthBalanceInfo
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ShardAccounts";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ShardAccounts t_ShardAccounts;

//
// headers for auxiliary type `Transaction_aux`
//

struct Transaction_aux final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef Transaction_aux type_class;
    Ref<CellSlice> in_msg;  	// in_msg : Maybe ^(Message Any)
    Ref<CellSlice> out_msgs;  	// out_msgs : HashmapE 15 ^(Message Any)
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& in_msg, Ref<CellSlice>& out_msgs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& in_msg, Ref<CellSlice>& out_msgs) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> in_msg, Ref<CellSlice> out_msgs) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> in_msg, Ref<CellSlice> out_msgs) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Transaction_aux";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const Transaction_aux t_Transaction_aux;

//
// headers for type `Transaction`
//

struct Transaction final : TLB_Complex {
  enum { transaction };
  static constexpr int cons_len_exact = 4;
  static constexpr unsigned char cons_tag[1] = { 7 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Transaction";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct Transaction::Record {
  typedef Transaction type_class;
  td::BitArray<256> account_addr;  	// account_addr : bits256
  unsigned long long lt;  	// lt : uint64
  td::BitArray<256> prev_trans_hash;  	// prev_trans_hash : bits256
  unsigned long long prev_trans_lt;  	// prev_trans_lt : uint64
  unsigned now;  	// now : uint32
  int outmsg_cnt;  	// outmsg_cnt : uint15
  char orig_status;  	// orig_status : AccountStatus
  char end_status;  	// end_status : AccountStatus
  Transaction_aux::Record r1;  	// ^[$_ in_msg:(Maybe ^(Message Any)) out_msgs:(HashmapE 15 ^(Message Any)) ]
  Ref<CellSlice> total_fees;  	// total_fees : CurrencyCollection
  Ref<Cell> state_update;  	// state_update : ^(HASH_UPDATE Account)
  Ref<Cell> description;  	// description : ^TransactionDescr
};

extern const Transaction t_Transaction;

//
// headers for type `MERKLE_UPDATE`
//

struct MERKLE_UPDATE final : TLB_Complex {
  enum { _merkle_update };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 4 };
  const TLB &X_;
  MERKLE_UPDATE(const TLB& X) : X_(X) {}
  struct Record;
  bool always_special() const override {
    return true;
  }
  int get_size(const vm::CellSlice& cs) const override {
    return 0x20228;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x20228);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(MERKLE_UPDATE " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct MERKLE_UPDATE::Record {
  typedef MERKLE_UPDATE type_class;
  td::BitArray<256> old_hash;  	// old_hash : bits256
  td::BitArray<256> new_hash;  	// new_hash : bits256
  int old_depth;  	// old_depth : uint16
  int new_depth;  	// new_depth : uint16
  Ref<Cell> old;  	// old : ^X
  Ref<Cell> new1;  	// new : ^X
};

//
// headers for type `HASH_UPDATE`
//

struct HASH_UPDATE final : TLB_Complex {
  enum { update_hashes };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0x72 };
  const TLB &X_;
  HASH_UPDATE(const TLB& X) : X_(X) {}
  struct Record {
    typedef HASH_UPDATE type_class;
    td::BitArray<256> old_hash;  	// old_hash : bits256
    td::BitArray<256> new_hash;  	// new_hash : bits256
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 520;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(520);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_update_hashes(vm::CellSlice& cs, td::BitArray<256>& old_hash, td::BitArray<256>& new_hash) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_update_hashes(Ref<vm::Cell> cell_ref, td::BitArray<256>& old_hash, td::BitArray<256>& new_hash) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_update_hashes(vm::CellBuilder& cb, td::BitArray<256> old_hash, td::BitArray<256> new_hash) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_update_hashes(Ref<vm::Cell>& cell_ref, td::BitArray<256> old_hash, td::BitArray<256> new_hash) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(HASH_UPDATE " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

//
// headers for type `MERKLE_PROOF`
//

struct MERKLE_PROOF final : TLB_Complex {
  enum { _merkle_proof };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 3 };
  const TLB &X_;
  MERKLE_PROOF(const TLB& X) : X_(X) {}
  struct Record;
  bool always_special() const override {
    return true;
  }
  int get_size(const vm::CellSlice& cs) const override {
    return 0x10118;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x10118);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack__merkle_proof(vm::CellSlice& cs, td::BitArray<256>& virtual_hash, int& depth, Ref<Cell>& virtual_root) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack__merkle_proof(Ref<vm::Cell> cell_ref, td::BitArray<256>& virtual_hash, int& depth, Ref<Cell>& virtual_root) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack__merkle_proof(vm::CellBuilder& cb, td::BitArray<256> virtual_hash, int depth, Ref<Cell> virtual_root) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack__merkle_proof(Ref<vm::Cell>& cell_ref, td::BitArray<256> virtual_hash, int depth, Ref<Cell> virtual_root) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(MERKLE_PROOF " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct MERKLE_PROOF::Record {
  typedef MERKLE_PROOF type_class;
  td::BitArray<256> virtual_hash;  	// virtual_hash : bits256
  int depth;  	// depth : uint16
  Ref<Cell> virtual_root;  	// virtual_root : ^X
};

//
// headers for type `AccountBlock`
//

struct AccountBlock final : TLB_Complex {
  enum { acc_trans };
  static constexpr int cons_len_exact = 4;
  static constexpr unsigned char cons_tag[1] = { 5 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_acc_trans(vm::CellSlice& cs, td::BitArray<256>& account_addr, Ref<CellSlice>& transactions, Ref<Cell>& state_update) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_acc_trans(Ref<vm::Cell> cell_ref, td::BitArray<256>& account_addr, Ref<CellSlice>& transactions, Ref<Cell>& state_update) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_acc_trans(vm::CellBuilder& cb, td::BitArray<256> account_addr, Ref<CellSlice> transactions, Ref<Cell> state_update) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_acc_trans(Ref<vm::Cell>& cell_ref, td::BitArray<256> account_addr, Ref<CellSlice> transactions, Ref<Cell> state_update) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "AccountBlock";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct AccountBlock::Record {
  typedef AccountBlock type_class;
  td::BitArray<256> account_addr;  	// account_addr : bits256
  Ref<CellSlice> transactions;  	// transactions : HashmapAug 64 ^Transaction CurrencyCollection
  Ref<Cell> state_update;  	// state_update : ^(HASH_UPDATE Account)
};

extern const AccountBlock t_AccountBlock;

//
// headers for type `ShardAccountBlocks`
//

struct ShardAccountBlocks final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ShardAccountBlocks type_class;
    Ref<CellSlice> x;  	// HashmapAugE 256 AccountBlock CurrencyCollection
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ShardAccountBlocks";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ShardAccountBlocks t_ShardAccountBlocks;

//
// headers for type `TrStoragePhase`
//

struct TrStoragePhase final : TLB_Complex {
  enum { tr_phase_storage };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_tr_phase_storage(vm::CellSlice& cs, Ref<CellSlice>& storage_fees_collected, Ref<CellSlice>& storage_fees_due, char& status_change) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_tr_phase_storage(Ref<vm::Cell> cell_ref, Ref<CellSlice>& storage_fees_collected, Ref<CellSlice>& storage_fees_due, char& status_change) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_tr_phase_storage(vm::CellBuilder& cb, Ref<CellSlice> storage_fees_collected, Ref<CellSlice> storage_fees_due, char status_change) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_tr_phase_storage(Ref<vm::Cell>& cell_ref, Ref<CellSlice> storage_fees_collected, Ref<CellSlice> storage_fees_due, char status_change) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "TrStoragePhase";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct TrStoragePhase::Record {
  typedef TrStoragePhase type_class;
  Ref<CellSlice> storage_fees_collected;  	// storage_fees_collected : Tomis
  Ref<CellSlice> storage_fees_due;  	// storage_fees_due : Maybe Tomis
  char status_change;  	// status_change : AccStatusChange
};

extern const TrStoragePhase t_TrStoragePhase;

//
// headers for type `AccStatusChange`
//

struct AccStatusChange final : TLB_Complex {
  enum { acst_unchanged, acst_frozen, acst_deleted };
  static constexpr char cons_len[3] = { 1, 2, 2 };
  static constexpr unsigned char cons_tag[3] = { 0, 2, 3 };
  struct Record_acst_unchanged {
    typedef AccStatusChange type_class;
  };
  struct Record_acst_frozen {
    typedef AccStatusChange type_class;
  };
  struct Record_acst_deleted {
    typedef AccStatusChange type_class;
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool fetch_enum_to(vm::CellSlice& cs, char& value) const;
  bool store_enum_from(vm::CellBuilder& cb, int value) const;
  bool unpack(vm::CellSlice& cs, Record_acst_unchanged& data) const;
  bool unpack_acst_unchanged(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_acst_unchanged& data) const;
  bool cell_unpack_acst_unchanged(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_acst_unchanged& data) const;
  bool pack_acst_unchanged(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_acst_unchanged& data) const;
  bool cell_pack_acst_unchanged(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_acst_frozen& data) const;
  bool unpack_acst_frozen(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_acst_frozen& data) const;
  bool cell_unpack_acst_frozen(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_acst_frozen& data) const;
  bool pack_acst_frozen(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_acst_frozen& data) const;
  bool cell_pack_acst_frozen(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_acst_deleted& data) const;
  bool unpack_acst_deleted(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_acst_deleted& data) const;
  bool cell_unpack_acst_deleted(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_acst_deleted& data) const;
  bool pack_acst_deleted(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_acst_deleted& data) const;
  bool cell_pack_acst_deleted(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "AccStatusChange";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect_ext(2, 13);
  }
};

extern const AccStatusChange t_AccStatusChange;

//
// headers for type `TrCreditPhase`
//

struct TrCreditPhase final : TLB_Complex {
  enum { tr_phase_credit };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef TrCreditPhase type_class;
    Ref<CellSlice> due_fees_collected;  	// due_fees_collected : Maybe Tomis
    Ref<CellSlice> credit;  	// credit : CurrencyCollection
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_tr_phase_credit(vm::CellSlice& cs, Ref<CellSlice>& due_fees_collected, Ref<CellSlice>& credit) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_tr_phase_credit(Ref<vm::Cell> cell_ref, Ref<CellSlice>& due_fees_collected, Ref<CellSlice>& credit) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_tr_phase_credit(vm::CellBuilder& cb, Ref<CellSlice> due_fees_collected, Ref<CellSlice> credit) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_tr_phase_credit(Ref<vm::Cell>& cell_ref, Ref<CellSlice> due_fees_collected, Ref<CellSlice> credit) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "TrCreditPhase";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const TrCreditPhase t_TrCreditPhase;

//
// headers for auxiliary type `TrComputePhase_aux`
//

struct TrComputePhase_aux final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "TrComputePhase_aux";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct TrComputePhase_aux::Record {
  typedef TrComputePhase_aux type_class;
  Ref<CellSlice> gas_used;  	// gas_used : VarUInteger 7
  Ref<CellSlice> gas_limit;  	// gas_limit : VarUInteger 7
  Ref<CellSlice> gas_credit;  	// gas_credit : Maybe (VarUInteger 3)
  int mode;  	// mode : int8
  int exit_code;  	// exit_code : int32
  Ref<CellSlice> exit_arg;  	// exit_arg : Maybe int32
  unsigned vm_steps;  	// vm_steps : uint32
  td::BitArray<256> vm_init_state_hash;  	// vm_init_state_hash : bits256
  td::BitArray<256> vm_final_state_hash;  	// vm_final_state_hash : bits256
};

extern const TrComputePhase_aux t_TrComputePhase_aux;

//
// headers for type `TrComputePhase`
//

struct TrComputePhase final : TLB_Complex {
  enum { tr_phase_compute_skipped, tr_phase_compute_vm };
  static constexpr int cons_len_exact = 1;
  struct Record_tr_phase_compute_skipped {
    typedef TrComputePhase type_class;
    char reason;  	// reason : ComputeSkipReason
  };
  struct Record_tr_phase_compute_vm;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_tr_phase_compute_skipped& data) const;
  bool unpack_tr_phase_compute_skipped(vm::CellSlice& cs, char& reason) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_tr_phase_compute_skipped& data) const;
  bool cell_unpack_tr_phase_compute_skipped(Ref<vm::Cell> cell_ref, char& reason) const;
  bool pack(vm::CellBuilder& cb, const Record_tr_phase_compute_skipped& data) const;
  bool pack_tr_phase_compute_skipped(vm::CellBuilder& cb, char reason) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_tr_phase_compute_skipped& data) const;
  bool cell_pack_tr_phase_compute_skipped(Ref<vm::Cell>& cell_ref, char reason) const;
  bool unpack(vm::CellSlice& cs, Record_tr_phase_compute_vm& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_tr_phase_compute_vm& data) const;
  bool pack(vm::CellBuilder& cb, const Record_tr_phase_compute_vm& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_tr_phase_compute_vm& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "TrComputePhase";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

struct TrComputePhase::Record_tr_phase_compute_vm {
  typedef TrComputePhase type_class;
  bool success;  	// success : Bool
  bool msg_state_used;  	// msg_state_used : Bool
  bool account_activated;  	// account_activated : Bool
  Ref<CellSlice> gas_fees;  	// gas_fees : Tomis
  TrComputePhase_aux::Record r1;  	// ^[$_ gas_used:(VarUInteger 7) gas_limit:(VarUInteger 7) gas_credit:(Maybe (VarUInteger 3)) mode:int8 exit_code:int32 exit_arg:(Maybe int32) vm_steps:uint32 vm_init_state_hash:bits256 vm_final_state_hash:bits256 ]
};

extern const TrComputePhase t_TrComputePhase;

//
// headers for type `ComputeSkipReason`
//

struct ComputeSkipReason final : TLB_Complex {
  enum { cskip_no_state, cskip_bad_state, cskip_no_gas, cskip_suspended };
  static constexpr char cons_len[4] = { 2, 2, 2, 3 };
  static constexpr unsigned char cons_tag[4] = { 0, 1, 2, 6 };
  struct Record_cskip_no_state {
    typedef ComputeSkipReason type_class;
  };
  struct Record_cskip_bad_state {
    typedef ComputeSkipReason type_class;
  };
  struct Record_cskip_no_gas {
    typedef ComputeSkipReason type_class;
  };
  struct Record_cskip_suspended {
    typedef ComputeSkipReason type_class;
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool fetch_enum_to(vm::CellSlice& cs, char& value) const;
  bool store_enum_from(vm::CellBuilder& cb, int value) const;
  bool unpack(vm::CellSlice& cs, Record_cskip_no_state& data) const;
  bool unpack_cskip_no_state(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cskip_no_state& data) const;
  bool cell_unpack_cskip_no_state(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_cskip_no_state& data) const;
  bool pack_cskip_no_state(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cskip_no_state& data) const;
  bool cell_pack_cskip_no_state(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_cskip_bad_state& data) const;
  bool unpack_cskip_bad_state(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cskip_bad_state& data) const;
  bool cell_unpack_cskip_bad_state(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_cskip_bad_state& data) const;
  bool pack_cskip_bad_state(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cskip_bad_state& data) const;
  bool cell_pack_cskip_bad_state(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_cskip_no_gas& data) const;
  bool unpack_cskip_no_gas(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cskip_no_gas& data) const;
  bool cell_unpack_cskip_no_gas(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_cskip_no_gas& data) const;
  bool pack_cskip_no_gas(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cskip_no_gas& data) const;
  bool cell_pack_cskip_no_gas(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_cskip_suspended& data) const;
  bool unpack_cskip_suspended(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cskip_suspended& data) const;
  bool cell_unpack_cskip_suspended(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_cskip_suspended& data) const;
  bool pack_cskip_suspended(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cskip_suspended& data) const;
  bool cell_pack_cskip_suspended(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ComputeSkipReason";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(2);
  }
};

extern const ComputeSkipReason t_ComputeSkipReason;

//
// headers for type `TrActionPhase`
//

struct TrActionPhase final : TLB_Complex {
  enum { tr_phase_action };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "TrActionPhase";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct TrActionPhase::Record {
  typedef TrActionPhase type_class;
  bool success;  	// success : Bool
  bool valid;  	// valid : Bool
  bool no_funds;  	// no_funds : Bool
  char status_change;  	// status_change : AccStatusChange
  Ref<CellSlice> total_fwd_fees;  	// total_fwd_fees : Maybe Tomis
  Ref<CellSlice> total_action_fees;  	// total_action_fees : Maybe Tomis
  int result_code;  	// result_code : int32
  Ref<CellSlice> result_arg;  	// result_arg : Maybe int32
  int tot_actions;  	// tot_actions : uint16
  int spec_actions;  	// spec_actions : uint16
  int skipped_actions;  	// skipped_actions : uint16
  int msgs_created;  	// msgs_created : uint16
  td::BitArray<256> action_list_hash;  	// action_list_hash : bits256
  Ref<CellSlice> tot_msg_size;  	// tot_msg_size : StorageUsed
};

extern const TrActionPhase t_TrActionPhase;

//
// headers for type `TrBouncePhase`
//

struct TrBouncePhase final : TLB_Complex {
  enum { tr_phase_bounce_negfunds, tr_phase_bounce_nofunds, tr_phase_bounce_ok };
  static constexpr char cons_len[3] = { 2, 2, 1 };
  static constexpr unsigned char cons_tag[3] = { 0, 1, 1 };
  struct Record_tr_phase_bounce_negfunds {
    typedef TrBouncePhase type_class;
  };
  struct Record_tr_phase_bounce_nofunds {
    typedef TrBouncePhase type_class;
    Ref<CellSlice> msg_size;  	// msg_size : StorageUsed
    Ref<CellSlice> req_fwd_fees;  	// req_fwd_fees : Tomis
  };
  struct Record_tr_phase_bounce_ok;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_tr_phase_bounce_negfunds& data) const;
  bool unpack_tr_phase_bounce_negfunds(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_tr_phase_bounce_negfunds& data) const;
  bool cell_unpack_tr_phase_bounce_negfunds(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_tr_phase_bounce_negfunds& data) const;
  bool pack_tr_phase_bounce_negfunds(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_tr_phase_bounce_negfunds& data) const;
  bool cell_pack_tr_phase_bounce_negfunds(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_tr_phase_bounce_nofunds& data) const;
  bool unpack_tr_phase_bounce_nofunds(vm::CellSlice& cs, Ref<CellSlice>& msg_size, Ref<CellSlice>& req_fwd_fees) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_tr_phase_bounce_nofunds& data) const;
  bool cell_unpack_tr_phase_bounce_nofunds(Ref<vm::Cell> cell_ref, Ref<CellSlice>& msg_size, Ref<CellSlice>& req_fwd_fees) const;
  bool pack(vm::CellBuilder& cb, const Record_tr_phase_bounce_nofunds& data) const;
  bool pack_tr_phase_bounce_nofunds(vm::CellBuilder& cb, Ref<CellSlice> msg_size, Ref<CellSlice> req_fwd_fees) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_tr_phase_bounce_nofunds& data) const;
  bool cell_pack_tr_phase_bounce_nofunds(Ref<vm::Cell>& cell_ref, Ref<CellSlice> msg_size, Ref<CellSlice> req_fwd_fees) const;
  bool unpack(vm::CellSlice& cs, Record_tr_phase_bounce_ok& data) const;
  bool unpack_tr_phase_bounce_ok(vm::CellSlice& cs, Ref<CellSlice>& msg_size, Ref<CellSlice>& msg_fees, Ref<CellSlice>& fwd_fees) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_tr_phase_bounce_ok& data) const;
  bool cell_unpack_tr_phase_bounce_ok(Ref<vm::Cell> cell_ref, Ref<CellSlice>& msg_size, Ref<CellSlice>& msg_fees, Ref<CellSlice>& fwd_fees) const;
  bool pack(vm::CellBuilder& cb, const Record_tr_phase_bounce_ok& data) const;
  bool pack_tr_phase_bounce_ok(vm::CellBuilder& cb, Ref<CellSlice> msg_size, Ref<CellSlice> msg_fees, Ref<CellSlice> fwd_fees) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_tr_phase_bounce_ok& data) const;
  bool cell_pack_tr_phase_bounce_ok(Ref<vm::Cell>& cell_ref, Ref<CellSlice> msg_size, Ref<CellSlice> msg_fees, Ref<CellSlice> fwd_fees) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "TrBouncePhase";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect_ext(2, 7);
  }
};

struct TrBouncePhase::Record_tr_phase_bounce_ok {
  typedef TrBouncePhase type_class;
  Ref<CellSlice> msg_size;  	// msg_size : StorageUsed
  Ref<CellSlice> msg_fees;  	// msg_fees : Tomis
  Ref<CellSlice> fwd_fees;  	// fwd_fees : Tomis
};

extern const TrBouncePhase t_TrBouncePhase;

//
// headers for type `SplitMergeInfo`
//

struct SplitMergeInfo final : TLB_Complex {
  enum { split_merge_info };
  static constexpr int cons_len_exact = 0;
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 524;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(524);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(524);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "SplitMergeInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct SplitMergeInfo::Record {
  typedef SplitMergeInfo type_class;
  unsigned cur_shard_pfx_len;  	// cur_shard_pfx_len : ## 6
  unsigned acc_split_depth;  	// acc_split_depth : ## 6
  td::BitArray<256> this_addr;  	// this_addr : bits256
  td::BitArray<256> sibling_addr;  	// sibling_addr : bits256
};

extern const SplitMergeInfo t_SplitMergeInfo;

//
// headers for type `TransactionDescr`
//

struct TransactionDescr final : TLB_Complex {
  enum { trans_ord, trans_storage, trans_tick_tock, trans_split_prepare, trans_split_install, trans_merge_prepare, trans_merge_install, trans_workchain_batch_v2, trans_workchain_storage_participant_v3, trans_workchain_settlement_participant_v3, trans_workchain_entry_v3 };
  static constexpr char cons_len[11] = { 4, 4, 3, 4, 4, 4, 4, 4, 4, 4, 4 };
  static constexpr unsigned char cons_tag[11] = { 0, 1, 1, 4, 5, 6, 7, 9, 10, 11, 12 };
  struct Record_trans_ord;
  struct Record_trans_storage {
    typedef TransactionDescr type_class;
    Ref<CellSlice> storage_ph;  	// storage_ph : TrStoragePhase
  };
  struct Record_trans_workchain_storage_participant_v3 {
    typedef TransactionDescr type_class;
    Ref<Cell> binding;  	// binding : ^UnoV2HostRecord
  };
  struct Record_trans_workchain_settlement_participant_v3 {
    typedef TransactionDescr type_class;
    Ref<Cell> binding;  	// binding : ^UnoV2HostRecord
  };
  struct Record_trans_workchain_entry_v3;
  struct Record_trans_workchain_batch_v2;
  struct Record_trans_tick_tock;
  struct Record_trans_split_prepare;
  struct Record_trans_split_install;
  struct Record_trans_merge_prepare;
  struct Record_trans_merge_install;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_trans_ord& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_trans_ord& data) const;
  bool pack(vm::CellBuilder& cb, const Record_trans_ord& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_trans_ord& data) const;
  bool unpack(vm::CellSlice& cs, Record_trans_storage& data) const;
  bool unpack_trans_storage(vm::CellSlice& cs, Ref<CellSlice>& storage_ph) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_trans_storage& data) const;
  bool cell_unpack_trans_storage(Ref<vm::Cell> cell_ref, Ref<CellSlice>& storage_ph) const;
  bool pack(vm::CellBuilder& cb, const Record_trans_storage& data) const;
  bool pack_trans_storage(vm::CellBuilder& cb, Ref<CellSlice> storage_ph) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_trans_storage& data) const;
  bool cell_pack_trans_storage(Ref<vm::Cell>& cell_ref, Ref<CellSlice> storage_ph) const;
  bool unpack(vm::CellSlice& cs, Record_trans_workchain_storage_participant_v3& data) const;
  bool unpack_trans_workchain_storage_participant_v3(vm::CellSlice& cs, Ref<Cell>& binding) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_trans_workchain_storage_participant_v3& data) const;
  bool cell_unpack_trans_workchain_storage_participant_v3(Ref<vm::Cell> cell_ref, Ref<Cell>& binding) const;
  bool pack(vm::CellBuilder& cb, const Record_trans_workchain_storage_participant_v3& data) const;
  bool pack_trans_workchain_storage_participant_v3(vm::CellBuilder& cb, Ref<Cell> binding) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_trans_workchain_storage_participant_v3& data) const;
  bool cell_pack_trans_workchain_storage_participant_v3(Ref<vm::Cell>& cell_ref, Ref<Cell> binding) const;
  bool unpack(vm::CellSlice& cs, Record_trans_workchain_settlement_participant_v3& data) const;
  bool unpack_trans_workchain_settlement_participant_v3(vm::CellSlice& cs, Ref<Cell>& binding) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_trans_workchain_settlement_participant_v3& data) const;
  bool cell_unpack_trans_workchain_settlement_participant_v3(Ref<vm::Cell> cell_ref, Ref<Cell>& binding) const;
  bool pack(vm::CellBuilder& cb, const Record_trans_workchain_settlement_participant_v3& data) const;
  bool pack_trans_workchain_settlement_participant_v3(vm::CellBuilder& cb, Ref<Cell> binding) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_trans_workchain_settlement_participant_v3& data) const;
  bool cell_pack_trans_workchain_settlement_participant_v3(Ref<vm::Cell>& cell_ref, Ref<Cell> binding) const;
  bool unpack(vm::CellSlice& cs, Record_trans_workchain_entry_v3& data) const;
  bool unpack_trans_workchain_entry_v3(vm::CellSlice& cs, Ref<Cell>& binding, Ref<Cell>& input, Ref<Cell>& effects) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_trans_workchain_entry_v3& data) const;
  bool cell_unpack_trans_workchain_entry_v3(Ref<vm::Cell> cell_ref, Ref<Cell>& binding, Ref<Cell>& input, Ref<Cell>& effects) const;
  bool pack(vm::CellBuilder& cb, const Record_trans_workchain_entry_v3& data) const;
  bool pack_trans_workchain_entry_v3(vm::CellBuilder& cb, Ref<Cell> binding, Ref<Cell> input, Ref<Cell> effects) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_trans_workchain_entry_v3& data) const;
  bool cell_pack_trans_workchain_entry_v3(Ref<vm::Cell>& cell_ref, Ref<Cell> binding, Ref<Cell> input, Ref<Cell> effects) const;
  bool unpack(vm::CellSlice& cs, Record_trans_workchain_batch_v2& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_trans_workchain_batch_v2& data) const;
  bool pack(vm::CellBuilder& cb, const Record_trans_workchain_batch_v2& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_trans_workchain_batch_v2& data) const;
  bool unpack(vm::CellSlice& cs, Record_trans_tick_tock& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_trans_tick_tock& data) const;
  bool pack(vm::CellBuilder& cb, const Record_trans_tick_tock& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_trans_tick_tock& data) const;
  bool unpack(vm::CellSlice& cs, Record_trans_split_prepare& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_trans_split_prepare& data) const;
  bool pack(vm::CellBuilder& cb, const Record_trans_split_prepare& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_trans_split_prepare& data) const;
  bool unpack(vm::CellSlice& cs, Record_trans_split_install& data) const;
  bool unpack_trans_split_install(vm::CellSlice& cs, Ref<CellSlice>& split_info, Ref<Cell>& prepare_transaction, bool& installed) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_trans_split_install& data) const;
  bool cell_unpack_trans_split_install(Ref<vm::Cell> cell_ref, Ref<CellSlice>& split_info, Ref<Cell>& prepare_transaction, bool& installed) const;
  bool pack(vm::CellBuilder& cb, const Record_trans_split_install& data) const;
  bool pack_trans_split_install(vm::CellBuilder& cb, Ref<CellSlice> split_info, Ref<Cell> prepare_transaction, bool installed) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_trans_split_install& data) const;
  bool cell_pack_trans_split_install(Ref<vm::Cell>& cell_ref, Ref<CellSlice> split_info, Ref<Cell> prepare_transaction, bool installed) const;
  bool unpack(vm::CellSlice& cs, Record_trans_merge_prepare& data) const;
  bool unpack_trans_merge_prepare(vm::CellSlice& cs, Ref<CellSlice>& split_info, Ref<CellSlice>& storage_ph, bool& aborted) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_trans_merge_prepare& data) const;
  bool cell_unpack_trans_merge_prepare(Ref<vm::Cell> cell_ref, Ref<CellSlice>& split_info, Ref<CellSlice>& storage_ph, bool& aborted) const;
  bool pack(vm::CellBuilder& cb, const Record_trans_merge_prepare& data) const;
  bool pack_trans_merge_prepare(vm::CellBuilder& cb, Ref<CellSlice> split_info, Ref<CellSlice> storage_ph, bool aborted) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_trans_merge_prepare& data) const;
  bool cell_pack_trans_merge_prepare(Ref<vm::Cell>& cell_ref, Ref<CellSlice> split_info, Ref<CellSlice> storage_ph, bool aborted) const;
  bool unpack(vm::CellSlice& cs, Record_trans_merge_install& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_trans_merge_install& data) const;
  bool pack(vm::CellBuilder& cb, const Record_trans_merge_install& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_trans_merge_install& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "TransactionDescr";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(4, 0x1ef7);
  }
};

struct TransactionDescr::Record_trans_ord {
  typedef TransactionDescr type_class;
  bool credit_first;  	// credit_first : Bool
  Ref<CellSlice> storage_ph;  	// storage_ph : Maybe TrStoragePhase
  Ref<CellSlice> credit_ph;  	// credit_ph : Maybe TrCreditPhase
  Ref<CellSlice> compute_ph;  	// compute_ph : TrComputePhase
  Ref<CellSlice> action;  	// action : Maybe ^TrActionPhase
  bool aborted;  	// aborted : Bool
  Ref<CellSlice> bounce;  	// bounce : Maybe TrBouncePhase
  bool destroyed;  	// destroyed : Bool
};

struct TransactionDescr::Record_trans_workchain_entry_v3 {
  typedef TransactionDescr type_class;
  Ref<Cell> binding;  	// binding : ^UnoV2HostRecord
  Ref<Cell> input;  	// input : ^UnoV2HostInput
  Ref<Cell> effects;  	// effects : ^UnoV2HostEffects
};

struct TransactionDescr::Record_trans_workchain_batch_v2 {
  typedef TransactionDescr type_class;
  td::BitArray<256> input_hash;  	// input_hash : bits256
  td::BitArray<256> effects_hash;  	// effects_hash : bits256
  unsigned long long wire_bytes;  	// wire_bytes : uint64
  unsigned long long verification_units;  	// verification_units : uint64
  unsigned long long written_cells;  	// written_cells : uint64
  Ref<CellSlice> inbound_messages;  	// inbound_messages : Maybe ^WorkchainBatchInbound
};

struct TransactionDescr::Record_trans_tick_tock {
  typedef TransactionDescr type_class;
  bool is_tock;  	// is_tock : Bool
  Ref<CellSlice> storage_ph;  	// storage_ph : TrStoragePhase
  Ref<CellSlice> compute_ph;  	// compute_ph : TrComputePhase
  Ref<CellSlice> action;  	// action : Maybe ^TrActionPhase
  bool aborted;  	// aborted : Bool
  bool destroyed;  	// destroyed : Bool
};

struct TransactionDescr::Record_trans_split_prepare {
  typedef TransactionDescr type_class;
  Ref<CellSlice> split_info;  	// split_info : SplitMergeInfo
  Ref<CellSlice> storage_ph;  	// storage_ph : Maybe TrStoragePhase
  Ref<CellSlice> compute_ph;  	// compute_ph : TrComputePhase
  Ref<CellSlice> action;  	// action : Maybe ^TrActionPhase
  bool aborted;  	// aborted : Bool
  bool destroyed;  	// destroyed : Bool
};

struct TransactionDescr::Record_trans_split_install {
  typedef TransactionDescr type_class;
  Ref<CellSlice> split_info;  	// split_info : SplitMergeInfo
  Ref<Cell> prepare_transaction;  	// prepare_transaction : ^Transaction
  bool installed;  	// installed : Bool
};

struct TransactionDescr::Record_trans_merge_prepare {
  typedef TransactionDescr type_class;
  Ref<CellSlice> split_info;  	// split_info : SplitMergeInfo
  Ref<CellSlice> storage_ph;  	// storage_ph : TrStoragePhase
  bool aborted;  	// aborted : Bool
};

struct TransactionDescr::Record_trans_merge_install {
  typedef TransactionDescr type_class;
  Ref<CellSlice> split_info;  	// split_info : SplitMergeInfo
  Ref<Cell> prepare_transaction;  	// prepare_transaction : ^Transaction
  Ref<CellSlice> storage_ph;  	// storage_ph : Maybe TrStoragePhase
  Ref<CellSlice> credit_ph;  	// credit_ph : Maybe TrCreditPhase
  Ref<CellSlice> compute_ph;  	// compute_ph : TrComputePhase
  Ref<CellSlice> action;  	// action : Maybe ^TrActionPhase
  bool aborted;  	// aborted : Bool
  bool destroyed;  	// destroyed : Bool
};

extern const TransactionDescr t_TransactionDescr;

//
// headers for type `SmartContractInfo`
//

struct SmartContractInfo final : TLB_Complex {
  enum { smc_info };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x76ef1ea };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "SmartContractInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct SmartContractInfo::Record {
  typedef SmartContractInfo type_class;
  int actions;  	// actions : uint16
  int msgs_sent;  	// msgs_sent : uint16
  unsigned unixtime;  	// unixtime : uint32
  unsigned long long block_lt;  	// block_lt : uint64
  unsigned long long trans_lt;  	// trans_lt : uint64
  td::BitArray<256> rand_seed;  	// rand_seed : bits256
  Ref<CellSlice> balance_remaining;  	// balance_remaining : CurrencyCollection
  Ref<CellSlice> myself;  	// myself : MsgAddressInt
  Ref<CellSlice> global_config;  	// global_config : Maybe Cell
};

extern const SmartContractInfo t_SmartContractInfo;

//
// headers for type `OutList`
//

struct OutList final : TLB_Complex {
  enum { out_list, out_list_empty };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  OutList(unsigned m) : m_(m) {}
  struct Record_out_list_empty {
    typedef OutList type_class;
  };
  struct Record_out_list;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_out_list_empty& data) const;
  bool unpack_out_list_empty(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_out_list_empty& data) const;
  bool cell_unpack_out_list_empty(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_out_list_empty& data) const;
  bool pack_out_list_empty(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_out_list_empty& data) const;
  bool cell_pack_out_list_empty(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_out_list& data) const;
  bool unpack_out_list(vm::CellSlice& cs, unsigned& n, Ref<Cell>& prev, Ref<CellSlice>& action) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_out_list& data) const;
  bool cell_unpack_out_list(Ref<vm::Cell> cell_ref, unsigned& n, Ref<Cell>& prev, Ref<CellSlice>& action) const;
  bool pack(vm::CellBuilder& cb, const Record_out_list& data) const;
  bool pack_out_list(vm::CellBuilder& cb, Ref<Cell> prev, Ref<CellSlice> action) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_out_list& data) const;
  bool cell_pack_out_list(Ref<vm::Cell>& cell_ref, Ref<Cell> prev, Ref<CellSlice> action) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(OutList " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct OutList::Record_out_list {
  typedef OutList type_class;
  unsigned n;  	// n : #
  Ref<Cell> prev;  	// prev : ^(OutList n)
  Ref<CellSlice> action;  	// action : OutAction
};

//
// headers for type `LibRef`
//

struct LibRef final : TLB_Complex {
  enum { libref_hash, libref_ref };
  static constexpr int cons_len_exact = 1;
  struct Record_libref_hash {
    typedef LibRef type_class;
    td::BitArray<256> lib_hash;  	// lib_hash : bits256
  };
  struct Record_libref_ref {
    typedef LibRef type_class;
    Ref<Cell> library;  	// library : ^Cell
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_libref_hash& data) const;
  bool unpack_libref_hash(vm::CellSlice& cs, td::BitArray<256>& lib_hash) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_libref_hash& data) const;
  bool cell_unpack_libref_hash(Ref<vm::Cell> cell_ref, td::BitArray<256>& lib_hash) const;
  bool pack(vm::CellBuilder& cb, const Record_libref_hash& data) const;
  bool pack_libref_hash(vm::CellBuilder& cb, td::BitArray<256> lib_hash) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_libref_hash& data) const;
  bool cell_pack_libref_hash(Ref<vm::Cell>& cell_ref, td::BitArray<256> lib_hash) const;
  bool unpack(vm::CellSlice& cs, Record_libref_ref& data) const;
  bool unpack_libref_ref(vm::CellSlice& cs, Ref<Cell>& library) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_libref_ref& data) const;
  bool cell_unpack_libref_ref(Ref<vm::Cell> cell_ref, Ref<Cell>& library) const;
  bool pack(vm::CellBuilder& cb, const Record_libref_ref& data) const;
  bool pack_libref_ref(vm::CellBuilder& cb, Ref<Cell> library) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_libref_ref& data) const;
  bool cell_pack_libref_ref(Ref<vm::Cell>& cell_ref, Ref<Cell> library) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "LibRef";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

extern const LibRef t_LibRef;

//
// headers for type `OutAction`
//

struct OutAction final : TLB_Complex {
  enum { action_send_msg, action_change_library, action_reserve_currency, action_create_account, action_set_code };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[5] = { 0xec3c86d, 0x26fa1dd4, 0x36e6b809, 0x4a435241, 0xad4de08eU };
  struct Record_action_send_msg {
    typedef OutAction type_class;
    unsigned mode;  	// mode : ## 8
    Ref<Cell> out_msg;  	// out_msg : ^(MessageRelaxed Any)
  };
  struct Record_action_set_code {
    typedef OutAction type_class;
    Ref<Cell> new_code;  	// new_code : ^Cell
  };
  struct Record_action_reserve_currency {
    typedef OutAction type_class;
    unsigned mode;  	// mode : ## 8
    Ref<CellSlice> currency;  	// currency : CurrencyCollection
  };
  struct Record_action_change_library {
    typedef OutAction type_class;
    unsigned mode;  	// mode : ## 7
    Ref<CellSlice> libref;  	// libref : LibRef
  };
  struct Record_action_create_account;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_action_send_msg& data) const;
  bool unpack_action_send_msg(vm::CellSlice& cs, unsigned& mode, Ref<Cell>& out_msg) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_action_send_msg& data) const;
  bool cell_unpack_action_send_msg(Ref<vm::Cell> cell_ref, unsigned& mode, Ref<Cell>& out_msg) const;
  bool pack(vm::CellBuilder& cb, const Record_action_send_msg& data) const;
  bool pack_action_send_msg(vm::CellBuilder& cb, unsigned mode, Ref<Cell> out_msg) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_action_send_msg& data) const;
  bool cell_pack_action_send_msg(Ref<vm::Cell>& cell_ref, unsigned mode, Ref<Cell> out_msg) const;
  bool unpack(vm::CellSlice& cs, Record_action_set_code& data) const;
  bool unpack_action_set_code(vm::CellSlice& cs, Ref<Cell>& new_code) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_action_set_code& data) const;
  bool cell_unpack_action_set_code(Ref<vm::Cell> cell_ref, Ref<Cell>& new_code) const;
  bool pack(vm::CellBuilder& cb, const Record_action_set_code& data) const;
  bool pack_action_set_code(vm::CellBuilder& cb, Ref<Cell> new_code) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_action_set_code& data) const;
  bool cell_pack_action_set_code(Ref<vm::Cell>& cell_ref, Ref<Cell> new_code) const;
  bool unpack(vm::CellSlice& cs, Record_action_reserve_currency& data) const;
  bool unpack_action_reserve_currency(vm::CellSlice& cs, unsigned& mode, Ref<CellSlice>& currency) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_action_reserve_currency& data) const;
  bool cell_unpack_action_reserve_currency(Ref<vm::Cell> cell_ref, unsigned& mode, Ref<CellSlice>& currency) const;
  bool pack(vm::CellBuilder& cb, const Record_action_reserve_currency& data) const;
  bool pack_action_reserve_currency(vm::CellBuilder& cb, unsigned mode, Ref<CellSlice> currency) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_action_reserve_currency& data) const;
  bool cell_pack_action_reserve_currency(Ref<vm::Cell>& cell_ref, unsigned mode, Ref<CellSlice> currency) const;
  bool unpack(vm::CellSlice& cs, Record_action_change_library& data) const;
  bool unpack_action_change_library(vm::CellSlice& cs, unsigned& mode, Ref<CellSlice>& libref) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_action_change_library& data) const;
  bool cell_unpack_action_change_library(Ref<vm::Cell> cell_ref, unsigned& mode, Ref<CellSlice>& libref) const;
  bool pack(vm::CellBuilder& cb, const Record_action_change_library& data) const;
  bool pack_action_change_library(vm::CellBuilder& cb, unsigned mode, Ref<CellSlice> libref) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_action_change_library& data) const;
  bool cell_pack_action_change_library(Ref<vm::Cell>& cell_ref, unsigned mode, Ref<CellSlice> libref) const;
  bool unpack(vm::CellSlice& cs, Record_action_create_account& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_action_create_account& data) const;
  bool pack(vm::CellBuilder& cb, const Record_action_create_account& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_action_create_account& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "OutAction";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(4, 0x41d);
  }
};

struct OutAction::Record_action_create_account {
  typedef OutAction type_class;
  unsigned mode;  	// mode : ## 8
  td::BitArray<256> dest_addr;  	// dest_addr : bits256
  Ref<Cell> state_init;  	// state_init : ^StateInit
  Ref<CellSlice> value;  	// value : Tomis
  Ref<CellSlice> body;  	// body : Maybe ^Cell
};

extern const OutAction t_OutAction;

//
// headers for type `OutListNode`
//

struct OutListNode final : TLB_Complex {
  enum { out_list_node };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef OutListNode type_class;
    Ref<Cell> prev;  	// prev : ^Cell
    Ref<CellSlice> action;  	// action : OutAction
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_out_list_node(vm::CellSlice& cs, Ref<Cell>& prev, Ref<CellSlice>& action) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_out_list_node(Ref<vm::Cell> cell_ref, Ref<Cell>& prev, Ref<CellSlice>& action) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_out_list_node(vm::CellBuilder& cb, Ref<Cell> prev, Ref<CellSlice> action) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_out_list_node(Ref<vm::Cell>& cell_ref, Ref<Cell> prev, Ref<CellSlice> action) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "OutListNode";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const OutListNode t_OutListNode;

//
// headers for type `ShardIdent`
//

struct ShardIdent final : TLB_Complex {
  enum { shard_ident };
  static constexpr int cons_len_exact = 2;
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 104;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(104);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_shard_ident(vm::CellSlice& cs, unsigned& shard_pfx_bits, int& workchain_id, unsigned long long& shard_prefix) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_shard_ident(Ref<vm::Cell> cell_ref, unsigned& shard_pfx_bits, int& workchain_id, unsigned long long& shard_prefix) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_shard_ident(vm::CellBuilder& cb, unsigned shard_pfx_bits, int workchain_id, unsigned long long shard_prefix) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_shard_ident(Ref<vm::Cell>& cell_ref, unsigned shard_pfx_bits, int workchain_id, unsigned long long shard_prefix) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ShardIdent";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ShardIdent::Record {
  typedef ShardIdent type_class;
  unsigned shard_pfx_bits;  	// shard_pfx_bits : #<= 60
  int workchain_id;  	// workchain_id : int32
  unsigned long long shard_prefix;  	// shard_prefix : uint64
};

extern const ShardIdent t_ShardIdent;

//
// headers for type `ExtBlkRef`
//

struct ExtBlkRef final : TLB_Complex {
  enum { ext_blk_ref };
  static constexpr int cons_len_exact = 0;
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 608;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(608);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(608);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ExtBlkRef";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ExtBlkRef::Record {
  typedef ExtBlkRef type_class;
  unsigned long long end_lt;  	// end_lt : uint64
  unsigned seq_no;  	// seq_no : uint32
  td::BitArray<256> root_hash;  	// root_hash : bits256
  td::BitArray<256> file_hash;  	// file_hash : bits256
};

extern const ExtBlkRef t_ExtBlkRef;

//
// headers for type `BlockIdExt`
//

struct BlockIdExt final : TLB_Complex {
  enum { block_id_ext };
  static constexpr int cons_len_exact = 0;
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 648;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(648);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BlockIdExt";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct BlockIdExt::Record {
  typedef BlockIdExt type_class;
  Ref<CellSlice> shard_id;  	// shard_id : ShardIdent
  unsigned seq_no;  	// seq_no : uint32
  td::BitArray<256> root_hash;  	// root_hash : bits256
  td::BitArray<256> file_hash;  	// file_hash : bits256
};

extern const BlockIdExt t_BlockIdExt;

//
// headers for type `BlkMasterInfo`
//

struct BlkMasterInfo final : TLB_Complex {
  enum { master_info };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef BlkMasterInfo type_class;
    Ref<CellSlice> master;  	// master : ExtBlkRef
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 608;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(608);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(608);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_master_info(vm::CellSlice& cs, Ref<CellSlice>& master) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_master_info(Ref<vm::Cell> cell_ref, Ref<CellSlice>& master) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_master_info(vm::CellBuilder& cb, Ref<CellSlice> master) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_master_info(Ref<vm::Cell>& cell_ref, Ref<CellSlice> master) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BlkMasterInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const BlkMasterInfo t_BlkMasterInfo;

//
// headers for auxiliary type `ShardStateUnsplit_aux`
//

struct ShardStateUnsplit_aux final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ShardStateUnsplit_aux";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ShardStateUnsplit_aux::Record {
  typedef ShardStateUnsplit_aux type_class;
  unsigned long long overload_history;  	// overload_history : uint64
  unsigned long long underload_history;  	// underload_history : uint64
  Ref<CellSlice> total_balance;  	// total_balance : CurrencyCollection
  Ref<CellSlice> total_validator_fees;  	// total_validator_fees : CurrencyCollection
  Ref<CellSlice> libraries;  	// libraries : HashmapE 256 LibDescr
  Ref<CellSlice> master_ref;  	// master_ref : Maybe BlkMasterInfo
};

extern const ShardStateUnsplit_aux t_ShardStateUnsplit_aux;

//
// headers for type `ShardStateUnsplit`
//

struct ShardStateUnsplit final : TLB_Complex {
  enum { shard_state };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x9023afe2U };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ShardStateUnsplit";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ShardStateUnsplit::Record {
  typedef ShardStateUnsplit type_class;
  int global_id;  	// global_id : int32
  Ref<CellSlice> shard_id;  	// shard_id : ShardIdent
  unsigned seq_no;  	// seq_no : uint32
  unsigned vert_seq_no;  	// vert_seq_no : #
  unsigned gen_utime;  	// gen_utime : uint32
  unsigned long long gen_lt;  	// gen_lt : uint64
  unsigned min_ref_mc_seqno;  	// min_ref_mc_seqno : uint32
  Ref<Cell> out_msg_queue_info;  	// out_msg_queue_info : ^OutMsgQueueInfo
  bool before_split;  	// before_split : ## 1
  Ref<Cell> accounts;  	// accounts : ^ShardAccounts
  ShardStateUnsplit_aux::Record r1;  	// ^[$_ overload_history:uint64 underload_history:uint64 total_balance:CurrencyCollection total_validator_fees:CurrencyCollection libraries:(HashmapE 256 LibDescr) master_ref:(Maybe BlkMasterInfo) ]
  Ref<CellSlice> custom;  	// custom : Maybe ^McStateExtra
};

extern const ShardStateUnsplit t_ShardStateUnsplit;

//
// headers for type `ShardState`
//

struct ShardState final : TLB_Complex {
  enum { split_state, cons1 };
  static constexpr char cons_len[2] = { 32, 0 };
  static constexpr unsigned cons_tag[2] = { 0x5f327da5, 0 };
  struct Record_cons1 {
    typedef ShardState type_class;
    Ref<CellSlice> x;  	// ShardStateUnsplit
  };
  struct Record_split_state {
    typedef ShardState type_class;
    Ref<Cell> left;  	// left : ^ShardStateUnsplit
    Ref<Cell> right;  	// right : ^ShardStateUnsplit
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_cons1& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons1& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons1& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons1& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_split_state& data) const;
  bool unpack_split_state(vm::CellSlice& cs, Ref<Cell>& left, Ref<Cell>& right) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_split_state& data) const;
  bool cell_unpack_split_state(Ref<vm::Cell> cell_ref, Ref<Cell>& left, Ref<Cell>& right) const;
  bool pack(vm::CellBuilder& cb, const Record_split_state& data) const;
  bool pack_split_state(vm::CellBuilder& cb, Ref<Cell> left, Ref<Cell> right) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_split_state& data) const;
  bool cell_pack_split_state(Ref<vm::Cell>& cell_ref, Ref<Cell> left, Ref<Cell> right) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ShardState";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

extern const ShardState t_ShardState;

//
// headers for type `LibDescr`
//

struct LibDescr final : TLB_Complex {
  enum { shared_lib_descr };
  static constexpr int cons_len_exact = 2;
  struct Record {
    typedef LibDescr type_class;
    Ref<Cell> lib;  	// lib : ^Cell
    Ref<CellSlice> publishers;  	// publishers : Hashmap 256 True
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_shared_lib_descr(vm::CellSlice& cs, Ref<Cell>& lib, Ref<CellSlice>& publishers) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_shared_lib_descr(Ref<vm::Cell> cell_ref, Ref<Cell>& lib, Ref<CellSlice>& publishers) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_shared_lib_descr(vm::CellBuilder& cb, Ref<Cell> lib, Ref<CellSlice> publishers) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_shared_lib_descr(Ref<vm::Cell>& cell_ref, Ref<Cell> lib, Ref<CellSlice> publishers) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "LibDescr";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const LibDescr t_LibDescr;

//
// headers for type `BlockInfo`
//

struct BlockInfo final : TLB_Complex {
  enum { block_info };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x9bc7a987U };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BlockInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct BlockInfo::Record {
  typedef BlockInfo type_class;
  unsigned version;  	// version : uint32
  bool not_master;  	// not_master : ## 1
  bool after_merge;  	// after_merge : ## 1
  bool before_split;  	// before_split : ## 1
  bool after_split;  	// after_split : ## 1
  bool want_split;  	// want_split : Bool
  bool want_merge;  	// want_merge : Bool
  bool key_block;  	// key_block : Bool
  bool vert_seqno_incr;  	// vert_seqno_incr : ## 1
  unsigned flags;  	// flags : ## 8
  unsigned seq_no;  	// seq_no : #
  unsigned vert_seq_no;  	// vert_seq_no : #
  Ref<CellSlice> shard;  	// shard : ShardIdent
  unsigned gen_utime;  	// gen_utime : uint32
  unsigned long long start_lt;  	// start_lt : uint64
  unsigned long long end_lt;  	// end_lt : uint64
  unsigned gen_validator_list_hash_short;  	// gen_validator_list_hash_short : uint32
  unsigned gen_catchain_seqno;  	// gen_catchain_seqno : uint32
  unsigned min_ref_mc_seqno;  	// min_ref_mc_seqno : uint32
  unsigned prev_key_block_seqno;  	// prev_key_block_seqno : uint32
  Ref<CellSlice> gen_software;  	// gen_software : flags.0?GlobalVersion
  Ref<Cell> master_ref;  	// master_ref : not_master?^BlkMasterInfo
  Ref<Cell> prev_ref;  	// prev_ref : ^(BlkPrevInfo after_merge)
  Ref<Cell> prev_vert_ref;  	// prev_vert_ref : vert_seqno_incr?^(BlkPrevInfo 0)
};

extern const BlockInfo t_BlockInfo;

//
// headers for type `BlkPrevInfo`
//

struct BlkPrevInfo final : TLB_Complex {
  enum { prev_blk_info, prev_blks_info };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  BlkPrevInfo(unsigned m) : m_(m) {}
  struct Record_prev_blk_info {
    typedef BlkPrevInfo type_class;
    Ref<CellSlice> prev;  	// prev : ExtBlkRef
  };
  struct Record_prev_blks_info {
    typedef BlkPrevInfo type_class;
    Ref<Cell> prev1;  	// prev1 : ^ExtBlkRef
    Ref<Cell> prev2;  	// prev2 : ^ExtBlkRef
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_prev_blk_info& data) const;
  bool unpack_prev_blk_info(vm::CellSlice& cs, Ref<CellSlice>& prev) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_prev_blk_info& data) const;
  bool cell_unpack_prev_blk_info(Ref<vm::Cell> cell_ref, Ref<CellSlice>& prev) const;
  bool pack(vm::CellBuilder& cb, const Record_prev_blk_info& data) const;
  bool pack_prev_blk_info(vm::CellBuilder& cb, Ref<CellSlice> prev) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_prev_blk_info& data) const;
  bool cell_pack_prev_blk_info(Ref<vm::Cell>& cell_ref, Ref<CellSlice> prev) const;
  bool unpack(vm::CellSlice& cs, Record_prev_blks_info& data) const;
  bool unpack_prev_blks_info(vm::CellSlice& cs, Ref<Cell>& prev1, Ref<Cell>& prev2) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_prev_blks_info& data) const;
  bool cell_unpack_prev_blks_info(Ref<vm::Cell> cell_ref, Ref<Cell>& prev1, Ref<Cell>& prev2) const;
  bool pack(vm::CellBuilder& cb, const Record_prev_blks_info& data) const;
  bool pack_prev_blks_info(vm::CellBuilder& cb, Ref<Cell> prev1, Ref<Cell> prev2) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_prev_blks_info& data) const;
  bool cell_pack_prev_blks_info(Ref<vm::Cell>& cell_ref, Ref<Cell> prev1, Ref<Cell> prev2) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(BlkPrevInfo " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

//
// headers for type `Block`
//

struct Block final : TLB_Complex {
  enum { block };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x11ef55aa };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 0x40040;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x40040);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Block";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct Block::Record {
  typedef Block type_class;
  int global_id;  	// global_id : int32
  Ref<Cell> info;  	// info : ^BlockInfo
  Ref<Cell> value_flow;  	// value_flow : ^ValueFlow
  Ref<Cell> state_update;  	// state_update : ^(MERKLE_UPDATE ShardState)
  Ref<Cell> extra;  	// extra : ^BlockExtra
};

extern const Block t_Block;

//
// headers for type `BlockExtra`
//

struct BlockExtra final : TLB_Complex {
  enum { block_extra };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x4a33f6fd };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BlockExtra";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct BlockExtra::Record {
  typedef BlockExtra type_class;
  Ref<Cell> in_msg_descr;  	// in_msg_descr : ^InMsgDescr
  Ref<Cell> out_msg_descr;  	// out_msg_descr : ^OutMsgDescr
  Ref<Cell> account_blocks;  	// account_blocks : ^ShardAccountBlocks
  td::BitArray<256> rand_seed;  	// rand_seed : bits256
  td::BitArray<256> created_by;  	// created_by : bits256
  Ref<CellSlice> custom;  	// custom : Maybe ^McBlockExtra
};

extern const BlockExtra t_BlockExtra;

//
// headers for auxiliary type `TYPE_1693`
//

struct TYPE_1693 final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "TYPE_1693";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct TYPE_1693::Record {
  typedef TYPE_1693 type_class;
  Ref<CellSlice> from_prev_blk;  	// from_prev_blk : CurrencyCollection
  Ref<CellSlice> to_next_blk;  	// to_next_blk : CurrencyCollection
  Ref<CellSlice> imported;  	// imported : CurrencyCollection
  Ref<CellSlice> exported;  	// exported : CurrencyCollection
};

extern const TYPE_1693 t_TYPE_1693;

//
// headers for auxiliary type `TYPE_1694`
//

struct TYPE_1694 final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "TYPE_1694";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct TYPE_1694::Record {
  typedef TYPE_1694 type_class;
  Ref<CellSlice> fees_imported;  	// fees_imported : CurrencyCollection
  Ref<CellSlice> recovered;  	// recovered : CurrencyCollection
  Ref<CellSlice> created;  	// created : CurrencyCollection
  Ref<CellSlice> minted;  	// minted : CurrencyCollection
};

extern const TYPE_1694 t_TYPE_1694;

//
// headers for type `ValueFlow`
//

struct ValueFlow final : TLB_Complex {
  enum { value_flow_v2, value_flow };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[2] = { 0x3ebf98b7, 0xb8e48dfbU };
  struct Record_value_flow;
  struct Record_value_flow_v2;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_value_flow& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_value_flow& data) const;
  bool pack(vm::CellBuilder& cb, const Record_value_flow& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_value_flow& data) const;
  bool unpack(vm::CellSlice& cs, Record_value_flow_v2& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_value_flow_v2& data) const;
  bool pack(vm::CellBuilder& cb, const Record_value_flow_v2& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_value_flow_v2& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ValueFlow";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

struct ValueFlow::Record_value_flow {
  typedef ValueFlow type_class;
  TYPE_1693::Record r1;  	// ^[$_ from_prev_blk:CurrencyCollection to_next_blk:CurrencyCollection imported:CurrencyCollection exported:CurrencyCollection ]
  Ref<CellSlice> fees_collected;  	// fees_collected : CurrencyCollection
  TYPE_1694::Record r2;  	// ^[$_ fees_imported:CurrencyCollection recovered:CurrencyCollection created:CurrencyCollection minted:CurrencyCollection ]
};

struct ValueFlow::Record_value_flow_v2 {
  typedef ValueFlow type_class;
  TYPE_1693::Record r1;  	// ^[$_ from_prev_blk:CurrencyCollection to_next_blk:CurrencyCollection imported:CurrencyCollection exported:CurrencyCollection ]
  Ref<CellSlice> fees_collected;  	// fees_collected : CurrencyCollection
  Ref<CellSlice> burned;  	// burned : CurrencyCollection
  TYPE_1694::Record r2;  	// ^[$_ fees_imported:CurrencyCollection recovered:CurrencyCollection created:CurrencyCollection minted:CurrencyCollection ]
};

extern const ValueFlow t_ValueFlow;

//
// headers for type `BinTree`
//

struct BinTree final : TLB_Complex {
  enum { bt_leaf, bt_fork };
  static constexpr int cons_len_exact = 1;
  const TLB &X_;
  BinTree(const TLB& X) : X_(X) {}
  struct Record_bt_leaf {
    typedef BinTree type_class;
    Ref<CellSlice> leaf;  	// leaf : X
  };
  struct Record_bt_fork {
    typedef BinTree type_class;
    Ref<Cell> left;  	// left : ^(BinTree X)
    Ref<Cell> right;  	// right : ^(BinTree X)
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_bt_leaf& data) const;
  bool unpack_bt_leaf(vm::CellSlice& cs, Ref<CellSlice>& leaf) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_bt_leaf& data) const;
  bool cell_unpack_bt_leaf(Ref<vm::Cell> cell_ref, Ref<CellSlice>& leaf) const;
  bool pack(vm::CellBuilder& cb, const Record_bt_leaf& data) const;
  bool pack_bt_leaf(vm::CellBuilder& cb, Ref<CellSlice> leaf) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_bt_leaf& data) const;
  bool cell_pack_bt_leaf(Ref<vm::Cell>& cell_ref, Ref<CellSlice> leaf) const;
  bool unpack(vm::CellSlice& cs, Record_bt_fork& data) const;
  bool unpack_bt_fork(vm::CellSlice& cs, Ref<Cell>& left, Ref<Cell>& right) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_bt_fork& data) const;
  bool cell_unpack_bt_fork(Ref<vm::Cell> cell_ref, Ref<Cell>& left, Ref<Cell>& right) const;
  bool pack(vm::CellBuilder& cb, const Record_bt_fork& data) const;
  bool pack_bt_fork(vm::CellBuilder& cb, Ref<Cell> left, Ref<Cell> right) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_bt_fork& data) const;
  bool cell_pack_bt_fork(Ref<vm::Cell>& cell_ref, Ref<Cell> left, Ref<Cell> right) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(BinTree " << X_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

//
// headers for type `FutureSplitMerge`
//

struct FutureSplitMerge final : TLB_Complex {
  enum { fsm_none, fsm_split, fsm_merge };
  static constexpr char cons_len[3] = { 1, 2, 2 };
  static constexpr unsigned char cons_tag[3] = { 0, 2, 3 };
  struct Record_fsm_none {
    typedef FutureSplitMerge type_class;
  };
  struct Record_fsm_split {
    typedef FutureSplitMerge type_class;
    unsigned split_utime;  	// split_utime : uint32
    unsigned interval;  	// interval : uint32
  };
  struct Record_fsm_merge {
    typedef FutureSplitMerge type_class;
    unsigned merge_utime;  	// merge_utime : uint32
    unsigned interval;  	// interval : uint32
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_fsm_none& data) const;
  bool unpack_fsm_none(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_fsm_none& data) const;
  bool cell_unpack_fsm_none(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_fsm_none& data) const;
  bool pack_fsm_none(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_fsm_none& data) const;
  bool cell_pack_fsm_none(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_fsm_split& data) const;
  bool unpack_fsm_split(vm::CellSlice& cs, unsigned& split_utime, unsigned& interval) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_fsm_split& data) const;
  bool cell_unpack_fsm_split(Ref<vm::Cell> cell_ref, unsigned& split_utime, unsigned& interval) const;
  bool pack(vm::CellBuilder& cb, const Record_fsm_split& data) const;
  bool pack_fsm_split(vm::CellBuilder& cb, unsigned split_utime, unsigned interval) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_fsm_split& data) const;
  bool cell_pack_fsm_split(Ref<vm::Cell>& cell_ref, unsigned split_utime, unsigned interval) const;
  bool unpack(vm::CellSlice& cs, Record_fsm_merge& data) const;
  bool unpack_fsm_merge(vm::CellSlice& cs, unsigned& merge_utime, unsigned& interval) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_fsm_merge& data) const;
  bool cell_unpack_fsm_merge(Ref<vm::Cell> cell_ref, unsigned& merge_utime, unsigned& interval) const;
  bool pack(vm::CellBuilder& cb, const Record_fsm_merge& data) const;
  bool pack_fsm_merge(vm::CellBuilder& cb, unsigned merge_utime, unsigned interval) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_fsm_merge& data) const;
  bool cell_pack_fsm_merge(Ref<vm::Cell>& cell_ref, unsigned merge_utime, unsigned interval) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "FutureSplitMerge";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect_ext(2, 13);
  }
};

extern const FutureSplitMerge t_FutureSplitMerge;

//
// headers for auxiliary type `ShardDescr_aux`
//

struct ShardDescr_aux final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ShardDescr_aux type_class;
    Ref<CellSlice> fees_collected;  	// fees_collected : CurrencyCollection
    Ref<CellSlice> funds_created;  	// funds_created : CurrencyCollection
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& fees_collected, Ref<CellSlice>& funds_created) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& fees_collected, Ref<CellSlice>& funds_created) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> fees_collected, Ref<CellSlice> funds_created) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> fees_collected, Ref<CellSlice> funds_created) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ShardDescr_aux";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ShardDescr_aux t_ShardDescr_aux;

//
// headers for type `ShardDescr`
//

struct ShardDescr final : TLB_Complex {
  enum { shard_descr_new, shard_descr };
  static constexpr int cons_len_exact = 4;
  static constexpr unsigned char cons_tag[2] = { 10, 11 };
  struct Record_shard_descr;
  struct Record_shard_descr_new;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_shard_descr& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_shard_descr& data) const;
  bool pack(vm::CellBuilder& cb, const Record_shard_descr& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_shard_descr& data) const;
  bool unpack(vm::CellSlice& cs, Record_shard_descr_new& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_shard_descr_new& data) const;
  bool pack(vm::CellBuilder& cb, const Record_shard_descr_new& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_shard_descr_new& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ShardDescr";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(4, 0xc00);
  }
};

struct ShardDescr::Record_shard_descr {
  typedef ShardDescr type_class;
  unsigned seq_no;  	// seq_no : uint32
  unsigned reg_mc_seqno;  	// reg_mc_seqno : uint32
  unsigned long long start_lt;  	// start_lt : uint64
  unsigned long long end_lt;  	// end_lt : uint64
  td::BitArray<256> root_hash;  	// root_hash : bits256
  td::BitArray<256> file_hash;  	// file_hash : bits256
  bool before_split;  	// before_split : Bool
  bool before_merge;  	// before_merge : Bool
  bool want_split;  	// want_split : Bool
  bool want_merge;  	// want_merge : Bool
  bool nx_cc_updated;  	// nx_cc_updated : Bool
  unsigned flags;  	// flags : ## 3
  unsigned next_catchain_seqno;  	// next_catchain_seqno : uint32
  unsigned long long next_validator_shard;  	// next_validator_shard : uint64
  unsigned min_ref_mc_seqno;  	// min_ref_mc_seqno : uint32
  unsigned gen_utime;  	// gen_utime : uint32
  Ref<CellSlice> split_merge_at;  	// split_merge_at : FutureSplitMerge
  Ref<CellSlice> fees_collected;  	// fees_collected : CurrencyCollection
  Ref<CellSlice> funds_created;  	// funds_created : CurrencyCollection
};

struct ShardDescr::Record_shard_descr_new {
  typedef ShardDescr type_class;
  unsigned seq_no;  	// seq_no : uint32
  unsigned reg_mc_seqno;  	// reg_mc_seqno : uint32
  unsigned long long start_lt;  	// start_lt : uint64
  unsigned long long end_lt;  	// end_lt : uint64
  td::BitArray<256> root_hash;  	// root_hash : bits256
  td::BitArray<256> file_hash;  	// file_hash : bits256
  bool before_split;  	// before_split : Bool
  bool before_merge;  	// before_merge : Bool
  bool want_split;  	// want_split : Bool
  bool want_merge;  	// want_merge : Bool
  bool nx_cc_updated;  	// nx_cc_updated : Bool
  unsigned flags;  	// flags : ## 3
  unsigned next_catchain_seqno;  	// next_catchain_seqno : uint32
  unsigned long long next_validator_shard;  	// next_validator_shard : uint64
  unsigned min_ref_mc_seqno;  	// min_ref_mc_seqno : uint32
  unsigned gen_utime;  	// gen_utime : uint32
  Ref<CellSlice> split_merge_at;  	// split_merge_at : FutureSplitMerge
  ShardDescr_aux::Record r1;  	// ^[$_ fees_collected:CurrencyCollection funds_created:CurrencyCollection ]
};

extern const ShardDescr t_ShardDescr;

//
// headers for type `ShardHashes`
//

struct ShardHashes final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ShardHashes type_class;
    Ref<CellSlice> x;  	// HashmapE 32 ^(BinTree ShardDescr)
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ShardHashes";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ShardHashes t_ShardHashes;

//
// headers for type `BinTreeAug`
//

struct BinTreeAug final : TLB_Complex {
  enum { bta_leaf, bta_fork };
  static constexpr int cons_len_exact = 1;
  const TLB &X_, &Y_;
  BinTreeAug(const TLB& X, const TLB& Y) : X_(X), Y_(Y) {}
  struct Record_bta_leaf {
    typedef BinTreeAug type_class;
    Ref<CellSlice> extra;  	// extra : Y
    Ref<CellSlice> leaf;  	// leaf : X
  };
  struct Record_bta_fork;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_bta_leaf& data) const;
  bool unpack_bta_leaf(vm::CellSlice& cs, Ref<CellSlice>& extra, Ref<CellSlice>& leaf) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_bta_leaf& data) const;
  bool cell_unpack_bta_leaf(Ref<vm::Cell> cell_ref, Ref<CellSlice>& extra, Ref<CellSlice>& leaf) const;
  bool pack(vm::CellBuilder& cb, const Record_bta_leaf& data) const;
  bool pack_bta_leaf(vm::CellBuilder& cb, Ref<CellSlice> extra, Ref<CellSlice> leaf) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_bta_leaf& data) const;
  bool cell_pack_bta_leaf(Ref<vm::Cell>& cell_ref, Ref<CellSlice> extra, Ref<CellSlice> leaf) const;
  bool unpack(vm::CellSlice& cs, Record_bta_fork& data) const;
  bool unpack_bta_fork(vm::CellSlice& cs, Ref<Cell>& left, Ref<Cell>& right, Ref<CellSlice>& extra) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_bta_fork& data) const;
  bool cell_unpack_bta_fork(Ref<vm::Cell> cell_ref, Ref<Cell>& left, Ref<Cell>& right, Ref<CellSlice>& extra) const;
  bool pack(vm::CellBuilder& cb, const Record_bta_fork& data) const;
  bool pack_bta_fork(vm::CellBuilder& cb, Ref<Cell> left, Ref<Cell> right, Ref<CellSlice> extra) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_bta_fork& data) const;
  bool cell_pack_bta_fork(Ref<vm::Cell>& cell_ref, Ref<Cell> left, Ref<Cell> right, Ref<CellSlice> extra) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(BinTreeAug " << X_ << " " << Y_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

struct BinTreeAug::Record_bta_fork {
  typedef BinTreeAug type_class;
  Ref<Cell> left;  	// left : ^(BinTreeAug X Y)
  Ref<Cell> right;  	// right : ^(BinTreeAug X Y)
  Ref<CellSlice> extra;  	// extra : Y
};

//
// headers for type `ShardFeeCreated`
//

struct ShardFeeCreated final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ShardFeeCreated type_class;
    Ref<CellSlice> fees;  	// fees : CurrencyCollection
    Ref<CellSlice> create;  	// create : CurrencyCollection
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& fees, Ref<CellSlice>& create) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& fees, Ref<CellSlice>& create) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> fees, Ref<CellSlice> create) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> fees, Ref<CellSlice> create) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ShardFeeCreated";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ShardFeeCreated t_ShardFeeCreated;

//
// headers for type `ShardFees`
//

struct ShardFees final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ShardFees type_class;
    Ref<CellSlice> x;  	// HashmapAugE 96 ShardFeeCreated ShardFeeCreated
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ShardFees";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ShardFees t_ShardFees;

//
// headers for type `ConfigParams`
//

struct ConfigParams final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ConfigParams type_class;
    td::BitArray<256> config_addr;  	// config_addr : bits256
    Ref<Cell> config;  	// config : ^(Hashmap 32 ^Cell)
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 0x10100;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x10100);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, td::BitArray<256>& config_addr, Ref<Cell>& config) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, td::BitArray<256>& config_addr, Ref<Cell>& config) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, td::BitArray<256> config_addr, Ref<Cell> config) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, td::BitArray<256> config_addr, Ref<Cell> config) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ConfigParams";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ConfigParams t_ConfigParams;

//
// headers for type `ValidatorInfo`
//

struct ValidatorInfo final : TLB_Complex {
  enum { validator_info };
  static constexpr int cons_len_exact = 0;
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 65;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(65);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(65);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_validator_info(vm::CellSlice& cs, unsigned& validator_list_hash_short, unsigned& catchain_seqno, bool& nx_cc_updated) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_validator_info(Ref<vm::Cell> cell_ref, unsigned& validator_list_hash_short, unsigned& catchain_seqno, bool& nx_cc_updated) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_validator_info(vm::CellBuilder& cb, unsigned validator_list_hash_short, unsigned catchain_seqno, bool nx_cc_updated) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_validator_info(Ref<vm::Cell>& cell_ref, unsigned validator_list_hash_short, unsigned catchain_seqno, bool nx_cc_updated) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ValidatorInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ValidatorInfo::Record {
  typedef ValidatorInfo type_class;
  unsigned validator_list_hash_short;  	// validator_list_hash_short : uint32
  unsigned catchain_seqno;  	// catchain_seqno : uint32
  bool nx_cc_updated;  	// nx_cc_updated : Bool
};

extern const ValidatorInfo t_ValidatorInfo;

//
// headers for type `KeyMaxLt`
//

struct KeyMaxLt final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef KeyMaxLt type_class;
    bool key;  	// key : Bool
    unsigned long long max_end_lt;  	// max_end_lt : uint64
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 65;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(65);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(65);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, bool& key, unsigned long long& max_end_lt) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, bool& key, unsigned long long& max_end_lt) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, bool key, unsigned long long max_end_lt) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, bool key, unsigned long long max_end_lt) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "KeyMaxLt";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const KeyMaxLt t_KeyMaxLt;

//
// headers for type `KeyExtBlkRef`
//

struct KeyExtBlkRef final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef KeyExtBlkRef type_class;
    bool key;  	// key : Bool
    Ref<CellSlice> blk_ref;  	// blk_ref : ExtBlkRef
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 609;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(609);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(609);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, bool& key, Ref<CellSlice>& blk_ref) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, bool& key, Ref<CellSlice>& blk_ref) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, bool key, Ref<CellSlice> blk_ref) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, bool key, Ref<CellSlice> blk_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "KeyExtBlkRef";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const KeyExtBlkRef t_KeyExtBlkRef;

//
// headers for type `OldMcBlocksInfo`
//

struct OldMcBlocksInfo final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef OldMcBlocksInfo type_class;
    Ref<CellSlice> x;  	// HashmapAugE 32 KeyExtBlkRef KeyMaxLt
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "OldMcBlocksInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const OldMcBlocksInfo t_OldMcBlocksInfo;

//
// headers for type `Counters`
//

struct Counters final : TLB_Complex {
  enum { counters };
  static constexpr int cons_len_exact = 0;
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 224;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(224);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(224);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Counters";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct Counters::Record {
  typedef Counters type_class;
  unsigned last_updated;  	// last_updated : uint32
  unsigned long long total;  	// total : uint64
  unsigned long long cnt2048;  	// cnt2048 : uint64
  unsigned long long cnt65536;  	// cnt65536 : uint64
};

extern const Counters t_Counters;

//
// headers for type `CreatorStats`
//

struct CreatorStats final : TLB_Complex {
  enum { creator_info };
  static constexpr int cons_len_exact = 4;
  static constexpr unsigned char cons_tag[1] = { 4 };
  struct Record {
    typedef CreatorStats type_class;
    Ref<CellSlice> mc_blocks;  	// mc_blocks : Counters
    Ref<CellSlice> shard_blocks;  	// shard_blocks : Counters
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 452;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(452);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_creator_info(vm::CellSlice& cs, Ref<CellSlice>& mc_blocks, Ref<CellSlice>& shard_blocks) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_creator_info(Ref<vm::Cell> cell_ref, Ref<CellSlice>& mc_blocks, Ref<CellSlice>& shard_blocks) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_creator_info(vm::CellBuilder& cb, Ref<CellSlice> mc_blocks, Ref<CellSlice> shard_blocks) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_creator_info(Ref<vm::Cell>& cell_ref, Ref<CellSlice> mc_blocks, Ref<CellSlice> shard_blocks) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "CreatorStats";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const CreatorStats t_CreatorStats;

//
// headers for type `BlockCreateStats`
//

struct BlockCreateStats final : TLB_Complex {
  enum { block_create_stats, block_create_stats_ext };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[2] = { 23, 0x34 };
  struct Record_block_create_stats {
    typedef BlockCreateStats type_class;
    Ref<CellSlice> counters;  	// counters : HashmapE 256 CreatorStats
  };
  struct Record_block_create_stats_ext {
    typedef BlockCreateStats type_class;
    Ref<CellSlice> counters;  	// counters : HashmapAugE 256 CreatorStats uint32
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_block_create_stats& data) const;
  bool unpack_block_create_stats(vm::CellSlice& cs, Ref<CellSlice>& counters) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_block_create_stats& data) const;
  bool cell_unpack_block_create_stats(Ref<vm::Cell> cell_ref, Ref<CellSlice>& counters) const;
  bool pack(vm::CellBuilder& cb, const Record_block_create_stats& data) const;
  bool pack_block_create_stats(vm::CellBuilder& cb, Ref<CellSlice> counters) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_block_create_stats& data) const;
  bool cell_pack_block_create_stats(Ref<vm::Cell>& cell_ref, Ref<CellSlice> counters) const;
  bool unpack(vm::CellSlice& cs, Record_block_create_stats_ext& data) const;
  bool unpack_block_create_stats_ext(vm::CellSlice& cs, Ref<CellSlice>& counters) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_block_create_stats_ext& data) const;
  bool cell_unpack_block_create_stats_ext(Ref<vm::Cell> cell_ref, Ref<CellSlice>& counters) const;
  bool pack(vm::CellBuilder& cb, const Record_block_create_stats_ext& data) const;
  bool pack_block_create_stats_ext(vm::CellBuilder& cb, Ref<CellSlice> counters) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_block_create_stats_ext& data) const;
  bool cell_pack_block_create_stats_ext(Ref<vm::Cell>& cell_ref, Ref<CellSlice> counters) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BlockCreateStats";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(3, 3);
  }
};

extern const BlockCreateStats t_BlockCreateStats;

//
// headers for auxiliary type `McStateExtra_aux`
//

struct McStateExtra_aux final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "McStateExtra_aux";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct McStateExtra_aux::Record {
  typedef McStateExtra_aux type_class;
  unsigned flags;  	// flags : ## 16
  Ref<CellSlice> validator_info;  	// validator_info : ValidatorInfo
  Ref<CellSlice> prev_blocks;  	// prev_blocks : OldMcBlocksInfo
  bool after_key_block;  	// after_key_block : Bool
  Ref<CellSlice> last_key_block;  	// last_key_block : Maybe ExtBlkRef
  Ref<CellSlice> block_create_stats;  	// block_create_stats : flags.0?BlockCreateStats
  Ref<Cell> workchain_instances;  	// workchain_instances : ^WorkchainInstanceLedger
};

extern const McStateExtra_aux t_McStateExtra_aux;

//
// headers for type `McStateExtra`
//

struct McStateExtra final : TLB_Complex {
  enum { masterchain_state_extra_instances };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x3214e578 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "McStateExtra";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct McStateExtra::Record {
  typedef McStateExtra type_class;
  Ref<CellSlice> shard_hashes;  	// shard_hashes : ShardHashes
  Ref<CellSlice> config;  	// config : ConfigParams
  McStateExtra_aux::Record r1;  	// ^[$_ flags:(## 16) {<= flags 1} validator_info:ValidatorInfo prev_blocks:OldMcBlocksInfo after_key_block:Bool last_key_block:(Maybe ExtBlkRef) block_create_stats:flags.0?BlockCreateStats workchain_instances:^WorkchainInstanceLedger ]
  Ref<CellSlice> global_balance;  	// global_balance : CurrencyCollection
};

extern const McStateExtra t_McStateExtra;

//
// headers for type `SigPubKey`
//

struct SigPubKey final : TLB_Complex {
  enum { ed25519_pubkey };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x8e81278aU };
  struct Record {
    typedef SigPubKey type_class;
    td::BitArray<256> pubkey;  	// pubkey : bits256
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 288;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(288);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_ed25519_pubkey(vm::CellSlice& cs, td::BitArray<256>& pubkey) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_ed25519_pubkey(Ref<vm::Cell> cell_ref, td::BitArray<256>& pubkey) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_ed25519_pubkey(vm::CellBuilder& cb, td::BitArray<256> pubkey) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_ed25519_pubkey(Ref<vm::Cell>& cell_ref, td::BitArray<256> pubkey) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "SigPubKey";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const SigPubKey t_SigPubKey;

//
// headers for type `CryptoSignatureSimple`
//

struct CryptoSignatureSimple final : TLB_Complex {
  enum { ed25519_signature };
  static constexpr int cons_len_exact = 4;
  static constexpr unsigned char cons_tag[1] = { 5 };
  struct Record {
    typedef CryptoSignatureSimple type_class;
    td::BitArray<256> R;  	// R : bits256
    td::BitArray<256> s;  	// s : bits256
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 516;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(516);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_ed25519_signature(vm::CellSlice& cs, td::BitArray<256>& R, td::BitArray<256>& s) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_ed25519_signature(Ref<vm::Cell> cell_ref, td::BitArray<256>& R, td::BitArray<256>& s) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_ed25519_signature(vm::CellBuilder& cb, td::BitArray<256> R, td::BitArray<256> s) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_ed25519_signature(Ref<vm::Cell>& cell_ref, td::BitArray<256> R, td::BitArray<256> s) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "CryptoSignatureSimple";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const CryptoSignatureSimple t_CryptoSignatureSimple;

//
// headers for type `CryptoSignaturePair`
//

struct CryptoSignaturePair final : TLB_Complex {
  enum { sig_pair };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef CryptoSignaturePair type_class;
    td::BitArray<256> node_id_short;  	// node_id_short : bits256
    Ref<CellSlice> sign;  	// sign : CryptoSignature
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_sig_pair(vm::CellSlice& cs, td::BitArray<256>& node_id_short, Ref<CellSlice>& sign) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_sig_pair(Ref<vm::Cell> cell_ref, td::BitArray<256>& node_id_short, Ref<CellSlice>& sign) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_sig_pair(vm::CellBuilder& cb, td::BitArray<256> node_id_short, Ref<CellSlice> sign) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_sig_pair(Ref<vm::Cell>& cell_ref, td::BitArray<256> node_id_short, Ref<CellSlice> sign) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "CryptoSignaturePair";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const CryptoSignaturePair t_CryptoSignaturePair;

//
// headers for type `Certificate`
//

struct Certificate final : TLB_Complex {
  enum { certificate };
  static constexpr int cons_len_exact = 4;
  static constexpr unsigned char cons_tag[1] = { 4 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 356;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(356);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_certificate(vm::CellSlice& cs, Ref<CellSlice>& temp_key, unsigned& valid_since, unsigned& valid_until) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_certificate(Ref<vm::Cell> cell_ref, Ref<CellSlice>& temp_key, unsigned& valid_since, unsigned& valid_until) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_certificate(vm::CellBuilder& cb, Ref<CellSlice> temp_key, unsigned valid_since, unsigned valid_until) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_certificate(Ref<vm::Cell>& cell_ref, Ref<CellSlice> temp_key, unsigned valid_since, unsigned valid_until) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Certificate";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct Certificate::Record {
  typedef Certificate type_class;
  Ref<CellSlice> temp_key;  	// temp_key : SigPubKey
  unsigned valid_since;  	// valid_since : uint32
  unsigned valid_until;  	// valid_until : uint32
};

extern const Certificate t_Certificate;

//
// headers for type `CertificateEnv`
//

struct CertificateEnv final : TLB_Complex {
  enum { certificate_env };
  static constexpr int cons_len_exact = 28;
  static constexpr unsigned cons_tag[1] = { 0xa419b7d };
  struct Record {
    typedef CertificateEnv type_class;
    Ref<CellSlice> certificate;  	// certificate : Certificate
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 384;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(384);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_certificate_env(vm::CellSlice& cs, Ref<CellSlice>& certificate) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_certificate_env(Ref<vm::Cell> cell_ref, Ref<CellSlice>& certificate) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_certificate_env(vm::CellBuilder& cb, Ref<CellSlice> certificate) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_certificate_env(Ref<vm::Cell>& cell_ref, Ref<CellSlice> certificate) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "CertificateEnv";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const CertificateEnv t_CertificateEnv;

//
// headers for type `SignedCertificate`
//

struct SignedCertificate final : TLB_Complex {
  enum { signed_certificate };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef SignedCertificate type_class;
    Ref<CellSlice> certificate;  	// certificate : Certificate
    Ref<CellSlice> certificate_signature;  	// certificate_signature : CryptoSignature
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_signed_certificate(vm::CellSlice& cs, Ref<CellSlice>& certificate, Ref<CellSlice>& certificate_signature) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_signed_certificate(Ref<vm::Cell> cell_ref, Ref<CellSlice>& certificate, Ref<CellSlice>& certificate_signature) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_signed_certificate(vm::CellBuilder& cb, Ref<CellSlice> certificate, Ref<CellSlice> certificate_signature) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_signed_certificate(Ref<vm::Cell>& cell_ref, Ref<CellSlice> certificate, Ref<CellSlice> certificate_signature) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "SignedCertificate";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const SignedCertificate t_SignedCertificate;

//
// headers for type `CryptoSignature`
//

struct CryptoSignature final : TLB_Complex {
  enum { cons1, chained_signature };
  static constexpr char cons_len[2] = { 0, 4 };
  static constexpr unsigned char cons_tag[2] = { 0, 15 };
  struct Record_cons1 {
    typedef CryptoSignature type_class;
    Ref<CellSlice> x;  	// CryptoSignatureSimple
  };
  struct Record_chained_signature {
    typedef CryptoSignature type_class;
    Ref<Cell> signed_cert;  	// signed_cert : ^SignedCertificate
    Ref<CellSlice> temp_key_signature;  	// temp_key_signature : CryptoSignatureSimple
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_cons1& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons1& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons1& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons1& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_chained_signature& data) const;
  bool unpack_chained_signature(vm::CellSlice& cs, Ref<Cell>& signed_cert, Ref<CellSlice>& temp_key_signature) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_chained_signature& data) const;
  bool cell_unpack_chained_signature(Ref<vm::Cell> cell_ref, Ref<Cell>& signed_cert, Ref<CellSlice>& temp_key_signature) const;
  bool pack(vm::CellBuilder& cb, const Record_chained_signature& data) const;
  bool pack_chained_signature(vm::CellBuilder& cb, Ref<Cell> signed_cert, Ref<CellSlice> temp_key_signature) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_chained_signature& data) const;
  bool cell_pack_chained_signature(Ref<vm::Cell>& cell_ref, Ref<Cell> signed_cert, Ref<CellSlice> temp_key_signature) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "CryptoSignature";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

extern const CryptoSignature t_CryptoSignature;

//
// headers for auxiliary type `McBlockExtra_aux`
//

struct McBlockExtra_aux final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& prev_blk_signatures, Ref<CellSlice>& recover_create_msg, Ref<CellSlice>& mint_msg) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& prev_blk_signatures, Ref<CellSlice>& recover_create_msg, Ref<CellSlice>& mint_msg) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> prev_blk_signatures, Ref<CellSlice> recover_create_msg, Ref<CellSlice> mint_msg) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> prev_blk_signatures, Ref<CellSlice> recover_create_msg, Ref<CellSlice> mint_msg) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "McBlockExtra_aux";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct McBlockExtra_aux::Record {
  typedef McBlockExtra_aux type_class;
  Ref<CellSlice> prev_blk_signatures;  	// prev_blk_signatures : HashmapE 16 CryptoSignaturePair
  Ref<CellSlice> recover_create_msg;  	// recover_create_msg : Maybe ^InMsg
  Ref<CellSlice> mint_msg;  	// mint_msg : Maybe ^InMsg
};

extern const McBlockExtra_aux t_McBlockExtra_aux;

//
// headers for type `McBlockExtra`
//

struct McBlockExtra final : TLB_Complex {
  enum { masterchain_block_extra };
  static constexpr int cons_len_exact = 16;
  static constexpr unsigned short cons_tag[1] = { 0xcca5 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "McBlockExtra";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct McBlockExtra::Record {
  typedef McBlockExtra type_class;
  bool key_block;  	// key_block : ## 1
  Ref<CellSlice> shard_hashes;  	// shard_hashes : ShardHashes
  Ref<CellSlice> shard_fees;  	// shard_fees : ShardFees
  McBlockExtra_aux::Record r1;  	// ^[$_ prev_blk_signatures:(HashmapE 16 CryptoSignaturePair) recover_create_msg:(Maybe ^InMsg) mint_msg:(Maybe ^InMsg) ]
  Ref<CellSlice> config;  	// config : key_block?ConfigParams
};

extern const McBlockExtra t_McBlockExtra;

//
// headers for type `ValidatorDescr`
//

struct ValidatorDescr final : TLB_Complex {
  enum { validator, validator_addr };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[2] = { 0x53, 0x73 };
  struct Record_validator {
    typedef ValidatorDescr type_class;
    Ref<CellSlice> public_key;  	// public_key : SigPubKey
    unsigned long long weight;  	// weight : uint64
  };
  struct Record_validator_addr;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_validator& data) const;
  bool unpack_validator(vm::CellSlice& cs, Ref<CellSlice>& public_key, unsigned long long& weight) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_validator& data) const;
  bool cell_unpack_validator(Ref<vm::Cell> cell_ref, Ref<CellSlice>& public_key, unsigned long long& weight) const;
  bool pack(vm::CellBuilder& cb, const Record_validator& data) const;
  bool pack_validator(vm::CellBuilder& cb, Ref<CellSlice> public_key, unsigned long long weight) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_validator& data) const;
  bool cell_pack_validator(Ref<vm::Cell>& cell_ref, Ref<CellSlice> public_key, unsigned long long weight) const;
  bool unpack(vm::CellSlice& cs, Record_validator_addr& data) const;
  bool unpack_validator_addr(vm::CellSlice& cs, Ref<CellSlice>& public_key, unsigned long long& weight, td::BitArray<256>& adnl_addr) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_validator_addr& data) const;
  bool cell_unpack_validator_addr(Ref<vm::Cell> cell_ref, Ref<CellSlice>& public_key, unsigned long long& weight, td::BitArray<256>& adnl_addr) const;
  bool pack(vm::CellBuilder& cb, const Record_validator_addr& data) const;
  bool pack_validator_addr(vm::CellBuilder& cb, Ref<CellSlice> public_key, unsigned long long weight, td::BitArray<256> adnl_addr) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_validator_addr& data) const;
  bool cell_pack_validator_addr(Ref<vm::Cell>& cell_ref, Ref<CellSlice> public_key, unsigned long long weight, td::BitArray<256> adnl_addr) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ValidatorDescr";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(3, 12);
  }
};

struct ValidatorDescr::Record_validator_addr {
  typedef ValidatorDescr type_class;
  Ref<CellSlice> public_key;  	// public_key : SigPubKey
  unsigned long long weight;  	// weight : uint64
  td::BitArray<256> adnl_addr;  	// adnl_addr : bits256
};

extern const ValidatorDescr t_ValidatorDescr;

//
// headers for type `ValidatorSet`
//

struct ValidatorSet final : TLB_Complex {
  enum { validators, validators_ext };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[2] = { 17, 18 };
  struct Record_validators;
  struct Record_validators_ext;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_validators& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_validators& data) const;
  bool pack(vm::CellBuilder& cb, const Record_validators& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_validators& data) const;
  bool unpack(vm::CellSlice& cs, Record_validators_ext& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_validators_ext& data) const;
  bool pack(vm::CellBuilder& cb, const Record_validators_ext& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_validators_ext& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ValidatorSet";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct ValidatorSet::Record_validators {
  typedef ValidatorSet type_class;
  unsigned utime_since;  	// utime_since : uint32
  unsigned utime_until;  	// utime_until : uint32
  unsigned total;  	// total : ## 16
  unsigned main;  	// main : ## 16
  Ref<CellSlice> list;  	// list : Hashmap 16 ValidatorDescr
};

struct ValidatorSet::Record_validators_ext {
  typedef ValidatorSet type_class;
  unsigned utime_since;  	// utime_since : uint32
  unsigned utime_until;  	// utime_until : uint32
  unsigned total;  	// total : ## 16
  unsigned main;  	// main : ## 16
  unsigned long long total_weight;  	// total_weight : uint64
  Ref<CellSlice> list;  	// list : HashmapE 16 ValidatorDescr
};

extern const ValidatorSet t_ValidatorSet;

//
// headers for type `BurningConfig`
//

struct BurningConfig final : TLB_Complex {
  enum { burning_config };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 1 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_burning_config(vm::CellSlice& cs, Ref<CellSlice>& blackhole_addr, unsigned& fee_burn_num, unsigned& fee_burn_denom) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_burning_config(Ref<vm::Cell> cell_ref, Ref<CellSlice>& blackhole_addr, unsigned& fee_burn_num, unsigned& fee_burn_denom) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_burning_config(vm::CellBuilder& cb, Ref<CellSlice> blackhole_addr, unsigned fee_burn_num, unsigned fee_burn_denom) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_burning_config(Ref<vm::Cell>& cell_ref, Ref<CellSlice> blackhole_addr, unsigned fee_burn_num, unsigned fee_burn_denom) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BurningConfig";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct BurningConfig::Record {
  typedef BurningConfig type_class;
  Ref<CellSlice> blackhole_addr;  	// blackhole_addr : Maybe bits256
  unsigned fee_burn_num;  	// fee_burn_num : #
  unsigned fee_burn_denom;  	// fee_burn_denom : #
};

extern const BurningConfig t_BurningConfig;

//
// headers for type `GlobalVersion`
//

struct GlobalVersion final : TLB_Complex {
  enum { capabilities };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0xc4 };
  struct Record {
    typedef GlobalVersion type_class;
    unsigned version;  	// version : uint32
    unsigned long long capabilities;  	// capabilities : uint64
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 104;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(104);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_capabilities(vm::CellSlice& cs, unsigned& version, unsigned long long& capabilities) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_capabilities(Ref<vm::Cell> cell_ref, unsigned& version, unsigned long long& capabilities) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_capabilities(vm::CellBuilder& cb, unsigned version, unsigned long long capabilities) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_capabilities(Ref<vm::Cell>& cell_ref, unsigned version, unsigned long long capabilities) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "GlobalVersion";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const GlobalVersion t_GlobalVersion;

//
// headers for type `ConfigProposalSetup`
//

struct ConfigProposalSetup final : TLB_Complex {
  enum { cfg_vote_cfg };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0x36 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 168;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(168);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ConfigProposalSetup";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ConfigProposalSetup::Record {
  typedef ConfigProposalSetup type_class;
  unsigned min_tot_rounds;  	// min_tot_rounds : ## 8
  unsigned max_tot_rounds;  	// max_tot_rounds : ## 8
  int min_wins;  	// min_wins : uint8
  int max_losses;  	// max_losses : uint8
  unsigned min_store_sec;  	// min_store_sec : ## 32
  unsigned max_store_sec;  	// max_store_sec : ## 32
  unsigned bit_price;  	// bit_price : uint32
  unsigned cell_price;  	// cell_price : uint32
};

extern const ConfigProposalSetup t_ConfigProposalSetup;

//
// headers for type `ConfigVotingSetup`
//

struct ConfigVotingSetup final : TLB_Complex {
  enum { cfg_vote_setup };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0x91 };
  struct Record {
    typedef ConfigVotingSetup type_class;
    Ref<Cell> normal_params;  	// normal_params : ^ConfigProposalSetup
    Ref<Cell> critical_params;  	// critical_params : ^ConfigProposalSetup
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 0x20008;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x20008);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cfg_vote_setup(vm::CellSlice& cs, Ref<Cell>& normal_params, Ref<Cell>& critical_params) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cfg_vote_setup(Ref<vm::Cell> cell_ref, Ref<Cell>& normal_params, Ref<Cell>& critical_params) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cfg_vote_setup(vm::CellBuilder& cb, Ref<Cell> normal_params, Ref<Cell> critical_params) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cfg_vote_setup(Ref<vm::Cell>& cell_ref, Ref<Cell> normal_params, Ref<Cell> critical_params) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ConfigVotingSetup";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ConfigVotingSetup t_ConfigVotingSetup;

//
// headers for type `ConfigProposal`
//

struct ConfigProposal final : TLB_Complex {
  enum { cfg_proposal };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0xf3 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cfg_proposal(vm::CellSlice& cs, int& param_id, Ref<CellSlice>& param_value, Ref<CellSlice>& if_hash_equal) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cfg_proposal(Ref<vm::Cell> cell_ref, int& param_id, Ref<CellSlice>& param_value, Ref<CellSlice>& if_hash_equal) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cfg_proposal(vm::CellBuilder& cb, int param_id, Ref<CellSlice> param_value, Ref<CellSlice> if_hash_equal) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cfg_proposal(Ref<vm::Cell>& cell_ref, int param_id, Ref<CellSlice> param_value, Ref<CellSlice> if_hash_equal) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ConfigProposal";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ConfigProposal::Record {
  typedef ConfigProposal type_class;
  int param_id;  	// param_id : int32
  Ref<CellSlice> param_value;  	// param_value : Maybe ^Cell
  Ref<CellSlice> if_hash_equal;  	// if_hash_equal : Maybe uint256
};

extern const ConfigProposal t_ConfigProposal;

//
// headers for type `ConfigProposalStatus`
//

struct ConfigProposalStatus final : TLB_Complex {
  enum { cfg_proposal_status };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0xce };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ConfigProposalStatus";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ConfigProposalStatus::Record {
  typedef ConfigProposalStatus type_class;
  unsigned expires;  	// expires : uint32
  Ref<Cell> proposal;  	// proposal : ^ConfigProposal
  bool is_critical;  	// is_critical : Bool
  Ref<CellSlice> voters;  	// voters : HashmapE 16 True
  long long remaining_weight;  	// remaining_weight : int64
  RefInt256 validator_set_id;  	// validator_set_id : uint256
  int rounds_remaining;  	// rounds_remaining : uint8
  int wins;  	// wins : uint8
  int losses;  	// losses : uint8
};

extern const ConfigProposalStatus t_ConfigProposalStatus;

//
// headers for type `WorkchainFormat`
//

struct WorkchainFormat final : TLB_Complex {
  enum { wfmt_ext, wfmt_basic };
  static constexpr int cons_len_exact = 4;
  unsigned m_;
  WorkchainFormat(unsigned m) : m_(m) {}
  struct Record_wfmt_basic {
    typedef WorkchainFormat type_class;
    int vm_version;  	// vm_version : int32
    unsigned long long vm_mode;  	// vm_mode : uint64
  };
  struct Record_wfmt_ext;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_wfmt_basic& data) const;
  bool unpack_wfmt_basic(vm::CellSlice& cs, int& vm_version, unsigned long long& vm_mode) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_wfmt_basic& data) const;
  bool cell_unpack_wfmt_basic(Ref<vm::Cell> cell_ref, int& vm_version, unsigned long long& vm_mode) const;
  bool pack(vm::CellBuilder& cb, const Record_wfmt_basic& data) const;
  bool pack_wfmt_basic(vm::CellBuilder& cb, int vm_version, unsigned long long vm_mode) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_wfmt_basic& data) const;
  bool cell_pack_wfmt_basic(Ref<vm::Cell>& cell_ref, int vm_version, unsigned long long vm_mode) const;
  bool unpack(vm::CellSlice& cs, Record_wfmt_ext& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_wfmt_ext& data) const;
  bool pack(vm::CellBuilder& cb, const Record_wfmt_ext& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_wfmt_ext& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(WorkchainFormat " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(4, 3);
  }
};

struct WorkchainFormat::Record_wfmt_ext {
  typedef WorkchainFormat type_class;
  unsigned min_addr_len;  	// min_addr_len : ## 12
  unsigned max_addr_len;  	// max_addr_len : ## 12
  unsigned addr_len_step;  	// addr_len_step : ## 12
  unsigned workchain_type_id;  	// workchain_type_id : ## 32
};

//
// headers for type `WcSplitMergeTimings`
//

struct WcSplitMergeTimings final : TLB_Complex {
  enum { wc_split_merge_timings };
  static constexpr int cons_len_exact = 4;
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 132;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(132);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WcSplitMergeTimings";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct WcSplitMergeTimings::Record {
  typedef WcSplitMergeTimings type_class;
  unsigned split_merge_delay;  	// split_merge_delay : uint32
  unsigned split_merge_interval;  	// split_merge_interval : uint32
  unsigned min_split_merge_interval;  	// min_split_merge_interval : uint32
  unsigned max_split_merge_delay;  	// max_split_merge_delay : uint32
};

extern const WcSplitMergeTimings t_WcSplitMergeTimings;

//
// headers for type `WorkchainDescr`
//

struct WorkchainDescr final : TLB_Complex {
  enum { workchain, workchain_v2 };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[2] = { 0xa6, 0xa7 };
  struct Record_workchain;
  struct Record_workchain_v2;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_workchain& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_workchain& data) const;
  bool pack(vm::CellBuilder& cb, const Record_workchain& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_workchain& data) const;
  bool unpack(vm::CellSlice& cs, Record_workchain_v2& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_workchain_v2& data) const;
  bool pack(vm::CellBuilder& cb, const Record_workchain_v2& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_workchain_v2& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "WorkchainDescr";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct WorkchainDescr::Record_workchain {
  typedef WorkchainDescr type_class;
  unsigned enabled_since;  	// enabled_since : uint32
  unsigned monitor_min_split;  	// monitor_min_split : ## 8
  unsigned min_split;  	// min_split : ## 8
  unsigned max_split;  	// max_split : ## 8
  bool basic;  	// basic : ## 1
  bool active;  	// active : Bool
  bool accept_msgs;  	// accept_msgs : Bool
  unsigned flags;  	// flags : ## 13
  td::BitArray<256> zerostate_root_hash;  	// zerostate_root_hash : bits256
  td::BitArray<256> zerostate_file_hash;  	// zerostate_file_hash : bits256
  unsigned version;  	// version : uint32
  Ref<CellSlice> format;  	// format : WorkchainFormat basic
};

struct WorkchainDescr::Record_workchain_v2 {
  typedef WorkchainDescr type_class;
  unsigned enabled_since;  	// enabled_since : uint32
  unsigned monitor_min_split;  	// monitor_min_split : ## 8
  unsigned min_split;  	// min_split : ## 8
  unsigned max_split;  	// max_split : ## 8
  bool basic;  	// basic : ## 1
  bool active;  	// active : Bool
  bool accept_msgs;  	// accept_msgs : Bool
  unsigned flags;  	// flags : ## 13
  td::BitArray<256> zerostate_root_hash;  	// zerostate_root_hash : bits256
  td::BitArray<256> zerostate_file_hash;  	// zerostate_file_hash : bits256
  unsigned version;  	// version : uint32
  Ref<CellSlice> format;  	// format : WorkchainFormat basic
  Ref<CellSlice> split_merge_timings;  	// split_merge_timings : WcSplitMergeTimings
  unsigned persistent_state_split_depth;  	// persistent_state_split_depth : ## 8
};

extern const WorkchainDescr t_WorkchainDescr;

//
// headers for type `ComplaintPricing`
//

struct ComplaintPricing final : TLB_Complex {
  enum { complaint_prices };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 26 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_complaint_prices(vm::CellSlice& cs, Ref<CellSlice>& deposit, Ref<CellSlice>& bit_price, Ref<CellSlice>& cell_price) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_complaint_prices(Ref<vm::Cell> cell_ref, Ref<CellSlice>& deposit, Ref<CellSlice>& bit_price, Ref<CellSlice>& cell_price) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_complaint_prices(vm::CellBuilder& cb, Ref<CellSlice> deposit, Ref<CellSlice> bit_price, Ref<CellSlice> cell_price) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_complaint_prices(Ref<vm::Cell>& cell_ref, Ref<CellSlice> deposit, Ref<CellSlice> bit_price, Ref<CellSlice> cell_price) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ComplaintPricing";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ComplaintPricing::Record {
  typedef ComplaintPricing type_class;
  Ref<CellSlice> deposit;  	// deposit : Tomis
  Ref<CellSlice> bit_price;  	// bit_price : Tomis
  Ref<CellSlice> cell_price;  	// cell_price : Tomis
};

extern const ComplaintPricing t_ComplaintPricing;

//
// headers for type `BlockCreateFees`
//

struct BlockCreateFees final : TLB_Complex {
  enum { block_tomis_created };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0x6b };
  struct Record {
    typedef BlockCreateFees type_class;
    Ref<CellSlice> masterchain_block_fee;  	// masterchain_block_fee : Tomis
    Ref<CellSlice> basechain_block_fee;  	// basechain_block_fee : Tomis
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_block_tomis_created(vm::CellSlice& cs, Ref<CellSlice>& masterchain_block_fee, Ref<CellSlice>& basechain_block_fee) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_block_tomis_created(Ref<vm::Cell> cell_ref, Ref<CellSlice>& masterchain_block_fee, Ref<CellSlice>& basechain_block_fee) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_block_tomis_created(vm::CellBuilder& cb, Ref<CellSlice> masterchain_block_fee, Ref<CellSlice> basechain_block_fee) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_block_tomis_created(Ref<vm::Cell>& cell_ref, Ref<CellSlice> masterchain_block_fee, Ref<CellSlice> basechain_block_fee) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BlockCreateFees";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const BlockCreateFees t_BlockCreateFees;

//
// headers for type `StoragePrices`
//

struct StoragePrices final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0xcc };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 296;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(296);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "StoragePrices";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct StoragePrices::Record {
  typedef StoragePrices type_class;
  unsigned utime_since;  	// utime_since : uint32
  unsigned long long bit_price_ps;  	// bit_price_ps : uint64
  unsigned long long cell_price_ps;  	// cell_price_ps : uint64
  unsigned long long mc_bit_price_ps;  	// mc_bit_price_ps : uint64
  unsigned long long mc_cell_price_ps;  	// mc_cell_price_ps : uint64
};

extern const StoragePrices t_StoragePrices;

//
// headers for type `GasLimitsPrices`
//

struct GasLimitsPrices final : TLB_Complex {
  enum { gas_flat_pfx, gas_prices, gas_prices_ext };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[3] = { 0xd1, 0xdd, 0xde };
  struct Record_gas_prices;
  struct Record_gas_prices_ext;
  struct Record_gas_flat_pfx;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_gas_prices& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_gas_prices& data) const;
  bool pack(vm::CellBuilder& cb, const Record_gas_prices& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_gas_prices& data) const;
  bool unpack(vm::CellSlice& cs, Record_gas_prices_ext& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_gas_prices_ext& data) const;
  bool pack(vm::CellBuilder& cb, const Record_gas_prices_ext& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_gas_prices_ext& data) const;
  bool unpack(vm::CellSlice& cs, Record_gas_flat_pfx& data) const;
  bool unpack_gas_flat_pfx(vm::CellSlice& cs, unsigned long long& flat_gas_limit, unsigned long long& flat_gas_price, Ref<CellSlice>& other) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_gas_flat_pfx& data) const;
  bool cell_unpack_gas_flat_pfx(Ref<vm::Cell> cell_ref, unsigned long long& flat_gas_limit, unsigned long long& flat_gas_price, Ref<CellSlice>& other) const;
  bool pack(vm::CellBuilder& cb, const Record_gas_flat_pfx& data) const;
  bool pack_gas_flat_pfx(vm::CellBuilder& cb, unsigned long long flat_gas_limit, unsigned long long flat_gas_price, Ref<CellSlice> other) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_gas_flat_pfx& data) const;
  bool cell_pack_gas_flat_pfx(Ref<vm::Cell>& cell_ref, unsigned long long flat_gas_limit, unsigned long long flat_gas_price, Ref<CellSlice> other) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "GasLimitsPrices";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct GasLimitsPrices::Record_gas_prices {
  typedef GasLimitsPrices type_class;
  unsigned long long gas_price;  	// gas_price : uint64
  unsigned long long gas_limit;  	// gas_limit : uint64
  unsigned long long gas_credit;  	// gas_credit : uint64
  unsigned long long block_gas_limit;  	// block_gas_limit : uint64
  unsigned long long freeze_due_limit;  	// freeze_due_limit : uint64
  unsigned long long delete_due_limit;  	// delete_due_limit : uint64
};

struct GasLimitsPrices::Record_gas_prices_ext {
  typedef GasLimitsPrices type_class;
  unsigned long long gas_price;  	// gas_price : uint64
  unsigned long long gas_limit;  	// gas_limit : uint64
  unsigned long long special_gas_limit;  	// special_gas_limit : uint64
  unsigned long long gas_credit;  	// gas_credit : uint64
  unsigned long long block_gas_limit;  	// block_gas_limit : uint64
  unsigned long long freeze_due_limit;  	// freeze_due_limit : uint64
  unsigned long long delete_due_limit;  	// delete_due_limit : uint64
};

struct GasLimitsPrices::Record_gas_flat_pfx {
  typedef GasLimitsPrices type_class;
  unsigned long long flat_gas_limit;  	// flat_gas_limit : uint64
  unsigned long long flat_gas_price;  	// flat_gas_price : uint64
  Ref<CellSlice> other;  	// other : GasLimitsPrices
};

extern const GasLimitsPrices t_GasLimitsPrices;

//
// headers for type `ParamLimits`
//

struct ParamLimits final : TLB_Complex {
  enum { param_limits };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0xc3 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 104;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(104);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_param_limits(vm::CellSlice& cs, unsigned& underload, unsigned& soft_limit, unsigned& hard_limit) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_param_limits(Ref<vm::Cell> cell_ref, unsigned& underload, unsigned& soft_limit, unsigned& hard_limit) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_param_limits(vm::CellBuilder& cb, unsigned underload, unsigned soft_limit, unsigned hard_limit) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_param_limits(Ref<vm::Cell>& cell_ref, unsigned underload, unsigned soft_limit, unsigned hard_limit) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ParamLimits";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ParamLimits::Record {
  typedef ParamLimits type_class;
  unsigned underload;  	// underload : #
  unsigned soft_limit;  	// soft_limit : #
  unsigned hard_limit;  	// hard_limit : #
};

extern const ParamLimits t_ParamLimits;

//
// headers for type `ImportedMsgQueueLimits`
//

struct ImportedMsgQueueLimits final : TLB_Complex {
  enum { imported_msg_queue_limits };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0xd3 };
  struct Record {
    typedef ImportedMsgQueueLimits type_class;
    unsigned max_bytes;  	// max_bytes : #
    unsigned max_msgs;  	// max_msgs : #
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 72;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(72);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_imported_msg_queue_limits(vm::CellSlice& cs, unsigned& max_bytes, unsigned& max_msgs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_imported_msg_queue_limits(Ref<vm::Cell> cell_ref, unsigned& max_bytes, unsigned& max_msgs) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_imported_msg_queue_limits(vm::CellBuilder& cb, unsigned max_bytes, unsigned max_msgs) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_imported_msg_queue_limits(Ref<vm::Cell>& cell_ref, unsigned max_bytes, unsigned max_msgs) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ImportedMsgQueueLimits";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ImportedMsgQueueLimits t_ImportedMsgQueueLimits;

//
// headers for type `BlockLimits`
//

struct BlockLimits final : TLB_Complex {
  enum { block_limits, block_limits_v2 };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[2] = { 0x5d, 0x5e };
  struct Record_block_limits;
  struct Record_block_limits_v2;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_block_limits& data) const;
  bool unpack_block_limits(vm::CellSlice& cs, Ref<CellSlice>& bytes, Ref<CellSlice>& gas, Ref<CellSlice>& lt_delta) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_block_limits& data) const;
  bool cell_unpack_block_limits(Ref<vm::Cell> cell_ref, Ref<CellSlice>& bytes, Ref<CellSlice>& gas, Ref<CellSlice>& lt_delta) const;
  bool pack(vm::CellBuilder& cb, const Record_block_limits& data) const;
  bool pack_block_limits(vm::CellBuilder& cb, Ref<CellSlice> bytes, Ref<CellSlice> gas, Ref<CellSlice> lt_delta) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_block_limits& data) const;
  bool cell_pack_block_limits(Ref<vm::Cell>& cell_ref, Ref<CellSlice> bytes, Ref<CellSlice> gas, Ref<CellSlice> lt_delta) const;
  bool unpack(vm::CellSlice& cs, Record_block_limits_v2& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_block_limits_v2& data) const;
  bool pack(vm::CellBuilder& cb, const Record_block_limits_v2& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_block_limits_v2& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BlockLimits";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct BlockLimits::Record_block_limits {
  typedef BlockLimits type_class;
  Ref<CellSlice> bytes;  	// bytes : ParamLimits
  Ref<CellSlice> gas;  	// gas : ParamLimits
  Ref<CellSlice> lt_delta;  	// lt_delta : ParamLimits
};

struct BlockLimits::Record_block_limits_v2 {
  typedef BlockLimits type_class;
  Ref<CellSlice> bytes;  	// bytes : ParamLimits
  Ref<CellSlice> gas;  	// gas : ParamLimits
  Ref<CellSlice> lt_delta;  	// lt_delta : ParamLimits
  Ref<CellSlice> collated_data;  	// collated_data : ParamLimits
  Ref<CellSlice> imported_msg_queue;  	// imported_msg_queue : ImportedMsgQueueLimits
};

extern const BlockLimits t_BlockLimits;

//
// headers for type `MsgForwardPrices`
//

struct MsgForwardPrices final : TLB_Complex {
  enum { msg_forward_prices };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0xea };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 264;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(264);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "MsgForwardPrices";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct MsgForwardPrices::Record {
  typedef MsgForwardPrices type_class;
  unsigned long long lump_price;  	// lump_price : uint64
  unsigned long long bit_price;  	// bit_price : uint64
  unsigned long long cell_price;  	// cell_price : uint64
  unsigned ihr_price_factor;  	// ihr_price_factor : uint32
  int first_frac;  	// first_frac : uint16
  int next_frac;  	// next_frac : uint16
};

extern const MsgForwardPrices t_MsgForwardPrices;

//
// headers for type `CatchainConfig`
//

struct CatchainConfig final : TLB_Complex {
  enum { catchain_config, catchain_config_new };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[2] = { 0xc1, 0xc2 };
  struct Record_catchain_config;
  struct Record_catchain_config_new;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_catchain_config& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_catchain_config& data) const;
  bool pack(vm::CellBuilder& cb, const Record_catchain_config& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_catchain_config& data) const;
  bool unpack(vm::CellSlice& cs, Record_catchain_config_new& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_catchain_config_new& data) const;
  bool pack(vm::CellBuilder& cb, const Record_catchain_config_new& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_catchain_config_new& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "CatchainConfig";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct CatchainConfig::Record_catchain_config {
  typedef CatchainConfig type_class;
  unsigned mc_catchain_lifetime;  	// mc_catchain_lifetime : ## 32
  unsigned shard_catchain_lifetime;  	// shard_catchain_lifetime : ## 32
  unsigned shard_validators_lifetime;  	// shard_validators_lifetime : ## 32
  unsigned shard_validators_num;  	// shard_validators_num : ## 32
};

struct CatchainConfig::Record_catchain_config_new {
  typedef CatchainConfig type_class;
  unsigned flags;  	// flags : ## 7
  bool shuffle_mc_validators;  	// shuffle_mc_validators : Bool
  unsigned mc_catchain_lifetime;  	// mc_catchain_lifetime : ## 32
  unsigned shard_catchain_lifetime;  	// shard_catchain_lifetime : ## 32
  unsigned shard_validators_lifetime;  	// shard_validators_lifetime : ## 32
  unsigned shard_validators_num;  	// shard_validators_num : ## 32
};

extern const CatchainConfig t_CatchainConfig;

//
// headers for type `ConsensusConfig`
//

struct ConsensusConfig final : TLB_Complex {
  enum { consensus_config, consensus_config_new, consensus_config_v3, consensus_config_v4 };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[4] = { 0xd6, 0xd7, 0xd8, 0xd9 };
  struct Record_consensus_config;
  struct Record_consensus_config_new;
  struct Record_consensus_config_v3;
  struct Record_consensus_config_v4;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_consensus_config& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_consensus_config& data) const;
  bool pack(vm::CellBuilder& cb, const Record_consensus_config& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_consensus_config& data) const;
  bool unpack(vm::CellSlice& cs, Record_consensus_config_new& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_consensus_config_new& data) const;
  bool pack(vm::CellBuilder& cb, const Record_consensus_config_new& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_consensus_config_new& data) const;
  bool unpack(vm::CellSlice& cs, Record_consensus_config_v3& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_consensus_config_v3& data) const;
  bool pack(vm::CellBuilder& cb, const Record_consensus_config_v3& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_consensus_config_v3& data) const;
  bool unpack(vm::CellSlice& cs, Record_consensus_config_v4& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_consensus_config_v4& data) const;
  bool pack(vm::CellBuilder& cb, const Record_consensus_config_v4& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_consensus_config_v4& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ConsensusConfig";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct ConsensusConfig::Record_consensus_config {
  typedef ConsensusConfig type_class;
  unsigned round_candidates;  	// round_candidates : #
  unsigned next_candidate_delay_ms;  	// next_candidate_delay_ms : uint32
  unsigned consensus_timeout_ms;  	// consensus_timeout_ms : uint32
  unsigned fast_attempts;  	// fast_attempts : uint32
  unsigned attempt_duration;  	// attempt_duration : uint32
  unsigned catchain_max_deps;  	// catchain_max_deps : uint32
  unsigned max_block_bytes;  	// max_block_bytes : uint32
  unsigned max_collated_bytes;  	// max_collated_bytes : uint32
};

struct ConsensusConfig::Record_consensus_config_new {
  typedef ConsensusConfig type_class;
  unsigned flags;  	// flags : ## 7
  bool new_catchain_ids;  	// new_catchain_ids : Bool
  unsigned round_candidates;  	// round_candidates : ## 8
  unsigned next_candidate_delay_ms;  	// next_candidate_delay_ms : uint32
  unsigned consensus_timeout_ms;  	// consensus_timeout_ms : uint32
  unsigned fast_attempts;  	// fast_attempts : uint32
  unsigned attempt_duration;  	// attempt_duration : uint32
  unsigned catchain_max_deps;  	// catchain_max_deps : uint32
  unsigned max_block_bytes;  	// max_block_bytes : uint32
  unsigned max_collated_bytes;  	// max_collated_bytes : uint32
};

struct ConsensusConfig::Record_consensus_config_v3 {
  typedef ConsensusConfig type_class;
  unsigned flags;  	// flags : ## 7
  bool new_catchain_ids;  	// new_catchain_ids : Bool
  unsigned round_candidates;  	// round_candidates : ## 8
  unsigned next_candidate_delay_ms;  	// next_candidate_delay_ms : uint32
  unsigned consensus_timeout_ms;  	// consensus_timeout_ms : uint32
  unsigned fast_attempts;  	// fast_attempts : uint32
  unsigned attempt_duration;  	// attempt_duration : uint32
  unsigned catchain_max_deps;  	// catchain_max_deps : uint32
  unsigned max_block_bytes;  	// max_block_bytes : uint32
  unsigned max_collated_bytes;  	// max_collated_bytes : uint32
  int proto_version;  	// proto_version : uint16
};

struct ConsensusConfig::Record_consensus_config_v4 {
  typedef ConsensusConfig type_class;
  unsigned flags;  	// flags : ## 6
  bool use_quic;  	// use_quic : Bool
  bool new_catchain_ids;  	// new_catchain_ids : Bool
  unsigned round_candidates;  	// round_candidates : ## 8
  unsigned next_candidate_delay_ms;  	// next_candidate_delay_ms : uint32
  unsigned consensus_timeout_ms;  	// consensus_timeout_ms : uint32
  unsigned fast_attempts;  	// fast_attempts : uint32
  unsigned attempt_duration;  	// attempt_duration : uint32
  unsigned catchain_max_deps;  	// catchain_max_deps : uint32
  unsigned max_block_bytes;  	// max_block_bytes : uint32
  unsigned max_collated_bytes;  	// max_collated_bytes : uint32
  int proto_version;  	// proto_version : uint16
  unsigned catchain_max_blocks_coeff;  	// catchain_max_blocks_coeff : uint32
};

extern const ConsensusConfig t_ConsensusConfig;

//
// headers for type `NewConsensusConfig`
//

struct NewConsensusConfig final : TLB_Complex {
  enum { simplex_config, simplex_config_v2 };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[2] = { 0x21, 0x22 };
  struct Record_simplex_config;
  struct Record_simplex_config_v2;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_simplex_config& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_simplex_config& data) const;
  bool pack(vm::CellBuilder& cb, const Record_simplex_config& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_simplex_config& data) const;
  bool unpack(vm::CellSlice& cs, Record_simplex_config_v2& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_simplex_config_v2& data) const;
  bool pack(vm::CellBuilder& cb, const Record_simplex_config_v2& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_simplex_config_v2& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "NewConsensusConfig";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct NewConsensusConfig::Record_simplex_config {
  typedef NewConsensusConfig type_class;
  unsigned flags;  	// flags : ## 7
  bool use_quic;  	// use_quic : Bool
  unsigned target_rate_ms;  	// target_rate_ms : uint32
  unsigned slots_per_leader_window;  	// slots_per_leader_window : ## 32
  unsigned first_block_timeout_ms;  	// first_block_timeout_ms : uint32
  unsigned max_leader_window_desync;  	// max_leader_window_desync : uint32
};

struct NewConsensusConfig::Record_simplex_config_v2 {
  typedef NewConsensusConfig type_class;
  unsigned flags;  	// flags : ## 5
  unsigned protocol_version;  	// protocol_version : ## 2
  bool use_quic;  	// use_quic : Bool
  unsigned slots_per_leader_window;  	// slots_per_leader_window : ## 32
  Ref<CellSlice> noncritical_params;  	// noncritical_params : HashmapE 8 uint32
};

extern const NewConsensusConfig t_NewConsensusConfig;

//
// headers for type `NewConsensusConfigAll`
//

struct NewConsensusConfigAll final : TLB_Complex {
  enum { new_consensus_config_all };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 16 };
  struct Record {
    typedef NewConsensusConfigAll type_class;
    Ref<CellSlice> mc;  	// mc : Maybe ^NewConsensusConfig
    Ref<CellSlice> shard;  	// shard : Maybe ^NewConsensusConfig
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_new_consensus_config_all(vm::CellSlice& cs, Ref<CellSlice>& mc, Ref<CellSlice>& shard) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_new_consensus_config_all(Ref<vm::Cell> cell_ref, Ref<CellSlice>& mc, Ref<CellSlice>& shard) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_new_consensus_config_all(vm::CellBuilder& cb, Ref<CellSlice> mc, Ref<CellSlice> shard) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_new_consensus_config_all(Ref<vm::Cell>& cell_ref, Ref<CellSlice> mc, Ref<CellSlice> shard) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "NewConsensusConfigAll";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const NewConsensusConfigAll t_NewConsensusConfigAll;

//
// headers for type `ValidatorTempKey`
//

struct ValidatorTempKey final : TLB_Complex {
  enum { validator_temp_key };
  static constexpr int cons_len_exact = 4;
  static constexpr unsigned char cons_tag[1] = { 3 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 612;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(612);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ValidatorTempKey";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ValidatorTempKey::Record {
  typedef ValidatorTempKey type_class;
  td::BitArray<256> adnl_addr;  	// adnl_addr : bits256
  Ref<CellSlice> temp_public_key;  	// temp_public_key : SigPubKey
  unsigned seqno;  	// seqno : #
  unsigned valid_until;  	// valid_until : uint32
};

extern const ValidatorTempKey t_ValidatorTempKey;

//
// headers for type `ValidatorSignedTempKey`
//

struct ValidatorSignedTempKey final : TLB_Complex {
  enum { signed_temp_key };
  static constexpr int cons_len_exact = 4;
  static constexpr unsigned char cons_tag[1] = { 4 };
  struct Record {
    typedef ValidatorSignedTempKey type_class;
    Ref<Cell> key;  	// key : ^ValidatorTempKey
    Ref<CellSlice> signature;  	// signature : CryptoSignature
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_signed_temp_key(vm::CellSlice& cs, Ref<Cell>& key, Ref<CellSlice>& signature) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_signed_temp_key(Ref<vm::Cell> cell_ref, Ref<Cell>& key, Ref<CellSlice>& signature) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_signed_temp_key(vm::CellBuilder& cb, Ref<Cell> key, Ref<CellSlice> signature) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_signed_temp_key(Ref<vm::Cell>& cell_ref, Ref<Cell> key, Ref<CellSlice> signature) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ValidatorSignedTempKey";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ValidatorSignedTempKey t_ValidatorSignedTempKey;

//
// headers for type `MisbehaviourPunishmentConfig`
//

struct MisbehaviourPunishmentConfig final : TLB_Complex {
  enum { misbehaviour_punishment_config_v1 };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 1 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "MisbehaviourPunishmentConfig";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct MisbehaviourPunishmentConfig::Record {
  typedef MisbehaviourPunishmentConfig type_class;
  Ref<CellSlice> default_flat_fine;  	// default_flat_fine : Tomis
  unsigned default_proportional_fine;  	// default_proportional_fine : uint32
  int severity_flat_mult;  	// severity_flat_mult : uint16
  int severity_proportional_mult;  	// severity_proportional_mult : uint16
  int unpunishable_interval;  	// unpunishable_interval : uint16
  int long_interval;  	// long_interval : uint16
  int long_flat_mult;  	// long_flat_mult : uint16
  int long_proportional_mult;  	// long_proportional_mult : uint16
  int medium_interval;  	// medium_interval : uint16
  int medium_flat_mult;  	// medium_flat_mult : uint16
  int medium_proportional_mult;  	// medium_proportional_mult : uint16
};

extern const MisbehaviourPunishmentConfig t_MisbehaviourPunishmentConfig;

//
// headers for type `SizeLimitsConfig`
//

struct SizeLimitsConfig final : TLB_Complex {
  enum { size_limits_config, size_limits_config_v2, size_limits_config_v3 };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[3] = { 1, 2, 3 };
  struct Record_size_limits_config;
  struct Record_size_limits_config_v2;
  struct Record_size_limits_config_v3;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_size_limits_config& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_size_limits_config& data) const;
  bool pack(vm::CellBuilder& cb, const Record_size_limits_config& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_size_limits_config& data) const;
  bool unpack(vm::CellSlice& cs, Record_size_limits_config_v2& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_size_limits_config_v2& data) const;
  bool pack(vm::CellBuilder& cb, const Record_size_limits_config_v2& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_size_limits_config_v2& data) const;
  bool unpack(vm::CellSlice& cs, Record_size_limits_config_v3& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_size_limits_config_v3& data) const;
  bool pack(vm::CellBuilder& cb, const Record_size_limits_config_v3& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_size_limits_config_v3& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "SizeLimitsConfig";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct SizeLimitsConfig::Record_size_limits_config {
  typedef SizeLimitsConfig type_class;
  unsigned max_msg_bits;  	// max_msg_bits : uint32
  unsigned max_msg_cells;  	// max_msg_cells : uint32
  unsigned max_library_cells;  	// max_library_cells : uint32
  int max_vm_data_depth;  	// max_vm_data_depth : uint16
  unsigned max_ext_msg_size;  	// max_ext_msg_size : uint32
  int max_ext_msg_depth;  	// max_ext_msg_depth : uint16
};

struct SizeLimitsConfig::Record_size_limits_config_v2 {
  typedef SizeLimitsConfig type_class;
  unsigned max_msg_bits;  	// max_msg_bits : uint32
  unsigned max_msg_cells;  	// max_msg_cells : uint32
  unsigned max_library_cells;  	// max_library_cells : uint32
  int max_vm_data_depth;  	// max_vm_data_depth : uint16
  unsigned max_ext_msg_size;  	// max_ext_msg_size : uint32
  int max_ext_msg_depth;  	// max_ext_msg_depth : uint16
  unsigned max_acc_state_cells;  	// max_acc_state_cells : uint32
  unsigned max_mc_acc_state_cells;  	// max_mc_acc_state_cells : uint32
  unsigned max_acc_public_libraries;  	// max_acc_public_libraries : uint32
  unsigned defer_out_queue_size_limit;  	// defer_out_queue_size_limit : uint32
  unsigned max_msg_extra_currencies;  	// max_msg_extra_currencies : uint32
  int max_acc_fixed_prefix_length;  	// max_acc_fixed_prefix_length : uint8
  unsigned acc_state_cells_for_storage_dict;  	// acc_state_cells_for_storage_dict : uint32
};

struct SizeLimitsConfig::Record_size_limits_config_v3 {
  typedef SizeLimitsConfig type_class;
  unsigned max_msg_bits;  	// max_msg_bits : uint32
  unsigned max_msg_cells;  	// max_msg_cells : uint32
  unsigned max_library_cells;  	// max_library_cells : uint32
  int max_vm_data_depth;  	// max_vm_data_depth : uint16
  unsigned max_ext_msg_size;  	// max_ext_msg_size : uint32
  int max_ext_msg_depth;  	// max_ext_msg_depth : uint16
  unsigned max_acc_state_cells;  	// max_acc_state_cells : uint32
  unsigned max_mc_acc_state_cells;  	// max_mc_acc_state_cells : uint32
  unsigned max_acc_public_libraries;  	// max_acc_public_libraries : uint32
  unsigned defer_out_queue_size_limit;  	// defer_out_queue_size_limit : uint32
  unsigned max_msg_extra_currencies;  	// max_msg_extra_currencies : uint32
  int max_acc_fixed_prefix_length;  	// max_acc_fixed_prefix_length : uint8
  unsigned acc_state_cells_for_storage_dict;  	// acc_state_cells_for_storage_dict : uint32
  Ref<CellSlice> max_transaction_library_loads;  	// max_transaction_library_loads : Maybe uint32
  unsigned max_total_msg_bits;  	// max_total_msg_bits : uint32
  unsigned max_total_msg_cells;  	// max_total_msg_cells : uint32
};

extern const SizeLimitsConfig t_SizeLimitsConfig;

//
// headers for type `SuspendedAddressList`
//

struct SuspendedAddressList final : TLB_Complex {
  enum { suspended_address_list };
  static constexpr int cons_len_exact = 8;
  struct Record {
    typedef SuspendedAddressList type_class;
    Ref<CellSlice> addresses;  	// addresses : HashmapE 288 Unit
    unsigned suspended_until;  	// suspended_until : uint32
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_suspended_address_list(vm::CellSlice& cs, Ref<CellSlice>& addresses, unsigned& suspended_until) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_suspended_address_list(Ref<vm::Cell> cell_ref, Ref<CellSlice>& addresses, unsigned& suspended_until) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_suspended_address_list(vm::CellBuilder& cb, Ref<CellSlice> addresses, unsigned suspended_until) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_suspended_address_list(Ref<vm::Cell>& cell_ref, Ref<CellSlice> addresses, unsigned suspended_until) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "SuspendedAddressList";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const SuspendedAddressList t_SuspendedAddressList;

//
// headers for type `PrecompiledSmc`
//

struct PrecompiledSmc final : TLB_Complex {
  enum { precompiled_smc };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0xb0 };
  struct Record {
    typedef PrecompiledSmc type_class;
    unsigned long long gas_usage;  	// gas_usage : uint64
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 72;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(72);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_precompiled_smc(vm::CellSlice& cs, unsigned long long& gas_usage) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_precompiled_smc(Ref<vm::Cell> cell_ref, unsigned long long& gas_usage) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_precompiled_smc(vm::CellBuilder& cb, unsigned long long gas_usage) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_precompiled_smc(Ref<vm::Cell>& cell_ref, unsigned long long gas_usage) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "PrecompiledSmc";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const PrecompiledSmc t_PrecompiledSmc;

//
// headers for type `PrecompiledContractsConfig`
//

struct PrecompiledContractsConfig final : TLB_Complex {
  enum { precompiled_contracts_config };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0xc0 };
  struct Record {
    typedef PrecompiledContractsConfig type_class;
    Ref<CellSlice> list;  	// list : HashmapE 256 PrecompiledSmc
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_precompiled_contracts_config(vm::CellSlice& cs, Ref<CellSlice>& list) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_precompiled_contracts_config(Ref<vm::Cell> cell_ref, Ref<CellSlice>& list) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_precompiled_contracts_config(vm::CellBuilder& cb, Ref<CellSlice> list) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_precompiled_contracts_config(Ref<vm::Cell>& cell_ref, Ref<CellSlice> list) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "PrecompiledContractsConfig";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const PrecompiledContractsConfig t_PrecompiledContractsConfig;

//
// headers for type `OracleBridgeParams`
//

struct OracleBridgeParams final : TLB_Complex {
  enum { oracle_bridge_params };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "OracleBridgeParams";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct OracleBridgeParams::Record {
  typedef OracleBridgeParams type_class;
  td::BitArray<256> bridge_address;  	// bridge_address : bits256
  td::BitArray<256> oracle_mutlisig_address;  	// oracle_mutlisig_address : bits256
  Ref<CellSlice> oracles;  	// oracles : HashmapE 256 uint256
  td::BitArray<256> external_chain_address;  	// external_chain_address : bits256
};

extern const OracleBridgeParams t_OracleBridgeParams;

//
// headers for type `JettonBridgePrices`
//

struct JettonBridgePrices final : TLB_Complex {
  enum { jetton_bridge_prices };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "JettonBridgePrices";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct JettonBridgePrices::Record {
  typedef JettonBridgePrices type_class;
  Ref<CellSlice> bridge_burn_fee;  	// bridge_burn_fee : Coins
  Ref<CellSlice> bridge_mint_fee;  	// bridge_mint_fee : Coins
  Ref<CellSlice> wallet_min_tos_for_storage;  	// wallet_min_tos_for_storage : Coins
  Ref<CellSlice> wallet_gas_consumption;  	// wallet_gas_consumption : Coins
  Ref<CellSlice> minter_min_tos_for_storage;  	// minter_min_tos_for_storage : Coins
  Ref<CellSlice> discover_gas_consumption;  	// discover_gas_consumption : Coins
};

extern const JettonBridgePrices t_JettonBridgePrices;

//
// headers for type `JettonBridgeParams`
//

struct JettonBridgeParams final : TLB_Complex {
  enum { jetton_bridge_params_v0, jetton_bridge_params_v1 };
  static constexpr int cons_len_exact = 8;
  struct Record_jetton_bridge_params_v0;
  struct Record_jetton_bridge_params_v1;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_jetton_bridge_params_v0& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_jetton_bridge_params_v0& data) const;
  bool pack(vm::CellBuilder& cb, const Record_jetton_bridge_params_v0& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_jetton_bridge_params_v0& data) const;
  bool unpack(vm::CellSlice& cs, Record_jetton_bridge_params_v1& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_jetton_bridge_params_v1& data) const;
  bool pack(vm::CellBuilder& cb, const Record_jetton_bridge_params_v1& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_jetton_bridge_params_v1& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "JettonBridgeParams";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct JettonBridgeParams::Record_jetton_bridge_params_v0 {
  typedef JettonBridgeParams type_class;
  td::BitArray<256> bridge_address;  	// bridge_address : bits256
  td::BitArray<256> oracles_address;  	// oracles_address : bits256
  Ref<CellSlice> oracles;  	// oracles : HashmapE 256 uint256
  int state_flags;  	// state_flags : uint8
  Ref<CellSlice> burn_bridge_fee;  	// burn_bridge_fee : Coins
};

struct JettonBridgeParams::Record_jetton_bridge_params_v1 {
  typedef JettonBridgeParams type_class;
  td::BitArray<256> bridge_address;  	// bridge_address : bits256
  td::BitArray<256> oracles_address;  	// oracles_address : bits256
  Ref<CellSlice> oracles;  	// oracles : HashmapE 256 uint256
  int state_flags;  	// state_flags : uint8
  Ref<Cell> prices;  	// prices : ^JettonBridgePrices
  td::BitArray<256> external_chain_address;  	// external_chain_address : bits256
};

extern const JettonBridgeParams t_JettonBridgeParams;

//
// headers for type `ConfigParam`
//

struct ConfigParam final : TLB_Complex {
  enum { cons44, cons79, cons81, cons82, cons83, cons5, cons40, cons43, cons30, cons32, cons33, cons34, cons35, cons36, cons37, cons13, cons84, config_mc_block_limits, config_block_limits, cons14, cons0, cons1, cons2, cons3, cons4, cons6, cons7, cons9, cons10, cons12, cons15, cons16, cons17, cons18, cons19, cons31, cons39, cons71, cons72, cons73, cons11, cons45, cons28, cons8, config_mc_gas_prices, config_gas_prices, cons29, config_mc_fwd_prices, config_fwd_prices };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  ConfigParam(unsigned m) : m_(m) {}
  struct Record_cons0 {
    typedef ConfigParam type_class;
    td::BitArray<256> config_addr;  	// config_addr : bits256
  };
  struct Record_cons1 {
    typedef ConfigParam type_class;
    td::BitArray<256> elector_addr;  	// elector_addr : bits256
  };
  struct Record_cons2 {
    typedef ConfigParam type_class;
    td::BitArray<256> minter_addr;  	// minter_addr : bits256
  };
  struct Record_cons3 {
    typedef ConfigParam type_class;
    td::BitArray<256> fee_collector_addr;  	// fee_collector_addr : bits256
  };
  struct Record_cons4 {
    typedef ConfigParam type_class;
    td::BitArray<256> dns_root_addr;  	// dns_root_addr : bits256
  };
  struct Record_cons5 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// BurningConfig
  };
  struct Record_cons6 {
    typedef ConfigParam type_class;
    Ref<CellSlice> mint_new_price;  	// mint_new_price : Tomis
    Ref<CellSlice> mint_add_price;  	// mint_add_price : Tomis
  };
  struct Record_cons7 {
    typedef ConfigParam type_class;
    Ref<CellSlice> to_mint;  	// to_mint : ExtraCurrencyCollection
  };
  struct Record_cons8 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// GlobalVersion
  };
  struct Record_cons9 {
    typedef ConfigParam type_class;
    Ref<CellSlice> mandatory_params;  	// mandatory_params : Hashmap 32 True
  };
  struct Record_cons10 {
    typedef ConfigParam type_class;
    Ref<CellSlice> critical_params;  	// critical_params : Hashmap 32 True
  };
  struct Record_cons11 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// ConfigVotingSetup
  };
  struct Record_cons12 {
    typedef ConfigParam type_class;
    Ref<CellSlice> workchains;  	// workchains : HashmapE 32 WorkchainDescr
  };
  struct Record_cons13 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// ComplaintPricing
  };
  struct Record_cons14 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// BlockCreateFees
  };
  struct Record_cons15;
  struct Record_cons16;
  struct Record_cons17;
  struct Record_cons18 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// Hashmap 32 StoragePrices
  };
  struct Record_cons19 {
    typedef ConfigParam type_class;
    int global_id;  	// global_id : int32
  };
  struct Record_config_mc_gas_prices {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// GasLimitsPrices
  };
  struct Record_config_gas_prices {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// GasLimitsPrices
  };
  struct Record_config_mc_block_limits {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// BlockLimits
  };
  struct Record_config_block_limits {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// BlockLimits
  };
  struct Record_config_mc_fwd_prices {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// MsgForwardPrices
  };
  struct Record_config_fwd_prices {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// MsgForwardPrices
  };
  struct Record_cons28 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// CatchainConfig
  };
  struct Record_cons29 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// ConsensusConfig
  };
  struct Record_cons30 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// NewConsensusConfigAll
  };
  struct Record_cons31 {
    typedef ConfigParam type_class;
    Ref<CellSlice> fundamental_smc_addr;  	// fundamental_smc_addr : HashmapE 256 True
  };
  struct Record_cons32 {
    typedef ConfigParam type_class;
    Ref<CellSlice> prev_validators;  	// prev_validators : ValidatorSet
  };
  struct Record_cons33 {
    typedef ConfigParam type_class;
    Ref<CellSlice> prev_temp_validators;  	// prev_temp_validators : ValidatorSet
  };
  struct Record_cons34 {
    typedef ConfigParam type_class;
    Ref<CellSlice> cur_validators;  	// cur_validators : ValidatorSet
  };
  struct Record_cons35 {
    typedef ConfigParam type_class;
    Ref<CellSlice> cur_temp_validators;  	// cur_temp_validators : ValidatorSet
  };
  struct Record_cons36 {
    typedef ConfigParam type_class;
    Ref<CellSlice> next_validators;  	// next_validators : ValidatorSet
  };
  struct Record_cons37 {
    typedef ConfigParam type_class;
    Ref<CellSlice> next_temp_validators;  	// next_temp_validators : ValidatorSet
  };
  struct Record_cons39 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// HashmapE 256 ValidatorSignedTempKey
  };
  struct Record_cons40 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// MisbehaviourPunishmentConfig
  };
  struct Record_cons43 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// SizeLimitsConfig
  };
  struct Record_cons44 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// SuspendedAddressList
  };
  struct Record_cons45 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// PrecompiledContractsConfig
  };
  struct Record_cons71 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// OracleBridgeParams
  };
  struct Record_cons72 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// OracleBridgeParams
  };
  struct Record_cons73 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// OracleBridgeParams
  };
  struct Record_cons79 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// JettonBridgeParams
  };
  struct Record_cons81 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// JettonBridgeParams
  };
  struct Record_cons82 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// JettonBridgeParams
  };
  struct Record_cons83 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// JettonBridgeParams
  };
  struct Record_cons84 {
    typedef ConfigParam type_class;
    Ref<CellSlice> x;  	// WorkchainNativeIngressTable
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_cons0& data) const;
  bool unpack_cons0(vm::CellSlice& cs, td::BitArray<256>& config_addr) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons0& data) const;
  bool cell_unpack_cons0(Ref<vm::Cell> cell_ref, td::BitArray<256>& config_addr) const;
  bool pack(vm::CellBuilder& cb, const Record_cons0& data) const;
  bool pack_cons0(vm::CellBuilder& cb, td::BitArray<256> config_addr) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons0& data) const;
  bool cell_pack_cons0(Ref<vm::Cell>& cell_ref, td::BitArray<256> config_addr) const;
  bool unpack(vm::CellSlice& cs, Record_cons1& data) const;
  bool unpack_cons1(vm::CellSlice& cs, td::BitArray<256>& elector_addr) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons1& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, td::BitArray<256>& elector_addr) const;
  bool pack(vm::CellBuilder& cb, const Record_cons1& data) const;
  bool pack_cons1(vm::CellBuilder& cb, td::BitArray<256> elector_addr) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons1& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, td::BitArray<256> elector_addr) const;
  bool unpack(vm::CellSlice& cs, Record_cons2& data) const;
  bool unpack_cons2(vm::CellSlice& cs, td::BitArray<256>& minter_addr) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons2& data) const;
  bool cell_unpack_cons2(Ref<vm::Cell> cell_ref, td::BitArray<256>& minter_addr) const;
  bool pack(vm::CellBuilder& cb, const Record_cons2& data) const;
  bool pack_cons2(vm::CellBuilder& cb, td::BitArray<256> minter_addr) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons2& data) const;
  bool cell_pack_cons2(Ref<vm::Cell>& cell_ref, td::BitArray<256> minter_addr) const;
  bool unpack(vm::CellSlice& cs, Record_cons3& data) const;
  bool unpack_cons3(vm::CellSlice& cs, td::BitArray<256>& fee_collector_addr) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons3& data) const;
  bool cell_unpack_cons3(Ref<vm::Cell> cell_ref, td::BitArray<256>& fee_collector_addr) const;
  bool pack(vm::CellBuilder& cb, const Record_cons3& data) const;
  bool pack_cons3(vm::CellBuilder& cb, td::BitArray<256> fee_collector_addr) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons3& data) const;
  bool cell_pack_cons3(Ref<vm::Cell>& cell_ref, td::BitArray<256> fee_collector_addr) const;
  bool unpack(vm::CellSlice& cs, Record_cons4& data) const;
  bool unpack_cons4(vm::CellSlice& cs, td::BitArray<256>& dns_root_addr) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons4& data) const;
  bool cell_unpack_cons4(Ref<vm::Cell> cell_ref, td::BitArray<256>& dns_root_addr) const;
  bool pack(vm::CellBuilder& cb, const Record_cons4& data) const;
  bool pack_cons4(vm::CellBuilder& cb, td::BitArray<256> dns_root_addr) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons4& data) const;
  bool cell_pack_cons4(Ref<vm::Cell>& cell_ref, td::BitArray<256> dns_root_addr) const;
  bool unpack(vm::CellSlice& cs, Record_cons5& data) const;
  bool unpack_cons5(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons5& data) const;
  bool cell_unpack_cons5(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons5& data) const;
  bool pack_cons5(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons5& data) const;
  bool cell_pack_cons5(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons6& data) const;
  bool unpack_cons6(vm::CellSlice& cs, Ref<CellSlice>& mint_new_price, Ref<CellSlice>& mint_add_price) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons6& data) const;
  bool cell_unpack_cons6(Ref<vm::Cell> cell_ref, Ref<CellSlice>& mint_new_price, Ref<CellSlice>& mint_add_price) const;
  bool pack(vm::CellBuilder& cb, const Record_cons6& data) const;
  bool pack_cons6(vm::CellBuilder& cb, Ref<CellSlice> mint_new_price, Ref<CellSlice> mint_add_price) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons6& data) const;
  bool cell_pack_cons6(Ref<vm::Cell>& cell_ref, Ref<CellSlice> mint_new_price, Ref<CellSlice> mint_add_price) const;
  bool unpack(vm::CellSlice& cs, Record_cons7& data) const;
  bool unpack_cons7(vm::CellSlice& cs, Ref<CellSlice>& to_mint) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons7& data) const;
  bool cell_unpack_cons7(Ref<vm::Cell> cell_ref, Ref<CellSlice>& to_mint) const;
  bool pack(vm::CellBuilder& cb, const Record_cons7& data) const;
  bool pack_cons7(vm::CellBuilder& cb, Ref<CellSlice> to_mint) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons7& data) const;
  bool cell_pack_cons7(Ref<vm::Cell>& cell_ref, Ref<CellSlice> to_mint) const;
  bool unpack(vm::CellSlice& cs, Record_cons8& data) const;
  bool unpack_cons8(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons8& data) const;
  bool cell_unpack_cons8(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons8& data) const;
  bool pack_cons8(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons8& data) const;
  bool cell_pack_cons8(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons9& data) const;
  bool unpack_cons9(vm::CellSlice& cs, Ref<CellSlice>& mandatory_params) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons9& data) const;
  bool cell_unpack_cons9(Ref<vm::Cell> cell_ref, Ref<CellSlice>& mandatory_params) const;
  bool pack(vm::CellBuilder& cb, const Record_cons9& data) const;
  bool pack_cons9(vm::CellBuilder& cb, Ref<CellSlice> mandatory_params) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons9& data) const;
  bool cell_pack_cons9(Ref<vm::Cell>& cell_ref, Ref<CellSlice> mandatory_params) const;
  bool unpack(vm::CellSlice& cs, Record_cons10& data) const;
  bool unpack_cons10(vm::CellSlice& cs, Ref<CellSlice>& critical_params) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons10& data) const;
  bool cell_unpack_cons10(Ref<vm::Cell> cell_ref, Ref<CellSlice>& critical_params) const;
  bool pack(vm::CellBuilder& cb, const Record_cons10& data) const;
  bool pack_cons10(vm::CellBuilder& cb, Ref<CellSlice> critical_params) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons10& data) const;
  bool cell_pack_cons10(Ref<vm::Cell>& cell_ref, Ref<CellSlice> critical_params) const;
  bool unpack(vm::CellSlice& cs, Record_cons11& data) const;
  bool unpack_cons11(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons11& data) const;
  bool cell_unpack_cons11(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons11& data) const;
  bool pack_cons11(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons11& data) const;
  bool cell_pack_cons11(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons12& data) const;
  bool unpack_cons12(vm::CellSlice& cs, Ref<CellSlice>& workchains) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons12& data) const;
  bool cell_unpack_cons12(Ref<vm::Cell> cell_ref, Ref<CellSlice>& workchains) const;
  bool pack(vm::CellBuilder& cb, const Record_cons12& data) const;
  bool pack_cons12(vm::CellBuilder& cb, Ref<CellSlice> workchains) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons12& data) const;
  bool cell_pack_cons12(Ref<vm::Cell>& cell_ref, Ref<CellSlice> workchains) const;
  bool unpack(vm::CellSlice& cs, Record_cons13& data) const;
  bool unpack_cons13(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons13& data) const;
  bool cell_unpack_cons13(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons13& data) const;
  bool pack_cons13(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons13& data) const;
  bool cell_pack_cons13(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons14& data) const;
  bool unpack_cons14(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons14& data) const;
  bool cell_unpack_cons14(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons14& data) const;
  bool pack_cons14(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons14& data) const;
  bool cell_pack_cons14(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons15& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons15& data) const;
  bool pack(vm::CellBuilder& cb, const Record_cons15& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons15& data) const;
  bool unpack(vm::CellSlice& cs, Record_cons16& data) const;
  bool unpack_cons16(vm::CellSlice& cs, unsigned& max_validators, unsigned& max_main_validators, unsigned& min_validators) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons16& data) const;
  bool cell_unpack_cons16(Ref<vm::Cell> cell_ref, unsigned& max_validators, unsigned& max_main_validators, unsigned& min_validators) const;
  bool pack(vm::CellBuilder& cb, const Record_cons16& data) const;
  bool pack_cons16(vm::CellBuilder& cb, unsigned max_validators, unsigned max_main_validators, unsigned min_validators) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons16& data) const;
  bool cell_pack_cons16(Ref<vm::Cell>& cell_ref, unsigned max_validators, unsigned max_main_validators, unsigned min_validators) const;
  bool unpack(vm::CellSlice& cs, Record_cons17& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons17& data) const;
  bool pack(vm::CellBuilder& cb, const Record_cons17& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons17& data) const;
  bool unpack(vm::CellSlice& cs, Record_cons18& data) const;
  bool unpack_cons18(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons18& data) const;
  bool cell_unpack_cons18(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons18& data) const;
  bool pack_cons18(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons18& data) const;
  bool cell_pack_cons18(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons19& data) const;
  bool unpack_cons19(vm::CellSlice& cs, int& global_id) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons19& data) const;
  bool cell_unpack_cons19(Ref<vm::Cell> cell_ref, int& global_id) const;
  bool pack(vm::CellBuilder& cb, const Record_cons19& data) const;
  bool pack_cons19(vm::CellBuilder& cb, int global_id) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons19& data) const;
  bool cell_pack_cons19(Ref<vm::Cell>& cell_ref, int global_id) const;
  bool unpack(vm::CellSlice& cs, Record_config_mc_gas_prices& data) const;
  bool unpack_config_mc_gas_prices(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_config_mc_gas_prices& data) const;
  bool cell_unpack_config_mc_gas_prices(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_config_mc_gas_prices& data) const;
  bool pack_config_mc_gas_prices(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_config_mc_gas_prices& data) const;
  bool cell_pack_config_mc_gas_prices(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_config_gas_prices& data) const;
  bool unpack_config_gas_prices(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_config_gas_prices& data) const;
  bool cell_unpack_config_gas_prices(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_config_gas_prices& data) const;
  bool pack_config_gas_prices(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_config_gas_prices& data) const;
  bool cell_pack_config_gas_prices(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_config_mc_block_limits& data) const;
  bool unpack_config_mc_block_limits(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_config_mc_block_limits& data) const;
  bool cell_unpack_config_mc_block_limits(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_config_mc_block_limits& data) const;
  bool pack_config_mc_block_limits(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_config_mc_block_limits& data) const;
  bool cell_pack_config_mc_block_limits(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_config_block_limits& data) const;
  bool unpack_config_block_limits(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_config_block_limits& data) const;
  bool cell_unpack_config_block_limits(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_config_block_limits& data) const;
  bool pack_config_block_limits(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_config_block_limits& data) const;
  bool cell_pack_config_block_limits(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_config_mc_fwd_prices& data) const;
  bool unpack_config_mc_fwd_prices(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_config_mc_fwd_prices& data) const;
  bool cell_unpack_config_mc_fwd_prices(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_config_mc_fwd_prices& data) const;
  bool pack_config_mc_fwd_prices(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_config_mc_fwd_prices& data) const;
  bool cell_pack_config_mc_fwd_prices(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_config_fwd_prices& data) const;
  bool unpack_config_fwd_prices(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_config_fwd_prices& data) const;
  bool cell_unpack_config_fwd_prices(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_config_fwd_prices& data) const;
  bool pack_config_fwd_prices(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_config_fwd_prices& data) const;
  bool cell_pack_config_fwd_prices(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons28& data) const;
  bool unpack_cons28(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons28& data) const;
  bool cell_unpack_cons28(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons28& data) const;
  bool pack_cons28(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons28& data) const;
  bool cell_pack_cons28(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons29& data) const;
  bool unpack_cons29(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons29& data) const;
  bool cell_unpack_cons29(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons29& data) const;
  bool pack_cons29(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons29& data) const;
  bool cell_pack_cons29(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons30& data) const;
  bool unpack_cons30(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons30& data) const;
  bool cell_unpack_cons30(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons30& data) const;
  bool pack_cons30(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons30& data) const;
  bool cell_pack_cons30(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons31& data) const;
  bool unpack_cons31(vm::CellSlice& cs, Ref<CellSlice>& fundamental_smc_addr) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons31& data) const;
  bool cell_unpack_cons31(Ref<vm::Cell> cell_ref, Ref<CellSlice>& fundamental_smc_addr) const;
  bool pack(vm::CellBuilder& cb, const Record_cons31& data) const;
  bool pack_cons31(vm::CellBuilder& cb, Ref<CellSlice> fundamental_smc_addr) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons31& data) const;
  bool cell_pack_cons31(Ref<vm::Cell>& cell_ref, Ref<CellSlice> fundamental_smc_addr) const;
  bool unpack(vm::CellSlice& cs, Record_cons32& data) const;
  bool unpack_cons32(vm::CellSlice& cs, Ref<CellSlice>& prev_validators) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons32& data) const;
  bool cell_unpack_cons32(Ref<vm::Cell> cell_ref, Ref<CellSlice>& prev_validators) const;
  bool pack(vm::CellBuilder& cb, const Record_cons32& data) const;
  bool pack_cons32(vm::CellBuilder& cb, Ref<CellSlice> prev_validators) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons32& data) const;
  bool cell_pack_cons32(Ref<vm::Cell>& cell_ref, Ref<CellSlice> prev_validators) const;
  bool unpack(vm::CellSlice& cs, Record_cons33& data) const;
  bool unpack_cons33(vm::CellSlice& cs, Ref<CellSlice>& prev_temp_validators) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons33& data) const;
  bool cell_unpack_cons33(Ref<vm::Cell> cell_ref, Ref<CellSlice>& prev_temp_validators) const;
  bool pack(vm::CellBuilder& cb, const Record_cons33& data) const;
  bool pack_cons33(vm::CellBuilder& cb, Ref<CellSlice> prev_temp_validators) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons33& data) const;
  bool cell_pack_cons33(Ref<vm::Cell>& cell_ref, Ref<CellSlice> prev_temp_validators) const;
  bool unpack(vm::CellSlice& cs, Record_cons34& data) const;
  bool unpack_cons34(vm::CellSlice& cs, Ref<CellSlice>& cur_validators) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons34& data) const;
  bool cell_unpack_cons34(Ref<vm::Cell> cell_ref, Ref<CellSlice>& cur_validators) const;
  bool pack(vm::CellBuilder& cb, const Record_cons34& data) const;
  bool pack_cons34(vm::CellBuilder& cb, Ref<CellSlice> cur_validators) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons34& data) const;
  bool cell_pack_cons34(Ref<vm::Cell>& cell_ref, Ref<CellSlice> cur_validators) const;
  bool unpack(vm::CellSlice& cs, Record_cons35& data) const;
  bool unpack_cons35(vm::CellSlice& cs, Ref<CellSlice>& cur_temp_validators) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons35& data) const;
  bool cell_unpack_cons35(Ref<vm::Cell> cell_ref, Ref<CellSlice>& cur_temp_validators) const;
  bool pack(vm::CellBuilder& cb, const Record_cons35& data) const;
  bool pack_cons35(vm::CellBuilder& cb, Ref<CellSlice> cur_temp_validators) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons35& data) const;
  bool cell_pack_cons35(Ref<vm::Cell>& cell_ref, Ref<CellSlice> cur_temp_validators) const;
  bool unpack(vm::CellSlice& cs, Record_cons36& data) const;
  bool unpack_cons36(vm::CellSlice& cs, Ref<CellSlice>& next_validators) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons36& data) const;
  bool cell_unpack_cons36(Ref<vm::Cell> cell_ref, Ref<CellSlice>& next_validators) const;
  bool pack(vm::CellBuilder& cb, const Record_cons36& data) const;
  bool pack_cons36(vm::CellBuilder& cb, Ref<CellSlice> next_validators) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons36& data) const;
  bool cell_pack_cons36(Ref<vm::Cell>& cell_ref, Ref<CellSlice> next_validators) const;
  bool unpack(vm::CellSlice& cs, Record_cons37& data) const;
  bool unpack_cons37(vm::CellSlice& cs, Ref<CellSlice>& next_temp_validators) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons37& data) const;
  bool cell_unpack_cons37(Ref<vm::Cell> cell_ref, Ref<CellSlice>& next_temp_validators) const;
  bool pack(vm::CellBuilder& cb, const Record_cons37& data) const;
  bool pack_cons37(vm::CellBuilder& cb, Ref<CellSlice> next_temp_validators) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons37& data) const;
  bool cell_pack_cons37(Ref<vm::Cell>& cell_ref, Ref<CellSlice> next_temp_validators) const;
  bool unpack(vm::CellSlice& cs, Record_cons39& data) const;
  bool unpack_cons39(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons39& data) const;
  bool cell_unpack_cons39(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons39& data) const;
  bool pack_cons39(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons39& data) const;
  bool cell_pack_cons39(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons40& data) const;
  bool unpack_cons40(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons40& data) const;
  bool cell_unpack_cons40(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons40& data) const;
  bool pack_cons40(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons40& data) const;
  bool cell_pack_cons40(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons43& data) const;
  bool unpack_cons43(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons43& data) const;
  bool cell_unpack_cons43(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons43& data) const;
  bool pack_cons43(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons43& data) const;
  bool cell_pack_cons43(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons44& data) const;
  bool unpack_cons44(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons44& data) const;
  bool cell_unpack_cons44(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons44& data) const;
  bool pack_cons44(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons44& data) const;
  bool cell_pack_cons44(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons45& data) const;
  bool unpack_cons45(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons45& data) const;
  bool cell_unpack_cons45(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons45& data) const;
  bool pack_cons45(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons45& data) const;
  bool cell_pack_cons45(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons71& data) const;
  bool unpack_cons71(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons71& data) const;
  bool cell_unpack_cons71(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons71& data) const;
  bool pack_cons71(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons71& data) const;
  bool cell_pack_cons71(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons72& data) const;
  bool unpack_cons72(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons72& data) const;
  bool cell_unpack_cons72(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons72& data) const;
  bool pack_cons72(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons72& data) const;
  bool cell_pack_cons72(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons73& data) const;
  bool unpack_cons73(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons73& data) const;
  bool cell_unpack_cons73(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons73& data) const;
  bool pack_cons73(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons73& data) const;
  bool cell_pack_cons73(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons79& data) const;
  bool unpack_cons79(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons79& data) const;
  bool cell_unpack_cons79(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons79& data) const;
  bool pack_cons79(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons79& data) const;
  bool cell_pack_cons79(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons81& data) const;
  bool unpack_cons81(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons81& data) const;
  bool cell_unpack_cons81(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons81& data) const;
  bool pack_cons81(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons81& data) const;
  bool cell_pack_cons81(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons82& data) const;
  bool unpack_cons82(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons82& data) const;
  bool cell_unpack_cons82(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons82& data) const;
  bool pack_cons82(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons82& data) const;
  bool cell_pack_cons82(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons83& data) const;
  bool unpack_cons83(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons83& data) const;
  bool cell_unpack_cons83(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons83& data) const;
  bool pack_cons83(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons83& data) const;
  bool cell_pack_cons83(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_cons84& data) const;
  bool unpack_cons84(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cons84& data) const;
  bool cell_unpack_cons84(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_cons84& data) const;
  bool pack_cons84(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cons84& data) const;
  bool cell_pack_cons84(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(ConfigParam " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct ConfigParam::Record_cons15 {
  typedef ConfigParam type_class;
  unsigned validators_elected_for;  	// validators_elected_for : uint32
  unsigned elections_start_before;  	// elections_start_before : uint32
  unsigned elections_end_before;  	// elections_end_before : uint32
  unsigned stake_held_for;  	// stake_held_for : uint32
};

struct ConfigParam::Record_cons16 {
  typedef ConfigParam type_class;
  unsigned max_validators;  	// max_validators : ## 16
  unsigned max_main_validators;  	// max_main_validators : ## 16
  unsigned min_validators;  	// min_validators : ## 16
};

struct ConfigParam::Record_cons17 {
  typedef ConfigParam type_class;
  Ref<CellSlice> min_stake;  	// min_stake : Tomis
  Ref<CellSlice> max_stake;  	// max_stake : Tomis
  Ref<CellSlice> min_total_stake;  	// min_total_stake : Tomis
  unsigned max_stake_factor;  	// max_stake_factor : uint32
};

//
// headers for type `BlockSignatures`
//

struct BlockSignatures final : TLB_Complex {
  enum { block_signatures_ordinary, block_signatures_simplex };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[2] = { 17, 18 };
  struct Record_block_signatures_ordinary;
  struct Record_block_signatures_simplex;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_block_signatures_ordinary& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_block_signatures_ordinary& data) const;
  bool pack(vm::CellBuilder& cb, const Record_block_signatures_ordinary& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_block_signatures_ordinary& data) const;
  bool unpack(vm::CellSlice& cs, Record_block_signatures_simplex& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_block_signatures_simplex& data) const;
  bool pack(vm::CellBuilder& cb, const Record_block_signatures_simplex& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_block_signatures_simplex& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BlockSignatures";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct BlockSignatures::Record_block_signatures_ordinary {
  typedef BlockSignatures type_class;
  unsigned validator_list_hash_short;  	// validator_list_hash_short : uint32
  unsigned catchain_seqno;  	// catchain_seqno : uint32
  unsigned sig_count;  	// sig_count : uint32
  unsigned long long sig_weight;  	// sig_weight : uint64
  Ref<CellSlice> signatures;  	// signatures : HashmapE 16 CryptoSignaturePair
};

struct BlockSignatures::Record_block_signatures_simplex {
  typedef BlockSignatures type_class;
  unsigned validator_list_hash_short;  	// validator_list_hash_short : uint32
  unsigned catchain_seqno;  	// catchain_seqno : uint32
  unsigned sig_count;  	// sig_count : uint32
  unsigned long long sig_weight;  	// sig_weight : uint64
  Ref<CellSlice> signatures;  	// signatures : HashmapE 16 CryptoSignaturePair
  td::BitArray<256> session_id;  	// session_id : bits256
  unsigned slot;  	// slot : uint32
  Ref<Cell> candidate_data;  	// candidate_data : ^Cell
};

extern const BlockSignatures t_BlockSignatures;

//
// headers for type `BlockProof`
//

struct BlockProof final : TLB_Complex {
  enum { block_proof };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0xc3 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_block_proof(vm::CellSlice& cs, Ref<CellSlice>& proof_for, Ref<Cell>& root, Ref<CellSlice>& signatures) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_block_proof(Ref<vm::Cell> cell_ref, Ref<CellSlice>& proof_for, Ref<Cell>& root, Ref<CellSlice>& signatures) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_block_proof(vm::CellBuilder& cb, Ref<CellSlice> proof_for, Ref<Cell> root, Ref<CellSlice> signatures) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_block_proof(Ref<vm::Cell>& cell_ref, Ref<CellSlice> proof_for, Ref<Cell> root, Ref<CellSlice> signatures) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BlockProof";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct BlockProof::Record {
  typedef BlockProof type_class;
  Ref<CellSlice> proof_for;  	// proof_for : BlockIdExt
  Ref<Cell> root;  	// root : ^Cell
  Ref<CellSlice> signatures;  	// signatures : Maybe ^BlockSignatures
};

extern const BlockProof t_BlockProof;

//
// headers for type `ProofChain`
//

struct ProofChain final : TLB_Complex {
  enum { chain_empty, chain_link };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  ProofChain(unsigned m) : m_(m) {}
  struct Record_chain_empty {
    typedef ProofChain type_class;
  };
  struct Record_chain_link;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_chain_empty& data) const;
  bool unpack_chain_empty(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_chain_empty& data) const;
  bool cell_unpack_chain_empty(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_chain_empty& data) const;
  bool pack_chain_empty(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_chain_empty& data) const;
  bool cell_pack_chain_empty(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_chain_link& data) const;
  bool unpack_chain_link(vm::CellSlice& cs, unsigned& n, Ref<Cell>& root, Ref<Cell>& prev) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_chain_link& data) const;
  bool cell_unpack_chain_link(Ref<vm::Cell> cell_ref, unsigned& n, Ref<Cell>& root, Ref<Cell>& prev) const;
  bool pack(vm::CellBuilder& cb, const Record_chain_link& data) const;
  bool pack_chain_link(vm::CellBuilder& cb, Ref<Cell> root, Ref<Cell> prev) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_chain_link& data) const;
  bool cell_pack_chain_link(Ref<vm::Cell>& cell_ref, Ref<Cell> root, Ref<Cell> prev) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(ProofChain " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct ProofChain::Record_chain_link {
  typedef ProofChain type_class;
  unsigned n;  	// n : #
  Ref<Cell> root;  	// root : ^Cell
  Ref<Cell> prev;  	// prev : n?^(ProofChain n)
};

//
// headers for type `TopBlockDescr`
//

struct TopBlockDescr final : TLB_Complex {
  enum { top_block_descr };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0xd5 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "TopBlockDescr";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct TopBlockDescr::Record {
  typedef TopBlockDescr type_class;
  Ref<CellSlice> proof_for;  	// proof_for : BlockIdExt
  Ref<CellSlice> signatures;  	// signatures : Maybe ^BlockSignatures
  unsigned len;  	// len : ## 8
  Ref<CellSlice> chain;  	// chain : ProofChain len
};

extern const TopBlockDescr t_TopBlockDescr;

//
// headers for type `TopBlockDescrSet`
//

struct TopBlockDescrSet final : TLB_Complex {
  enum { top_block_descr_set };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x4ac789f3 };
  struct Record {
    typedef TopBlockDescrSet type_class;
    Ref<CellSlice> collection;  	// collection : HashmapE 96 ^TopBlockDescr
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_top_block_descr_set(vm::CellSlice& cs, Ref<CellSlice>& collection) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_top_block_descr_set(Ref<vm::Cell> cell_ref, Ref<CellSlice>& collection) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_top_block_descr_set(vm::CellBuilder& cb, Ref<CellSlice> collection) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_top_block_descr_set(Ref<vm::Cell>& cell_ref, Ref<CellSlice> collection) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "TopBlockDescrSet";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const TopBlockDescrSet t_TopBlockDescrSet;

//
// headers for type `AccountStorageDictProof`
//

struct AccountStorageDictProof final : TLB_Complex {
  enum { account_storage_dict_proof };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x37c1e3fc };
  struct Record {
    typedef AccountStorageDictProof type_class;
    Ref<Cell> proof;  	// proof : ^Cell
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 0x10020;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x10020);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_account_storage_dict_proof(vm::CellSlice& cs, Ref<Cell>& proof) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_account_storage_dict_proof(Ref<vm::Cell> cell_ref, Ref<Cell>& proof) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_account_storage_dict_proof(vm::CellBuilder& cb, Ref<Cell> proof) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_account_storage_dict_proof(Ref<vm::Cell>& cell_ref, Ref<Cell> proof) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "AccountStorageDictProof";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const AccountStorageDictProof t_AccountStorageDictProof;

//
// headers for type `ConsensusExtraData`
//

struct ConsensusExtraData final : TLB_Complex {
  enum { consensus_extra_data };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x638eb292 };
  struct Record {
    typedef ConsensusExtraData type_class;
    unsigned flags;  	// flags : #
    unsigned long long gen_utime_ms;  	// gen_utime_ms : uint64
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 128;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(128);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_consensus_extra_data(vm::CellSlice& cs, unsigned& flags, unsigned long long& gen_utime_ms) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_consensus_extra_data(Ref<vm::Cell> cell_ref, unsigned& flags, unsigned long long& gen_utime_ms) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_consensus_extra_data(vm::CellBuilder& cb, unsigned flags, unsigned long long gen_utime_ms) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_consensus_extra_data(Ref<vm::Cell>& cell_ref, unsigned flags, unsigned long long gen_utime_ms) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ConsensusExtraData";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ConsensusExtraData t_ConsensusExtraData;

//
// headers for type `ProducerInfo`
//

struct ProducerInfo final : TLB_Complex {
  enum { prod_info };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0x34 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 0x20288;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x20288);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ProducerInfo";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ProducerInfo::Record {
  typedef ProducerInfo type_class;
  unsigned utime;  	// utime : uint32
  Ref<CellSlice> mc_blk_ref;  	// mc_blk_ref : ExtBlkRef
  Ref<Cell> state_proof;  	// state_proof : ^(MERKLE_PROOF Block)
  Ref<Cell> prod_proof;  	// prod_proof : ^(MERKLE_PROOF ShardState)
};

extern const ProducerInfo t_ProducerInfo;

//
// headers for type `ComplaintDescr`
//

struct ComplaintDescr final : TLB_Complex {
  enum { no_blk_gen, no_blk_gen_diff };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[2] = { 0x450e8bd9, 0xc737b0caU };
  struct Record_no_blk_gen {
    typedef ComplaintDescr type_class;
    unsigned from_utime;  	// from_utime : uint32
    Ref<Cell> prod_info;  	// prod_info : ^ProducerInfo
  };
  struct Record_no_blk_gen_diff {
    typedef ComplaintDescr type_class;
    Ref<Cell> prod_info_old;  	// prod_info_old : ^ProducerInfo
    Ref<Cell> prod_info_new;  	// prod_info_new : ^ProducerInfo
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_no_blk_gen& data) const;
  bool unpack_no_blk_gen(vm::CellSlice& cs, unsigned& from_utime, Ref<Cell>& prod_info) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_no_blk_gen& data) const;
  bool cell_unpack_no_blk_gen(Ref<vm::Cell> cell_ref, unsigned& from_utime, Ref<Cell>& prod_info) const;
  bool pack(vm::CellBuilder& cb, const Record_no_blk_gen& data) const;
  bool pack_no_blk_gen(vm::CellBuilder& cb, unsigned from_utime, Ref<Cell> prod_info) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_no_blk_gen& data) const;
  bool cell_pack_no_blk_gen(Ref<vm::Cell>& cell_ref, unsigned from_utime, Ref<Cell> prod_info) const;
  bool unpack(vm::CellSlice& cs, Record_no_blk_gen_diff& data) const;
  bool unpack_no_blk_gen_diff(vm::CellSlice& cs, Ref<Cell>& prod_info_old, Ref<Cell>& prod_info_new) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_no_blk_gen_diff& data) const;
  bool cell_unpack_no_blk_gen_diff(Ref<vm::Cell> cell_ref, Ref<Cell>& prod_info_old, Ref<Cell>& prod_info_new) const;
  bool pack(vm::CellBuilder& cb, const Record_no_blk_gen_diff& data) const;
  bool pack_no_blk_gen_diff(vm::CellBuilder& cb, Ref<Cell> prod_info_old, Ref<Cell> prod_info_new) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_no_blk_gen_diff& data) const;
  bool cell_pack_no_blk_gen_diff(Ref<vm::Cell>& cell_ref, Ref<Cell> prod_info_old, Ref<Cell> prod_info_new) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ComplaintDescr";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

extern const ComplaintDescr t_ComplaintDescr;

//
// headers for type `ValidatorComplaint`
//

struct ValidatorComplaint final : TLB_Complex {
  enum { validator_complaint };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0xbc };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ValidatorComplaint";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ValidatorComplaint::Record {
  typedef ValidatorComplaint type_class;
  td::BitArray<256> validator_pubkey;  	// validator_pubkey : bits256
  Ref<Cell> description;  	// description : ^ComplaintDescr
  unsigned created_at;  	// created_at : uint32
  int severity;  	// severity : uint8
  RefInt256 reward_addr;  	// reward_addr : uint256
  Ref<CellSlice> paid;  	// paid : Tomis
  Ref<CellSlice> suggested_fine;  	// suggested_fine : Tomis
  unsigned suggested_fine_part;  	// suggested_fine_part : uint32
};

extern const ValidatorComplaint t_ValidatorComplaint;

//
// headers for type `ValidatorComplaintStatus`
//

struct ValidatorComplaintStatus final : TLB_Complex {
  enum { complaint_status };
  static constexpr int cons_len_exact = 8;
  static constexpr unsigned char cons_tag[1] = { 0x2d };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ValidatorComplaintStatus";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ValidatorComplaintStatus::Record {
  typedef ValidatorComplaintStatus type_class;
  Ref<Cell> complaint;  	// complaint : ^ValidatorComplaint
  Ref<CellSlice> voters;  	// voters : HashmapE 16 True
  RefInt256 vset_id;  	// vset_id : uint256
  long long weight_remaining;  	// weight_remaining : int64
};

extern const ValidatorComplaintStatus t_ValidatorComplaintStatus;

//
// headers for type `VmCellSlice`
//

struct VmCellSlice final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 0x1001a;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x1001a);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "VmCellSlice";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct VmCellSlice::Record {
  typedef VmCellSlice type_class;
  Ref<Cell> cell;  	// cell : ^Cell
  unsigned st_bits;  	// st_bits : ## 10
  unsigned end_bits;  	// end_bits : ## 10
  unsigned st_ref;  	// st_ref : #<= 4
  unsigned end_ref;  	// end_ref : #<= 4
};

extern const VmCellSlice t_VmCellSlice;

//
// headers for type `VmTupleRef`
//

struct VmTupleRef final : TLB_Complex {
  enum { vm_tupref_nil, vm_tupref_single, vm_tupref_any };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  VmTupleRef(unsigned m) : m_(m) {}
  struct Record_vm_tupref_nil {
    typedef VmTupleRef type_class;
  };
  struct Record_vm_tupref_single {
    typedef VmTupleRef type_class;
    Ref<Cell> entry;  	// entry : ^VmStackValue
  };
  struct Record_vm_tupref_any {
    typedef VmTupleRef type_class;
    unsigned n;  	// n : #
    Ref<Cell> ref;  	// ref : ^(VmTuple (n + 2))
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_vm_tupref_nil& data) const;
  bool unpack_vm_tupref_nil(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_tupref_nil& data) const;
  bool cell_unpack_vm_tupref_nil(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_tupref_nil& data) const;
  bool pack_vm_tupref_nil(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_tupref_nil& data) const;
  bool cell_pack_vm_tupref_nil(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_vm_tupref_single& data) const;
  bool unpack_vm_tupref_single(vm::CellSlice& cs, Ref<Cell>& entry) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_tupref_single& data) const;
  bool cell_unpack_vm_tupref_single(Ref<vm::Cell> cell_ref, Ref<Cell>& entry) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_tupref_single& data) const;
  bool pack_vm_tupref_single(vm::CellBuilder& cb, Ref<Cell> entry) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_tupref_single& data) const;
  bool cell_pack_vm_tupref_single(Ref<vm::Cell>& cell_ref, Ref<Cell> entry) const;
  bool unpack(vm::CellSlice& cs, Record_vm_tupref_any& data) const;
  bool unpack_vm_tupref_any(vm::CellSlice& cs, unsigned& n, Ref<Cell>& ref) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_tupref_any& data) const;
  bool cell_unpack_vm_tupref_any(Ref<vm::Cell> cell_ref, unsigned& n, Ref<Cell>& ref) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_tupref_any& data) const;
  bool pack_vm_tupref_any(vm::CellBuilder& cb, Ref<Cell> ref) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_tupref_any& data) const;
  bool cell_pack_vm_tupref_any(Ref<vm::Cell>& cell_ref, Ref<Cell> ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(VmTupleRef " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

//
// headers for type `VmTuple`
//

struct VmTuple final : TLB_Complex {
  enum { vm_tuple_nil, vm_tuple_tcons };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  VmTuple(unsigned m) : m_(m) {}
  struct Record_vm_tuple_nil {
    typedef VmTuple type_class;
  };
  struct Record_vm_tuple_tcons;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_vm_tuple_nil& data) const;
  bool unpack_vm_tuple_nil(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_tuple_nil& data) const;
  bool cell_unpack_vm_tuple_nil(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_tuple_nil& data) const;
  bool pack_vm_tuple_nil(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_tuple_nil& data) const;
  bool cell_pack_vm_tuple_nil(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_vm_tuple_tcons& data) const;
  bool unpack_vm_tuple_tcons(vm::CellSlice& cs, unsigned& n, Ref<CellSlice>& head, Ref<Cell>& tail) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_tuple_tcons& data) const;
  bool cell_unpack_vm_tuple_tcons(Ref<vm::Cell> cell_ref, unsigned& n, Ref<CellSlice>& head, Ref<Cell>& tail) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_tuple_tcons& data) const;
  bool pack_vm_tuple_tcons(vm::CellBuilder& cb, Ref<CellSlice> head, Ref<Cell> tail) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_tuple_tcons& data) const;
  bool cell_pack_vm_tuple_tcons(Ref<vm::Cell>& cell_ref, Ref<CellSlice> head, Ref<Cell> tail) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(VmTuple " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct VmTuple::Record_vm_tuple_tcons {
  typedef VmTuple type_class;
  unsigned n;  	// n : #
  Ref<CellSlice> head;  	// head : VmTupleRef n
  Ref<Cell> tail;  	// tail : ^VmStackValue
};

//
// headers for type `VmStackValue`
//

struct VmStackValue final : TLB_Complex {
  enum { vm_stk_null, vm_stk_tinyint, vm_stk_int, vm_stk_nan, vm_stk_cell, vm_stk_slice, vm_stk_builder, vm_stk_cont, vm_stk_tuple };
  static constexpr char cons_len[9] = { 8, 8, 15, 16, 8, 8, 8, 8, 8 };
  static constexpr unsigned short cons_tag[9] = { 0, 1, 0x100, 0x2ff, 3, 4, 5, 6, 7 };
  struct Record_vm_stk_null {
    typedef VmStackValue type_class;
  };
  struct Record_vm_stk_tinyint {
    typedef VmStackValue type_class;
    long long value;  	// value : int64
  };
  struct Record_vm_stk_int {
    typedef VmStackValue type_class;
    RefInt256 value;  	// value : int257
  };
  struct Record_vm_stk_nan {
    typedef VmStackValue type_class;
  };
  struct Record_vm_stk_cell {
    typedef VmStackValue type_class;
    Ref<Cell> cell;  	// cell : ^Cell
  };
  struct Record_vm_stk_slice {
    typedef VmStackValue type_class;
    Ref<CellSlice> x;  	// VmCellSlice
  };
  struct Record_vm_stk_builder {
    typedef VmStackValue type_class;
    Ref<Cell> cell;  	// cell : ^Cell
  };
  struct Record_vm_stk_cont {
    typedef VmStackValue type_class;
    Ref<CellSlice> cont;  	// cont : VmCont
  };
  struct Record_vm_stk_tuple {
    typedef VmStackValue type_class;
    unsigned len;  	// len : ## 16
    Ref<CellSlice> data;  	// data : VmTuple len
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_vm_stk_null& data) const;
  bool unpack_vm_stk_null(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_stk_null& data) const;
  bool cell_unpack_vm_stk_null(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_stk_null& data) const;
  bool pack_vm_stk_null(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_stk_null& data) const;
  bool cell_pack_vm_stk_null(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_vm_stk_tinyint& data) const;
  bool unpack_vm_stk_tinyint(vm::CellSlice& cs, long long& value) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_stk_tinyint& data) const;
  bool cell_unpack_vm_stk_tinyint(Ref<vm::Cell> cell_ref, long long& value) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_stk_tinyint& data) const;
  bool pack_vm_stk_tinyint(vm::CellBuilder& cb, long long value) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_stk_tinyint& data) const;
  bool cell_pack_vm_stk_tinyint(Ref<vm::Cell>& cell_ref, long long value) const;
  bool unpack(vm::CellSlice& cs, Record_vm_stk_int& data) const;
  bool unpack_vm_stk_int(vm::CellSlice& cs, RefInt256& value) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_stk_int& data) const;
  bool cell_unpack_vm_stk_int(Ref<vm::Cell> cell_ref, RefInt256& value) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_stk_int& data) const;
  bool pack_vm_stk_int(vm::CellBuilder& cb, RefInt256 value) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_stk_int& data) const;
  bool cell_pack_vm_stk_int(Ref<vm::Cell>& cell_ref, RefInt256 value) const;
  bool unpack(vm::CellSlice& cs, Record_vm_stk_nan& data) const;
  bool unpack_vm_stk_nan(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_stk_nan& data) const;
  bool cell_unpack_vm_stk_nan(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_stk_nan& data) const;
  bool pack_vm_stk_nan(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_stk_nan& data) const;
  bool cell_pack_vm_stk_nan(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_vm_stk_cell& data) const;
  bool unpack_vm_stk_cell(vm::CellSlice& cs, Ref<Cell>& cell) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_stk_cell& data) const;
  bool cell_unpack_vm_stk_cell(Ref<vm::Cell> cell_ref, Ref<Cell>& cell) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_stk_cell& data) const;
  bool pack_vm_stk_cell(vm::CellBuilder& cb, Ref<Cell> cell) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_stk_cell& data) const;
  bool cell_pack_vm_stk_cell(Ref<vm::Cell>& cell_ref, Ref<Cell> cell) const;
  bool unpack(vm::CellSlice& cs, Record_vm_stk_slice& data) const;
  bool unpack_vm_stk_slice(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_stk_slice& data) const;
  bool cell_unpack_vm_stk_slice(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_stk_slice& data) const;
  bool pack_vm_stk_slice(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_stk_slice& data) const;
  bool cell_pack_vm_stk_slice(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_vm_stk_builder& data) const;
  bool unpack_vm_stk_builder(vm::CellSlice& cs, Ref<Cell>& cell) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_stk_builder& data) const;
  bool cell_unpack_vm_stk_builder(Ref<vm::Cell> cell_ref, Ref<Cell>& cell) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_stk_builder& data) const;
  bool pack_vm_stk_builder(vm::CellBuilder& cb, Ref<Cell> cell) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_stk_builder& data) const;
  bool cell_pack_vm_stk_builder(Ref<vm::Cell>& cell_ref, Ref<Cell> cell) const;
  bool unpack(vm::CellSlice& cs, Record_vm_stk_cont& data) const;
  bool unpack_vm_stk_cont(vm::CellSlice& cs, Ref<CellSlice>& cont) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_stk_cont& data) const;
  bool cell_unpack_vm_stk_cont(Ref<vm::Cell> cell_ref, Ref<CellSlice>& cont) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_stk_cont& data) const;
  bool pack_vm_stk_cont(vm::CellBuilder& cb, Ref<CellSlice> cont) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_stk_cont& data) const;
  bool cell_pack_vm_stk_cont(Ref<vm::Cell>& cell_ref, Ref<CellSlice> cont) const;
  bool unpack(vm::CellSlice& cs, Record_vm_stk_tuple& data) const;
  bool unpack_vm_stk_tuple(vm::CellSlice& cs, unsigned& len, Ref<CellSlice>& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_stk_tuple& data) const;
  bool cell_unpack_vm_stk_tuple(Ref<vm::Cell> cell_ref, unsigned& len, Ref<CellSlice>& data) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_stk_tuple& data) const;
  bool pack_vm_stk_tuple(vm::CellBuilder& cb, unsigned len, Ref<CellSlice> data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_stk_tuple& data) const;
  bool cell_pack_vm_stk_tuple(Ref<vm::Cell>& cell_ref, unsigned len, Ref<CellSlice> data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "VmStackValue";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

extern const VmStackValue t_VmStackValue;

//
// headers for type `VmStack`
//

struct VmStack final : TLB_Complex {
  enum { vm_stack };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef VmStack type_class;
    unsigned depth;  	// depth : ## 24
    Ref<CellSlice> stack;  	// stack : VmStackList depth
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_vm_stack(vm::CellSlice& cs, unsigned& depth, Ref<CellSlice>& stack) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_vm_stack(Ref<vm::Cell> cell_ref, unsigned& depth, Ref<CellSlice>& stack) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_vm_stack(vm::CellBuilder& cb, unsigned depth, Ref<CellSlice> stack) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_vm_stack(Ref<vm::Cell>& cell_ref, unsigned depth, Ref<CellSlice> stack) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "VmStack";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const VmStack t_VmStack;

//
// headers for type `VmStackList`
//

struct VmStackList final : TLB_Complex {
  enum { vm_stk_cons, vm_stk_nil };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  VmStackList(unsigned m) : m_(m) {}
  struct Record_vm_stk_cons;
  struct Record_vm_stk_nil {
    typedef VmStackList type_class;
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_vm_stk_cons& data) const;
  bool unpack_vm_stk_cons(vm::CellSlice& cs, unsigned& n, Ref<Cell>& rest, Ref<CellSlice>& tos) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_stk_cons& data) const;
  bool cell_unpack_vm_stk_cons(Ref<vm::Cell> cell_ref, unsigned& n, Ref<Cell>& rest, Ref<CellSlice>& tos) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_stk_cons& data) const;
  bool pack_vm_stk_cons(vm::CellBuilder& cb, Ref<Cell> rest, Ref<CellSlice> tos) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_stk_cons& data) const;
  bool cell_pack_vm_stk_cons(Ref<vm::Cell>& cell_ref, Ref<Cell> rest, Ref<CellSlice> tos) const;
  bool unpack(vm::CellSlice& cs, Record_vm_stk_nil& data) const;
  bool unpack_vm_stk_nil(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vm_stk_nil& data) const;
  bool cell_unpack_vm_stk_nil(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_vm_stk_nil& data) const;
  bool pack_vm_stk_nil(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vm_stk_nil& data) const;
  bool cell_pack_vm_stk_nil(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(VmStackList " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct VmStackList::Record_vm_stk_cons {
  typedef VmStackList type_class;
  unsigned n;  	// n : #
  Ref<Cell> rest;  	// rest : ^(VmStackList n)
  Ref<CellSlice> tos;  	// tos : VmStackValue
};

//
// headers for type `VmSaveList`
//

struct VmSaveList final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef VmSaveList type_class;
    Ref<CellSlice> cregs;  	// cregs : HashmapE 4 VmStackValue
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& cregs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& cregs) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> cregs) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> cregs) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "VmSaveList";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const VmSaveList t_VmSaveList;

//
// headers for auxiliary type `VmGasLimits_aux`
//

struct VmGasLimits_aux final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 192;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(192);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(192);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, long long& max_limit, long long& cur_limit, long long& credit) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, long long& max_limit, long long& cur_limit, long long& credit) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, long long max_limit, long long cur_limit, long long credit) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, long long max_limit, long long cur_limit, long long credit) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "VmGasLimits_aux";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct VmGasLimits_aux::Record {
  typedef VmGasLimits_aux type_class;
  long long max_limit;  	// max_limit : int64
  long long cur_limit;  	// cur_limit : int64
  long long credit;  	// credit : int64
};

extern const VmGasLimits_aux t_VmGasLimits_aux;

//
// headers for type `VmGasLimits`
//

struct VmGasLimits final : TLB_Complex {
  enum { gas_limits };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef VmGasLimits type_class;
    long long remaining;  	// remaining : int64
    VmGasLimits_aux::Record r1;  	// ^[$_ max_limit:int64 cur_limit:int64 credit:int64 ]
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 0x10040;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x10040);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "VmGasLimits";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const VmGasLimits t_VmGasLimits;

//
// headers for type `VmLibraries`
//

struct VmLibraries final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef VmLibraries type_class;
    Ref<CellSlice> libraries;  	// libraries : HashmapE 256 ^Cell
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& libraries) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& libraries) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> libraries) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> libraries) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "VmLibraries";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const VmLibraries t_VmLibraries;

//
// headers for type `VmControlData`
//

struct VmControlData final : TLB_Complex {
  enum { vm_ctl_data };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "VmControlData";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct VmControlData::Record {
  typedef VmControlData type_class;
  Ref<CellSlice> nargs;  	// nargs : Maybe uint13
  Ref<CellSlice> stack;  	// stack : Maybe VmStack
  Ref<CellSlice> save;  	// save : VmSaveList
  Ref<CellSlice> cp;  	// cp : Maybe int16
};

extern const VmControlData t_VmControlData;

//
// headers for type `VmCont`
//

struct VmCont final : TLB_Complex {
  enum { vmc_std, vmc_envelope, vmc_quit, vmc_quit_exc, vmc_repeat, vmc_until, vmc_again, vmc_while_cond, vmc_while_body, vmc_pushint };
  static constexpr char cons_len[10] = { 2, 2, 4, 4, 5, 6, 6, 6, 6, 4 };
  static constexpr unsigned char cons_tag[10] = { 0, 1, 8, 9, 20, 0x30, 0x31, 0x32, 0x33, 15 };
  struct Record_vmc_std {
    typedef VmCont type_class;
    Ref<CellSlice> cdata;  	// cdata : VmControlData
    Ref<CellSlice> code;  	// code : VmCellSlice
  };
  struct Record_vmc_envelope {
    typedef VmCont type_class;
    Ref<CellSlice> cdata;  	// cdata : VmControlData
    Ref<Cell> next;  	// next : ^VmCont
  };
  struct Record_vmc_quit {
    typedef VmCont type_class;
    int exit_code;  	// exit_code : int32
  };
  struct Record_vmc_quit_exc {
    typedef VmCont type_class;
  };
  struct Record_vmc_repeat;
  struct Record_vmc_until {
    typedef VmCont type_class;
    Ref<Cell> body;  	// body : ^VmCont
    Ref<Cell> after;  	// after : ^VmCont
  };
  struct Record_vmc_again {
    typedef VmCont type_class;
    Ref<Cell> body;  	// body : ^VmCont
  };
  struct Record_vmc_while_cond;
  struct Record_vmc_while_body;
  struct Record_vmc_pushint {
    typedef VmCont type_class;
    int value;  	// value : int32
    Ref<Cell> next;  	// next : ^VmCont
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_vmc_std& data) const;
  bool unpack_vmc_std(vm::CellSlice& cs, Ref<CellSlice>& cdata, Ref<CellSlice>& code) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vmc_std& data) const;
  bool cell_unpack_vmc_std(Ref<vm::Cell> cell_ref, Ref<CellSlice>& cdata, Ref<CellSlice>& code) const;
  bool pack(vm::CellBuilder& cb, const Record_vmc_std& data) const;
  bool pack_vmc_std(vm::CellBuilder& cb, Ref<CellSlice> cdata, Ref<CellSlice> code) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vmc_std& data) const;
  bool cell_pack_vmc_std(Ref<vm::Cell>& cell_ref, Ref<CellSlice> cdata, Ref<CellSlice> code) const;
  bool unpack(vm::CellSlice& cs, Record_vmc_envelope& data) const;
  bool unpack_vmc_envelope(vm::CellSlice& cs, Ref<CellSlice>& cdata, Ref<Cell>& next) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vmc_envelope& data) const;
  bool cell_unpack_vmc_envelope(Ref<vm::Cell> cell_ref, Ref<CellSlice>& cdata, Ref<Cell>& next) const;
  bool pack(vm::CellBuilder& cb, const Record_vmc_envelope& data) const;
  bool pack_vmc_envelope(vm::CellBuilder& cb, Ref<CellSlice> cdata, Ref<Cell> next) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vmc_envelope& data) const;
  bool cell_pack_vmc_envelope(Ref<vm::Cell>& cell_ref, Ref<CellSlice> cdata, Ref<Cell> next) const;
  bool unpack(vm::CellSlice& cs, Record_vmc_quit& data) const;
  bool unpack_vmc_quit(vm::CellSlice& cs, int& exit_code) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vmc_quit& data) const;
  bool cell_unpack_vmc_quit(Ref<vm::Cell> cell_ref, int& exit_code) const;
  bool pack(vm::CellBuilder& cb, const Record_vmc_quit& data) const;
  bool pack_vmc_quit(vm::CellBuilder& cb, int exit_code) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vmc_quit& data) const;
  bool cell_pack_vmc_quit(Ref<vm::Cell>& cell_ref, int exit_code) const;
  bool unpack(vm::CellSlice& cs, Record_vmc_quit_exc& data) const;
  bool unpack_vmc_quit_exc(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vmc_quit_exc& data) const;
  bool cell_unpack_vmc_quit_exc(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_vmc_quit_exc& data) const;
  bool pack_vmc_quit_exc(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vmc_quit_exc& data) const;
  bool cell_pack_vmc_quit_exc(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_vmc_repeat& data) const;
  bool unpack_vmc_repeat(vm::CellSlice& cs, long long& count, Ref<Cell>& body, Ref<Cell>& after) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vmc_repeat& data) const;
  bool cell_unpack_vmc_repeat(Ref<vm::Cell> cell_ref, long long& count, Ref<Cell>& body, Ref<Cell>& after) const;
  bool pack(vm::CellBuilder& cb, const Record_vmc_repeat& data) const;
  bool pack_vmc_repeat(vm::CellBuilder& cb, long long count, Ref<Cell> body, Ref<Cell> after) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vmc_repeat& data) const;
  bool cell_pack_vmc_repeat(Ref<vm::Cell>& cell_ref, long long count, Ref<Cell> body, Ref<Cell> after) const;
  bool unpack(vm::CellSlice& cs, Record_vmc_until& data) const;
  bool unpack_vmc_until(vm::CellSlice& cs, Ref<Cell>& body, Ref<Cell>& after) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vmc_until& data) const;
  bool cell_unpack_vmc_until(Ref<vm::Cell> cell_ref, Ref<Cell>& body, Ref<Cell>& after) const;
  bool pack(vm::CellBuilder& cb, const Record_vmc_until& data) const;
  bool pack_vmc_until(vm::CellBuilder& cb, Ref<Cell> body, Ref<Cell> after) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vmc_until& data) const;
  bool cell_pack_vmc_until(Ref<vm::Cell>& cell_ref, Ref<Cell> body, Ref<Cell> after) const;
  bool unpack(vm::CellSlice& cs, Record_vmc_again& data) const;
  bool unpack_vmc_again(vm::CellSlice& cs, Ref<Cell>& body) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vmc_again& data) const;
  bool cell_unpack_vmc_again(Ref<vm::Cell> cell_ref, Ref<Cell>& body) const;
  bool pack(vm::CellBuilder& cb, const Record_vmc_again& data) const;
  bool pack_vmc_again(vm::CellBuilder& cb, Ref<Cell> body) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vmc_again& data) const;
  bool cell_pack_vmc_again(Ref<vm::Cell>& cell_ref, Ref<Cell> body) const;
  bool unpack(vm::CellSlice& cs, Record_vmc_while_cond& data) const;
  bool unpack_vmc_while_cond(vm::CellSlice& cs, Ref<Cell>& cond, Ref<Cell>& body, Ref<Cell>& after) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vmc_while_cond& data) const;
  bool cell_unpack_vmc_while_cond(Ref<vm::Cell> cell_ref, Ref<Cell>& cond, Ref<Cell>& body, Ref<Cell>& after) const;
  bool pack(vm::CellBuilder& cb, const Record_vmc_while_cond& data) const;
  bool pack_vmc_while_cond(vm::CellBuilder& cb, Ref<Cell> cond, Ref<Cell> body, Ref<Cell> after) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vmc_while_cond& data) const;
  bool cell_pack_vmc_while_cond(Ref<vm::Cell>& cell_ref, Ref<Cell> cond, Ref<Cell> body, Ref<Cell> after) const;
  bool unpack(vm::CellSlice& cs, Record_vmc_while_body& data) const;
  bool unpack_vmc_while_body(vm::CellSlice& cs, Ref<Cell>& cond, Ref<Cell>& body, Ref<Cell>& after) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vmc_while_body& data) const;
  bool cell_unpack_vmc_while_body(Ref<vm::Cell> cell_ref, Ref<Cell>& cond, Ref<Cell>& body, Ref<Cell>& after) const;
  bool pack(vm::CellBuilder& cb, const Record_vmc_while_body& data) const;
  bool pack_vmc_while_body(vm::CellBuilder& cb, Ref<Cell> cond, Ref<Cell> body, Ref<Cell> after) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vmc_while_body& data) const;
  bool cell_pack_vmc_while_body(Ref<vm::Cell>& cell_ref, Ref<Cell> cond, Ref<Cell> body, Ref<Cell> after) const;
  bool unpack(vm::CellSlice& cs, Record_vmc_pushint& data) const;
  bool unpack_vmc_pushint(vm::CellSlice& cs, int& value, Ref<Cell>& next) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_vmc_pushint& data) const;
  bool cell_unpack_vmc_pushint(Ref<vm::Cell> cell_ref, int& value, Ref<Cell>& next) const;
  bool pack(vm::CellBuilder& cb, const Record_vmc_pushint& data) const;
  bool pack_vmc_pushint(vm::CellBuilder& cb, int value, Ref<Cell> next) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_vmc_pushint& data) const;
  bool cell_pack_vmc_pushint(Ref<vm::Cell>& cell_ref, int value, Ref<Cell> next) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "VmCont";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect_ext(6, 0x100f011100010001ULL);
  }
};

struct VmCont::Record_vmc_repeat {
  typedef VmCont type_class;
  long long count;  	// count : uint63
  Ref<Cell> body;  	// body : ^VmCont
  Ref<Cell> after;  	// after : ^VmCont
};

struct VmCont::Record_vmc_while_cond {
  typedef VmCont type_class;
  Ref<Cell> cond;  	// cond : ^VmCont
  Ref<Cell> body;  	// body : ^VmCont
  Ref<Cell> after;  	// after : ^VmCont
};

struct VmCont::Record_vmc_while_body {
  typedef VmCont type_class;
  Ref<Cell> cond;  	// cond : ^VmCont
  Ref<Cell> body;  	// body : ^VmCont
  Ref<Cell> after;  	// after : ^VmCont
};

extern const VmCont t_VmCont;

//
// headers for type `DNS_RecordSet`
//

struct DNS_RecordSet final : TLB_Complex {
  enum { cons1 };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef DNS_RecordSet type_class;
    Ref<CellSlice> x;  	// HashmapE 256 ^DNSRecord
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_cons1(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_cons1(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_cons1(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_cons1(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "DNS_RecordSet";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const DNS_RecordSet t_DNS_RecordSet;

//
// headers for type `TextChunkRef`
//

struct TextChunkRef final : TLB_Complex {
  enum { chunk_ref, chunk_ref_empty };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  TextChunkRef(unsigned m) : m_(m) {}
  struct Record_chunk_ref {
    typedef TextChunkRef type_class;
    unsigned n;  	// n : #
    Ref<Cell> ref;  	// ref : ^(TextChunks (n + 1))
  };
  struct Record_chunk_ref_empty {
    typedef TextChunkRef type_class;
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_chunk_ref& data) const;
  bool unpack_chunk_ref(vm::CellSlice& cs, unsigned& n, Ref<Cell>& ref) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_chunk_ref& data) const;
  bool cell_unpack_chunk_ref(Ref<vm::Cell> cell_ref, unsigned& n, Ref<Cell>& ref) const;
  bool pack(vm::CellBuilder& cb, const Record_chunk_ref& data) const;
  bool pack_chunk_ref(vm::CellBuilder& cb, Ref<Cell> ref) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_chunk_ref& data) const;
  bool cell_pack_chunk_ref(Ref<vm::Cell>& cell_ref, Ref<Cell> ref) const;
  bool unpack(vm::CellSlice& cs, Record_chunk_ref_empty& data) const;
  bool unpack_chunk_ref_empty(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_chunk_ref_empty& data) const;
  bool cell_unpack_chunk_ref_empty(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_chunk_ref_empty& data) const;
  bool pack_chunk_ref_empty(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_chunk_ref_empty& data) const;
  bool cell_pack_chunk_ref_empty(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(TextChunkRef " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

//
// headers for type `TextChunks`
//

struct TextChunks final : TLB_Complex {
  enum { text_chunk, text_chunk_empty };
  static constexpr int cons_len_exact = 0;
  unsigned m_;
  TextChunks(unsigned m) : m_(m) {}
  struct Record_text_chunk;
  struct Record_text_chunk_empty {
    typedef TextChunks type_class;
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_text_chunk& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_text_chunk& data) const;
  bool pack(vm::CellBuilder& cb, const Record_text_chunk& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_text_chunk& data) const;
  bool unpack(vm::CellSlice& cs, Record_text_chunk_empty& data) const;
  bool unpack_text_chunk_empty(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_text_chunk_empty& data) const;
  bool cell_unpack_text_chunk_empty(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_text_chunk_empty& data) const;
  bool pack_text_chunk_empty(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_text_chunk_empty& data) const;
  bool cell_pack_text_chunk_empty(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "(TextChunks " << m_ << ")";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override;
};

struct TextChunks::Record_text_chunk {
  typedef TextChunks type_class;
  unsigned n;  	// n : #
  unsigned len;  	// len : ## 8
  Ref<td::BitString> data;  	// data : bits (8 * len)
  Ref<CellSlice> next;  	// next : TextChunkRef n
};

//
// headers for type `Text`
//

struct Text final : TLB_Complex {
  enum { text };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef Text type_class;
    unsigned chunks;  	// chunks : ## 8
    Ref<CellSlice> rest;  	// rest : TextChunks chunks
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_text(vm::CellSlice& cs, unsigned& chunks, Ref<CellSlice>& rest) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_text(Ref<vm::Cell> cell_ref, unsigned& chunks, Ref<CellSlice>& rest) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_text(vm::CellBuilder& cb, unsigned chunks, Ref<CellSlice> rest) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_text(Ref<vm::Cell>& cell_ref, unsigned chunks, Ref<CellSlice> rest) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Text";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const Text t_Text;

//
// headers for type `ProtoList`
//

struct ProtoList final : TLB_Complex {
  enum { proto_list_nil, proto_list_next };
  static constexpr int cons_len_exact = 1;
  struct Record_proto_list_nil {
    typedef ProtoList type_class;
  };
  struct Record_proto_list_next {
    typedef ProtoList type_class;
    char head;  	// head : Protocol
    Ref<CellSlice> tail;  	// tail : ProtoList
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_proto_list_nil& data) const;
  bool unpack_proto_list_nil(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_proto_list_nil& data) const;
  bool cell_unpack_proto_list_nil(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_proto_list_nil& data) const;
  bool pack_proto_list_nil(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_proto_list_nil& data) const;
  bool cell_pack_proto_list_nil(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_proto_list_next& data) const;
  bool unpack_proto_list_next(vm::CellSlice& cs, char& head, Ref<CellSlice>& tail) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_proto_list_next& data) const;
  bool cell_unpack_proto_list_next(Ref<vm::Cell> cell_ref, char& head, Ref<CellSlice>& tail) const;
  bool pack(vm::CellBuilder& cb, const Record_proto_list_next& data) const;
  bool pack_proto_list_next(vm::CellBuilder& cb, char head, Ref<CellSlice> tail) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_proto_list_next& data) const;
  bool cell_pack_proto_list_next(Ref<vm::Cell>& cell_ref, char head, Ref<CellSlice> tail) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ProtoList";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

extern const ProtoList t_ProtoList;

//
// headers for type `Protocol`
//

struct Protocol final : TLB_Complex {
  enum { proto_http };
  static constexpr int cons_len_exact = 16;
  static constexpr unsigned short cons_tag[1] = { 0x4854 };
  struct Record {
    typedef Protocol type_class;
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 16;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(16);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool fetch_enum_to(vm::CellSlice& cs, char& value) const;
  bool store_enum_from(vm::CellBuilder& cb, int value) const;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_proto_http(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_proto_http(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_proto_http(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_proto_http(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "Protocol";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const Protocol t_Protocol;

//
// headers for type `SmcCapList`
//

struct SmcCapList final : TLB_Complex {
  enum { cap_list_nil, cap_list_next };
  static constexpr int cons_len_exact = 1;
  struct Record_cap_list_nil {
    typedef SmcCapList type_class;
  };
  struct Record_cap_list_next {
    typedef SmcCapList type_class;
    Ref<CellSlice> head;  	// head : SmcCapability
    Ref<CellSlice> tail;  	// tail : SmcCapList
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_cap_list_nil& data) const;
  bool unpack_cap_list_nil(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cap_list_nil& data) const;
  bool cell_unpack_cap_list_nil(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_cap_list_nil& data) const;
  bool pack_cap_list_nil(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cap_list_nil& data) const;
  bool cell_pack_cap_list_nil(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_cap_list_next& data) const;
  bool unpack_cap_list_next(vm::CellSlice& cs, Ref<CellSlice>& head, Ref<CellSlice>& tail) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cap_list_next& data) const;
  bool cell_unpack_cap_list_next(Ref<vm::Cell> cell_ref, Ref<CellSlice>& head, Ref<CellSlice>& tail) const;
  bool pack(vm::CellBuilder& cb, const Record_cap_list_next& data) const;
  bool pack_cap_list_next(vm::CellBuilder& cb, Ref<CellSlice> head, Ref<CellSlice> tail) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cap_list_next& data) const;
  bool cell_pack_cap_list_next(Ref<vm::Cell>& cell_ref, Ref<CellSlice> head, Ref<CellSlice> tail) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "SmcCapList";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return (int)cs.prefetch_ulong(1);
  }
};

extern const SmcCapList t_SmcCapList;

//
// headers for type `SmcCapability`
//

struct SmcCapability final : TLB_Complex {
  enum { cap_is_wallet, cap_method_seqno, cap_method_pubkey, cap_name };
  static constexpr char cons_len[4] = { 16, 16, 16, 8 };
  static constexpr unsigned short cons_tag[4] = { 0x2177, 0x5371, 0x71f4, 0xff };
  struct Record_cap_method_seqno {
    typedef SmcCapability type_class;
  };
  struct Record_cap_method_pubkey {
    typedef SmcCapability type_class;
  };
  struct Record_cap_is_wallet {
    typedef SmcCapability type_class;
  };
  struct Record_cap_name {
    typedef SmcCapability type_class;
    Ref<CellSlice> name;  	// name : Text
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_cap_method_seqno& data) const;
  bool unpack_cap_method_seqno(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cap_method_seqno& data) const;
  bool cell_unpack_cap_method_seqno(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_cap_method_seqno& data) const;
  bool pack_cap_method_seqno(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cap_method_seqno& data) const;
  bool cell_pack_cap_method_seqno(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_cap_method_pubkey& data) const;
  bool unpack_cap_method_pubkey(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cap_method_pubkey& data) const;
  bool cell_unpack_cap_method_pubkey(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_cap_method_pubkey& data) const;
  bool pack_cap_method_pubkey(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cap_method_pubkey& data) const;
  bool cell_pack_cap_method_pubkey(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_cap_is_wallet& data) const;
  bool unpack_cap_is_wallet(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cap_is_wallet& data) const;
  bool cell_unpack_cap_is_wallet(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_cap_is_wallet& data) const;
  bool pack_cap_is_wallet(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cap_is_wallet& data) const;
  bool cell_pack_cap_is_wallet(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_cap_name& data) const;
  bool unpack_cap_name(vm::CellSlice& cs, Ref<CellSlice>& name) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_cap_name& data) const;
  bool cell_unpack_cap_name(Ref<vm::Cell> cell_ref, Ref<CellSlice>& name) const;
  bool pack(vm::CellBuilder& cb, const Record_cap_name& data) const;
  bool pack_cap_name(vm::CellBuilder& cb, Ref<CellSlice> name) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_cap_name& data) const;
  bool cell_pack_cap_name(Ref<vm::Cell>& cell_ref, Ref<CellSlice> name) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "SmcCapability";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(3, 0x8e);
  }
};

extern const SmcCapability t_SmcCapability;

//
// headers for type `DNSRecord`
//

struct DNSRecord final : TLB_Complex {
  enum { dns_text, dns_storage_address, dns_smc_address, dns_adnl_address, dns_next_resolver };
  static constexpr int cons_len_exact = 16;
  static constexpr unsigned short cons_tag[5] = { 0x1eda, 0x7473, 0x9fd3, 0xad01, 0xba93 };
  struct Record_dns_text {
    typedef DNSRecord type_class;
    Ref<CellSlice> x;  	// Text
  };
  struct Record_dns_next_resolver {
    typedef DNSRecord type_class;
    Ref<CellSlice> resolver;  	// resolver : MsgAddressInt
  };
  struct Record_dns_adnl_address;
  struct Record_dns_smc_address;
  struct Record_dns_storage_address {
    typedef DNSRecord type_class;
    td::BitArray<256> bag_id;  	// bag_id : bits256
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_dns_text& data) const;
  bool unpack_dns_text(vm::CellSlice& cs, Ref<CellSlice>& x) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_dns_text& data) const;
  bool cell_unpack_dns_text(Ref<vm::Cell> cell_ref, Ref<CellSlice>& x) const;
  bool pack(vm::CellBuilder& cb, const Record_dns_text& data) const;
  bool pack_dns_text(vm::CellBuilder& cb, Ref<CellSlice> x) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_dns_text& data) const;
  bool cell_pack_dns_text(Ref<vm::Cell>& cell_ref, Ref<CellSlice> x) const;
  bool unpack(vm::CellSlice& cs, Record_dns_next_resolver& data) const;
  bool unpack_dns_next_resolver(vm::CellSlice& cs, Ref<CellSlice>& resolver) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_dns_next_resolver& data) const;
  bool cell_unpack_dns_next_resolver(Ref<vm::Cell> cell_ref, Ref<CellSlice>& resolver) const;
  bool pack(vm::CellBuilder& cb, const Record_dns_next_resolver& data) const;
  bool pack_dns_next_resolver(vm::CellBuilder& cb, Ref<CellSlice> resolver) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_dns_next_resolver& data) const;
  bool cell_pack_dns_next_resolver(Ref<vm::Cell>& cell_ref, Ref<CellSlice> resolver) const;
  bool unpack(vm::CellSlice& cs, Record_dns_adnl_address& data) const;
  bool unpack_dns_adnl_address(vm::CellSlice& cs, td::BitArray<256>& adnl_addr, unsigned& flags, Ref<CellSlice>& proto_list) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_dns_adnl_address& data) const;
  bool cell_unpack_dns_adnl_address(Ref<vm::Cell> cell_ref, td::BitArray<256>& adnl_addr, unsigned& flags, Ref<CellSlice>& proto_list) const;
  bool pack(vm::CellBuilder& cb, const Record_dns_adnl_address& data) const;
  bool pack_dns_adnl_address(vm::CellBuilder& cb, td::BitArray<256> adnl_addr, unsigned flags, Ref<CellSlice> proto_list) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_dns_adnl_address& data) const;
  bool cell_pack_dns_adnl_address(Ref<vm::Cell>& cell_ref, td::BitArray<256> adnl_addr, unsigned flags, Ref<CellSlice> proto_list) const;
  bool unpack(vm::CellSlice& cs, Record_dns_smc_address& data) const;
  bool unpack_dns_smc_address(vm::CellSlice& cs, Ref<CellSlice>& smc_addr, unsigned& flags, Ref<CellSlice>& cap_list) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_dns_smc_address& data) const;
  bool cell_unpack_dns_smc_address(Ref<vm::Cell> cell_ref, Ref<CellSlice>& smc_addr, unsigned& flags, Ref<CellSlice>& cap_list) const;
  bool pack(vm::CellBuilder& cb, const Record_dns_smc_address& data) const;
  bool pack_dns_smc_address(vm::CellBuilder& cb, Ref<CellSlice> smc_addr, unsigned flags, Ref<CellSlice> cap_list) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_dns_smc_address& data) const;
  bool cell_pack_dns_smc_address(Ref<vm::Cell>& cell_ref, Ref<CellSlice> smc_addr, unsigned flags, Ref<CellSlice> cap_list) const;
  bool unpack(vm::CellSlice& cs, Record_dns_storage_address& data) const;
  bool unpack_dns_storage_address(vm::CellSlice& cs, td::BitArray<256>& bag_id) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_dns_storage_address& data) const;
  bool cell_unpack_dns_storage_address(Ref<vm::Cell> cell_ref, td::BitArray<256>& bag_id) const;
  bool pack(vm::CellBuilder& cb, const Record_dns_storage_address& data) const;
  bool pack_dns_storage_address(vm::CellBuilder& cb, td::BitArray<256> bag_id) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_dns_storage_address& data) const;
  bool cell_pack_dns_storage_address(Ref<vm::Cell>& cell_ref, td::BitArray<256> bag_id) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "DNSRecord";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(4, 0xe82);
  }
};

struct DNSRecord::Record_dns_adnl_address {
  typedef DNSRecord type_class;
  td::BitArray<256> adnl_addr;  	// adnl_addr : bits256
  unsigned flags;  	// flags : ## 8
  Ref<CellSlice> proto_list;  	// proto_list : flags.0?ProtoList
};

struct DNSRecord::Record_dns_smc_address {
  typedef DNSRecord type_class;
  Ref<CellSlice> smc_addr;  	// smc_addr : MsgAddressInt
  unsigned flags;  	// flags : ## 8
  Ref<CellSlice> cap_list;  	// cap_list : flags.0?SmcCapList
};

extern const DNSRecord t_DNSRecord;

//
// headers for type `ChanConfig`
//

struct ChanConfig final : TLB_Complex {
  enum { chan_config };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ChanConfig";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ChanConfig::Record {
  typedef ChanConfig type_class;
  unsigned init_timeout;  	// init_timeout : uint32
  unsigned close_timeout;  	// close_timeout : uint32
  td::BitArray<256> a_key;  	// a_key : bits256
  td::BitArray<256> b_key;  	// b_key : bits256
  Ref<Cell> a_addr;  	// a_addr : ^MsgAddressInt
  Ref<Cell> b_addr;  	// b_addr : ^MsgAddressInt
  unsigned long long channel_id;  	// channel_id : uint64
  Ref<CellSlice> min_A_extra;  	// min_A_extra : Tomis
};

extern const ChanConfig t_ChanConfig;

//
// headers for type `ChanState`
//

struct ChanState final : TLB_Complex {
  enum { chan_state_init, chan_state_close, chan_state_payout };
  static constexpr int cons_len_exact = 3;
  struct Record_chan_state_init;
  struct Record_chan_state_close;
  struct Record_chan_state_payout {
    typedef ChanState type_class;
    Ref<CellSlice> A;  	// A : Tomis
    Ref<CellSlice> B;  	// B : Tomis
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_chan_state_init& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_chan_state_init& data) const;
  bool pack(vm::CellBuilder& cb, const Record_chan_state_init& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_chan_state_init& data) const;
  bool unpack(vm::CellSlice& cs, Record_chan_state_close& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_chan_state_close& data) const;
  bool pack(vm::CellBuilder& cb, const Record_chan_state_close& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_chan_state_close& data) const;
  bool unpack(vm::CellSlice& cs, Record_chan_state_payout& data) const;
  bool unpack_chan_state_payout(vm::CellSlice& cs, Ref<CellSlice>& A, Ref<CellSlice>& B) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_chan_state_payout& data) const;
  bool cell_unpack_chan_state_payout(Ref<vm::Cell> cell_ref, Ref<CellSlice>& A, Ref<CellSlice>& B) const;
  bool pack(vm::CellBuilder& cb, const Record_chan_state_payout& data) const;
  bool pack_chan_state_payout(vm::CellBuilder& cb, Ref<CellSlice> A, Ref<CellSlice> B) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_chan_state_payout& data) const;
  bool cell_pack_chan_state_payout(Ref<vm::Cell>& cell_ref, Ref<CellSlice> A, Ref<CellSlice> B) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ChanState";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(3, 7);
  }
};

struct ChanState::Record_chan_state_init {
  typedef ChanState type_class;
  bool signed_A;  	// signed_A : Bool
  bool signed_B;  	// signed_B : Bool
  Ref<CellSlice> min_A;  	// min_A : Tomis
  Ref<CellSlice> min_B;  	// min_B : Tomis
  unsigned expire_at;  	// expire_at : uint32
  Ref<CellSlice> A;  	// A : Tomis
  Ref<CellSlice> B;  	// B : Tomis
};

struct ChanState::Record_chan_state_close {
  typedef ChanState type_class;
  bool signed_A;  	// signed_A : Bool
  bool signed_B;  	// signed_B : Bool
  Ref<CellSlice> promise_A;  	// promise_A : Tomis
  Ref<CellSlice> promise_B;  	// promise_B : Tomis
  unsigned expire_at;  	// expire_at : uint32
  Ref<CellSlice> A;  	// A : Tomis
  Ref<CellSlice> B;  	// B : Tomis
};

extern const ChanState t_ChanState;

//
// headers for type `ChanPromise`
//

struct ChanPromise final : TLB_Complex {
  enum { chan_promise };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_chan_promise(vm::CellSlice& cs, unsigned long long& channel_id, Ref<CellSlice>& promise_A, Ref<CellSlice>& promise_B) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_chan_promise(Ref<vm::Cell> cell_ref, unsigned long long& channel_id, Ref<CellSlice>& promise_A, Ref<CellSlice>& promise_B) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_chan_promise(vm::CellBuilder& cb, unsigned long long channel_id, Ref<CellSlice> promise_A, Ref<CellSlice> promise_B) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_chan_promise(Ref<vm::Cell>& cell_ref, unsigned long long channel_id, Ref<CellSlice> promise_A, Ref<CellSlice> promise_B) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ChanPromise";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ChanPromise::Record {
  typedef ChanPromise type_class;
  unsigned long long channel_id;  	// channel_id : uint64
  Ref<CellSlice> promise_A;  	// promise_A : Tomis
  Ref<CellSlice> promise_B;  	// promise_B : Tomis
};

extern const ChanPromise t_ChanPromise;

//
// headers for type `ChanSignedPromise`
//

struct ChanSignedPromise final : TLB_Complex {
  enum { chan_signed_promise };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ChanSignedPromise type_class;
    Ref<CellSlice> sig;  	// sig : Maybe ^bits512
    Ref<CellSlice> promise;  	// promise : ChanPromise
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_chan_signed_promise(vm::CellSlice& cs, Ref<CellSlice>& sig, Ref<CellSlice>& promise) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_chan_signed_promise(Ref<vm::Cell> cell_ref, Ref<CellSlice>& sig, Ref<CellSlice>& promise) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_chan_signed_promise(vm::CellBuilder& cb, Ref<CellSlice> sig, Ref<CellSlice> promise) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_chan_signed_promise(Ref<vm::Cell>& cell_ref, Ref<CellSlice> sig, Ref<CellSlice> promise) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ChanSignedPromise";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ChanSignedPromise t_ChanSignedPromise;

//
// headers for type `ChanMsg`
//

struct ChanMsg final : TLB_Complex {
  enum { chan_msg_init, chan_msg_payout, chan_msg_timeout, chan_msg_close };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[4] = { 0x27317822, 0x37fe7810, 0x43278a28, 0xf28ae183U };
  struct Record_chan_msg_init;
  struct Record_chan_msg_close;
  struct Record_chan_msg_timeout {
    typedef ChanMsg type_class;
  };
  struct Record_chan_msg_payout {
    typedef ChanMsg type_class;
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record_chan_msg_init& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_chan_msg_init& data) const;
  bool pack(vm::CellBuilder& cb, const Record_chan_msg_init& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_chan_msg_init& data) const;
  bool unpack(vm::CellSlice& cs, Record_chan_msg_close& data) const;
  bool unpack_chan_msg_close(vm::CellSlice& cs, Ref<CellSlice>& extra_A, Ref<CellSlice>& extra_B, Ref<CellSlice>& promise) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_chan_msg_close& data) const;
  bool cell_unpack_chan_msg_close(Ref<vm::Cell> cell_ref, Ref<CellSlice>& extra_A, Ref<CellSlice>& extra_B, Ref<CellSlice>& promise) const;
  bool pack(vm::CellBuilder& cb, const Record_chan_msg_close& data) const;
  bool pack_chan_msg_close(vm::CellBuilder& cb, Ref<CellSlice> extra_A, Ref<CellSlice> extra_B, Ref<CellSlice> promise) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_chan_msg_close& data) const;
  bool cell_pack_chan_msg_close(Ref<vm::Cell>& cell_ref, Ref<CellSlice> extra_A, Ref<CellSlice> extra_B, Ref<CellSlice> promise) const;
  bool unpack(vm::CellSlice& cs, Record_chan_msg_timeout& data) const;
  bool unpack_chan_msg_timeout(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_chan_msg_timeout& data) const;
  bool cell_unpack_chan_msg_timeout(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_chan_msg_timeout& data) const;
  bool pack_chan_msg_timeout(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_chan_msg_timeout& data) const;
  bool cell_pack_chan_msg_timeout(Ref<vm::Cell>& cell_ref) const;
  bool unpack(vm::CellSlice& cs, Record_chan_msg_payout& data) const;
  bool unpack_chan_msg_payout(vm::CellSlice& cs) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record_chan_msg_payout& data) const;
  bool cell_unpack_chan_msg_payout(Ref<vm::Cell> cell_ref) const;
  bool pack(vm::CellBuilder& cb, const Record_chan_msg_payout& data) const;
  bool pack_chan_msg_payout(vm::CellBuilder& cb) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record_chan_msg_payout& data) const;
  bool cell_pack_chan_msg_payout(Ref<vm::Cell>& cell_ref) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ChanMsg";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return cs.bselect(4, 0x801c);
  }
};

struct ChanMsg::Record_chan_msg_init {
  typedef ChanMsg type_class;
  Ref<CellSlice> inc_A;  	// inc_A : Tomis
  Ref<CellSlice> inc_B;  	// inc_B : Tomis
  Ref<CellSlice> min_A;  	// min_A : Tomis
  Ref<CellSlice> min_B;  	// min_B : Tomis
  unsigned long long channel_id;  	// channel_id : uint64
};

struct ChanMsg::Record_chan_msg_close {
  typedef ChanMsg type_class;
  Ref<CellSlice> extra_A;  	// extra_A : Tomis
  Ref<CellSlice> extra_B;  	// extra_B : Tomis
  Ref<CellSlice> promise;  	// promise : ChanSignedPromise
};

extern const ChanMsg t_ChanMsg;

//
// headers for type `ChanSignedMsg`
//

struct ChanSignedMsg final : TLB_Complex {
  enum { chan_signed_msg };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_chan_signed_msg(vm::CellSlice& cs, Ref<CellSlice>& sig_A, Ref<CellSlice>& sig_B, Ref<CellSlice>& msg) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_chan_signed_msg(Ref<vm::Cell> cell_ref, Ref<CellSlice>& sig_A, Ref<CellSlice>& sig_B, Ref<CellSlice>& msg) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_chan_signed_msg(vm::CellBuilder& cb, Ref<CellSlice> sig_A, Ref<CellSlice> sig_B, Ref<CellSlice> msg) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_chan_signed_msg(Ref<vm::Cell>& cell_ref, Ref<CellSlice> sig_A, Ref<CellSlice> sig_B, Ref<CellSlice> msg) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ChanSignedMsg";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ChanSignedMsg::Record {
  typedef ChanSignedMsg type_class;
  Ref<CellSlice> sig_A;  	// sig_A : Maybe ^bits512
  Ref<CellSlice> sig_B;  	// sig_B : Maybe ^bits512
  Ref<CellSlice> msg;  	// msg : ChanMsg
};

extern const ChanSignedMsg t_ChanSignedMsg;

//
// headers for type `ChanOp`
//

struct ChanOp final : TLB_Complex {
  enum { chan_op_cmd };
  static constexpr int cons_len_exact = 32;
  static constexpr unsigned cons_tag[1] = { 0x912838d1U };
  struct Record {
    typedef ChanOp type_class;
    Ref<CellSlice> msg;  	// msg : ChanSignedMsg
  };
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_chan_op_cmd(vm::CellSlice& cs, Ref<CellSlice>& msg) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_chan_op_cmd(Ref<vm::Cell> cell_ref, Ref<CellSlice>& msg) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_chan_op_cmd(vm::CellBuilder& cb, Ref<CellSlice> msg) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_chan_op_cmd(Ref<vm::Cell>& cell_ref, Ref<CellSlice> msg) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ChanOp";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ChanOp t_ChanOp;

//
// headers for type `ChanData`
//

struct ChanData final : TLB_Complex {
  enum { chan_data };
  static constexpr int cons_len_exact = 0;
  struct Record {
    typedef ChanData type_class;
    Ref<Cell> config;  	// config : ^ChanConfig
    Ref<Cell> state;  	// state : ^ChanState
  };
  int get_size(const vm::CellSlice& cs) const override {
    return 0x20000;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x20000);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_chan_data(vm::CellSlice& cs, Ref<Cell>& config, Ref<Cell>& state) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_chan_data(Ref<vm::Cell> cell_ref, Ref<Cell>& config, Ref<Cell>& state) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_chan_data(vm::CellBuilder& cb, Ref<Cell> config, Ref<Cell> state) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_chan_data(Ref<vm::Cell>& cell_ref, Ref<Cell> config, Ref<Cell> state) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ChanData";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

extern const ChanData t_ChanData;

//
// headers for type `DeliveryOriginV1`
//

struct DeliveryOriginV1 final : TLB_Complex {
  enum { delivery_origin_v1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 360;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(360);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override {
    return cs.advance(360);
  }
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "DeliveryOriginV1";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct DeliveryOriginV1::Record {
  typedef DeliveryOriginV1 type_class;
  unsigned long long origin_tx_lt;  	// origin_tx_lt : uint64
  RefInt256 origin_tx_hash;  	// origin_tx_hash : uint256
  int origin_action_index;  	// origin_action_index : uint16
  int attempt_kind;  	// attempt_kind : uint8
  int attempt_seq;  	// attempt_seq : uint16
};

extern const DeliveryOriginV1 t_DeliveryOriginV1;

//
// headers for type `DeliveryRouteV1`
//

struct DeliveryRouteV1 final : TLB_Complex {
  enum { delivery_route_v1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "DeliveryRouteV1";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct DeliveryRouteV1::Record {
  typedef DeliveryRouteV1 type_class;
  Ref<CellSlice> src;  	// src : MsgAddressInt
  Ref<CellSlice> dest;  	// dest : MsgAddressInt
  int send_mode;  	// send_mode : uint16
  int extra_flags;  	// extra_flags : uint16
};

extern const DeliveryRouteV1 t_DeliveryRouteV1;

//
// headers for type `DeliveryPayloadV1`
//

struct DeliveryPayloadV1 final : TLB_Complex {
  enum { delivery_payload_v1 };
  static constexpr int cons_len_exact = 0;
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "DeliveryPayloadV1";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct DeliveryPayloadV1::Record {
  typedef DeliveryPayloadV1 type_class;
  Ref<CellSlice> value;  	// value : CurrencyCollection
  Ref<CellSlice> state_init_hash;  	// state_init_hash : Maybe uint256
  RefInt256 body_hash;  	// body_hash : uint256
  unsigned not_before_mc_seqno;  	// not_before_mc_seqno : uint32
  unsigned expire_after_blocks;  	// expire_after_blocks : uint32
};

extern const DeliveryPayloadV1 t_DeliveryPayloadV1;

//
// headers for type `DeliveryIdInputV1`
//

struct DeliveryIdInputV1 final : TLB_Complex {
  enum { delivery_id_input_v1 };
  static constexpr int cons_len_exact = 16;
  static constexpr unsigned short cons_tag[1] = { 0xd601 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 0x30010;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance_ext(0x30010);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool unpack_delivery_id_input_v1(vm::CellSlice& cs, Ref<Cell>& origin, Ref<Cell>& route, Ref<Cell>& payload) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool cell_unpack_delivery_id_input_v1(Ref<vm::Cell> cell_ref, Ref<Cell>& origin, Ref<Cell>& route, Ref<Cell>& payload) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool pack_delivery_id_input_v1(vm::CellBuilder& cb, Ref<Cell> origin, Ref<Cell> route, Ref<Cell> payload) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool cell_pack_delivery_id_input_v1(Ref<vm::Cell>& cell_ref, Ref<Cell> origin, Ref<Cell> route, Ref<Cell> payload) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "DeliveryIdInputV1";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct DeliveryIdInputV1::Record {
  typedef DeliveryIdInputV1 type_class;
  Ref<Cell> origin;  	// origin : ^DeliveryOriginV1
  Ref<Cell> route;  	// route : ^DeliveryRouteV1
  Ref<Cell> payload;  	// payload : ^DeliveryPayloadV1
};

extern const DeliveryIdInputV1 t_DeliveryIdInputV1;

//
// headers for type `BackPressureAdvice`
//

struct BackPressureAdvice final : TLB_Complex {
  enum { back_pressure_advice_v1 };
  static constexpr int cons_len_exact = 16;
  static constexpr unsigned short cons_tag[1] = { 0xb601 };
  struct Record;
  int get_size(const vm::CellSlice& cs) const override {
    return 608;
  }
  bool skip(vm::CellSlice& cs) const override {
    return cs.advance(608);
  }
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "BackPressureAdvice";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct BackPressureAdvice::Record {
  typedef BackPressureAdvice type_class;
  RefInt256 delivery_id;  	// delivery_id : uint256
  int bucket;  	// bucket : uint8
  int scope;  	// scope : uint8
  unsigned min_retry_after_blocks;  	// min_retry_after_blocks : uint32
  unsigned advice_valid_until;  	// advice_valid_until : uint32
  RefInt256 route_hash;  	// route_hash : uint256
};

extern const BackPressureAdvice t_BackPressureAdvice;

//
// headers for type `ScheduledActionV1`
//

struct ScheduledActionV1 final : TLB_Complex {
  enum { scheduled_action_v1 };
  static constexpr int cons_len_exact = 16;
  static constexpr unsigned short cons_tag[1] = { 0xd602 };
  struct Record;
  bool skip(vm::CellSlice& cs) const override;
  bool validate_skip(int* ops, vm::CellSlice& cs, bool weak = false) const override;
  bool unpack(vm::CellSlice& cs, Record& data) const;
  bool cell_unpack(Ref<vm::Cell> cell_ref, Record& data) const;
  bool pack(vm::CellBuilder& cb, const Record& data) const;
  bool cell_pack(Ref<vm::Cell>& cell_ref, const Record& data) const;
  bool print_skip(PrettyPrinter& pp, vm::CellSlice& cs) const override;
  std::ostream& print_type(std::ostream& os) const override {
    return os << "ScheduledActionV1";
  }
  int check_tag(const vm::CellSlice& cs) const override;
  int get_tag(const vm::CellSlice& cs) const override {
    return 0;
  }
};

struct ScheduledActionV1::Record {
  typedef ScheduledActionV1 type_class;
  Ref<CellSlice> target;  	// target : MsgAddressInt
  Ref<Cell> body;  	// body : ^Cell
  Ref<CellSlice> value;  	// value : CurrencyCollection
  int send_mode;  	// send_mode : uint16
  unsigned not_before_mc_seqno;  	// not_before_mc_seqno : uint32
  unsigned expire_after_blocks;  	// expire_after_blocks : uint32
  Ref<CellSlice> cancel_authority;  	// cancel_authority : MsgAddressInt
  Ref<CellSlice> dead_letter;  	// dead_letter : Maybe MsgAddressInt
};

extern const ScheduledActionV1 t_ScheduledActionV1;

// declarations of constant types used

// uint16
extern const UInt t_uint16;
// uint64
extern const UInt t_uint64;
// ^UnoV2SystemState
extern const RefT t_Ref_UnoV2SystemState;
// uint32
extern const UInt t_uint32;
// ^UnoV2ResourceInput
extern const RefT t_Ref_UnoV2ResourceInput;
// ^UnoV2ResourceState
extern const RefT t_Ref_UnoV2ResourceState;
// ^UnoV2ResourceWorkOutput
extern const RefT t_Ref_UnoV2ResourceWorkOutput;
// ^ParamLimits
extern const RefT t_Ref_ParamLimits;
// bits256
extern const Bits t_bits256;
// ^UnoV2ResourcePolicy
extern const RefT t_Ref_UnoV2ResourcePolicy;
// HashmapE 32 WorkchainInstanceRecord
extern const HashmapE t_HashmapE_32_WorkchainInstanceRecord;
// int32
extern const Int t_int32;
// int64
extern const Int t_int64;
// ^UnoV2HostDomain
extern const RefT t_Ref_UnoV2HostDomain;
// ^UnoV2HostPolicy
extern const RefT t_Ref_UnoV2HostPolicy;
// ^UnoV2HostContext
extern const RefT t_Ref_UnoV2HostContext;
// Maybe bits256
extern const Maybe t_Maybe_bits256;
// ^UnoV2HostRead
extern const RefT t_Ref_UnoV2HostRead;
// HashmapE 256 ^UnoV2HostRead
extern const HashmapE t_HashmapE_256_Ref_UnoV2HostRead;
// HashmapE 256 True
extern const HashmapE t_HashmapE_256_True;
// ^UnoV2HostIdentity
extern const RefT t_Ref_UnoV2HostIdentity;
// ^UnoV2HostAccess
extern const RefT t_Ref_UnoV2HostAccess;
// ^WorkchainBatchInbound
extern const RefT t_Ref_WorkchainBatchInbound;
// Maybe ^WorkchainBatchInbound
extern const Maybe t_Maybe_Ref_WorkchainBatchInbound;
// Maybe ^Cell
extern const Maybe t_Maybe_Ref_Cell;
// ^UnoV2NativeTransfer
extern const RefT t_Ref_UnoV2NativeTransfer;
// HashmapE 32 ^UnoV2NativeTransfer
extern const HashmapE t_HashmapE_32_Ref_UnoV2NativeTransfer;
// ^UnoV2FeeSettlement
extern const RefT t_Ref_UnoV2FeeSettlement;
// HashmapE 256 ^Cell
extern const HashmapE t_HashmapE_256_Ref_Cell;
// ^UnoV2NativeEffects
extern const RefT t_Ref_UnoV2NativeEffects;
// ^WorkchainNativeIngressPolicy
extern const RefT t_Ref_WorkchainNativeIngressPolicy;
// HashmapE 32 ^WorkchainNativeIngressPolicy
extern const HashmapE t_HashmapE_32_Ref_WorkchainNativeIngressPolicy;
// uint15
extern const UInt t_uint15;
// ^MsgEnvelope
extern const RefT t_Ref_MsgEnvelope;
// HashmapE 256 ^MsgEnvelope
extern const HashmapE t_HashmapE_256_Ref_MsgEnvelope;
// ^WorkchainBlockContext
extern const RefT t_Ref_WorkchainBlockContext;
// ^WorkchainBlockOutputs
extern const RefT t_Ref_WorkchainBlockOutputs;
// ^WorkchainBlockResult
extern const RefT t_Ref_WorkchainBlockResult;
// ^WorkchainBatchWitness
extern const RefT t_Ref_WorkchainBatchWitness;
// Maybe ^WorkchainBatchWitness
extern const Maybe t_Maybe_Ref_WorkchainBatchWitness;
// ## 1
extern const NatWidth t_natwidth_1;
// ## 9
extern const NatWidth t_natwidth_9;
// #<= 30
extern const NatLeq t_natleq_30;
// Maybe Anycast
extern const Maybe t_Maybe_Anycast;
// int8
extern const Int t_int8;
// VarUInteger 16
extern const VarUInteger t_VarUInteger_16;
// VarUInteger 32
extern const VarUInteger t_VarUInteger_32;
// HashmapE 32 (VarUInteger 32)
extern const HashmapE t_HashmapE_32_VarUInteger_32;
// ## 5
extern const NatWidth t_natwidth_5;
// Maybe (## 5)
extern const Maybe t_Maybe_natwidth_5;
// Maybe TickTock
extern const Maybe t_Maybe_TickTock;
// HashmapE 256 SimpleLib
extern const HashmapE t_HashmapE_256_SimpleLib;
// ^StateInit
extern const RefT t_Ref_StateInit;
// Either StateInit ^StateInit
extern const Either t_Either_StateInit_Ref_StateInit;
// Maybe (Either StateInit ^StateInit)
extern const Maybe t_Maybe_Either_StateInit_Ref_StateInit;
// Message Any
extern const Message t_Message_Any;
// ^NewBounceOriginalInfo
extern const RefT t_Ref_NewBounceOriginalInfo;
// uint8
extern const UInt t_uint8;
// Maybe NewBounceComputePhaseInfo
extern const Maybe t_Maybe_NewBounceComputePhaseInfo;
// #<= 96
extern const NatLeq t_natleq_96;
// ^(Message Any)
extern const RefT t_Ref_Message_Any;
// Maybe uint64
extern const Maybe t_Maybe_uint64;
// Maybe MsgMetadata
extern const Maybe t_Maybe_MsgMetadata;
// ^Transaction
extern const RefT t_Ref_Transaction;
// HashmapAugE 256 InMsg ImportFees
extern const HashmapAugE t_HashmapAugE_256_InMsg_ImportFees;
// ^InMsg
extern const RefT t_Ref_InMsg;
// uint63
extern const UInt t_uint63;
// HashmapAugE 256 OutMsg CurrencyCollection
extern const HashmapAugE t_HashmapAugE_256_OutMsg_CurrencyCollection;
// HashmapAugE 352 EnqueuedMsg uint64
extern const HashmapAugE t_HashmapAugE_352_EnqueuedMsg_uint64;
// HashmapE 96 ProcessedUpto
extern const HashmapE t_HashmapE_96_ProcessedUpto;
// HashmapE 320 IhrPendingSince
extern const HashmapE t_HashmapE_320_IhrPendingSince;
// HashmapE 64 EnqueuedMsg
extern const HashmapE t_HashmapE_64_EnqueuedMsg;
// uint48
extern const UInt t_uint48;
// HashmapAugE 256 AccountDispatchQueue uint64
extern const HashmapAugE t_HashmapAugE_256_AccountDispatchQueue_uint64;
// Maybe uint48
extern const Maybe t_Maybe_uint48;
// Maybe OutMsgQueueExtra
extern const Maybe t_Maybe_OutMsgQueueExtra;
// uint256
extern const UInt t_uint256;
// VarUInteger 7
extern const VarUInteger t_VarUInteger_7;
// Maybe Tomis
extern const Maybe t_Maybe_Tomis;
// ^Account
extern const RefT t_Ref_Account;
// HashmapAugE 256 ShardAccount DepthBalanceInfo
extern const HashmapAugE t_HashmapAugE_256_ShardAccount_DepthBalanceInfo;
// Maybe ^(Message Any)
extern const Maybe t_Maybe_Ref_Message_Any;
// HashmapE 15 ^(Message Any)
extern const HashmapE t_HashmapE_15_Ref_Message_Any;
// ^[$_ in_msg:(Maybe ^(Message Any)) out_msgs:(HashmapE 15 ^(Message Any)) ]
extern const RefT t_Ref_TYPE_1656;
// HASH_UPDATE Account
extern const HASH_UPDATE t_HASH_UPDATE_Account;
// ^(HASH_UPDATE Account)
extern const RefT t_Ref_HASH_UPDATE_Account;
// ^TransactionDescr
extern const RefT t_Ref_TransactionDescr;
// HashmapAug 64 ^Transaction CurrencyCollection
extern const HashmapAug t_HashmapAug_64_Ref_Transaction_CurrencyCollection;
// HashmapAugE 256 AccountBlock CurrencyCollection
extern const HashmapAugE t_HashmapAugE_256_AccountBlock_CurrencyCollection;
// VarUInteger 3
extern const VarUInteger t_VarUInteger_3;
// Maybe (VarUInteger 3)
extern const Maybe t_Maybe_VarUInteger_3;
// Maybe int32
extern const Maybe t_Maybe_int32;
// ^[$_ gas_used:(VarUInteger 7) gas_limit:(VarUInteger 7) gas_credit:(Maybe (VarUInteger 3)) mode:int8 exit_code:int32 exit_arg:(Maybe int32) vm_steps:uint32 vm_init_state_hash:bits256 vm_final_state_hash:bits256 ]
extern const RefT t_Ref_TYPE_1668;
// Maybe TrStoragePhase
extern const Maybe t_Maybe_TrStoragePhase;
// Maybe TrCreditPhase
extern const Maybe t_Maybe_TrCreditPhase;
// ^TrActionPhase
extern const RefT t_Ref_TrActionPhase;
// Maybe ^TrActionPhase
extern const Maybe t_Maybe_Ref_TrActionPhase;
// Maybe TrBouncePhase
extern const Maybe t_Maybe_TrBouncePhase;
// ^UnoV2HostRecord
extern const RefT t_Ref_UnoV2HostRecord;
// ^UnoV2HostInput
extern const RefT t_Ref_UnoV2HostInput;
// ^UnoV2HostEffects
extern const RefT t_Ref_UnoV2HostEffects;
// ## 6
extern const NatWidth t_natwidth_6;
// Maybe Cell
extern const Maybe t_Maybe_Cell;
// ## 8
extern const NatWidth t_natwidth_8;
// MessageRelaxed Any
extern const MessageRelaxed t_MessageRelaxed_Any;
// ^(MessageRelaxed Any)
extern const RefT t_Ref_MessageRelaxed_Any;
// ## 7
extern const NatWidth t_natwidth_7;
// #<= 60
extern const NatLeq t_natleq_60;
// ^OutMsgQueueInfo
extern const RefT t_Ref_OutMsgQueueInfo;
// ^ShardAccounts
extern const RefT t_Ref_ShardAccounts;
// HashmapE 256 LibDescr
extern const HashmapE t_HashmapE_256_LibDescr;
// Maybe BlkMasterInfo
extern const Maybe t_Maybe_BlkMasterInfo;
// ^[$_ overload_history:uint64 underload_history:uint64 total_balance:CurrencyCollection total_validator_fees:CurrencyCollection libraries:(HashmapE 256 LibDescr) master_ref:(Maybe BlkMasterInfo) ]
extern const RefT t_Ref_TYPE_1682;
// ^McStateExtra
extern const RefT t_Ref_McStateExtra;
// Maybe ^McStateExtra
extern const Maybe t_Maybe_Ref_McStateExtra;
// ^ShardStateUnsplit
extern const RefT t_Ref_ShardStateUnsplit;
// Hashmap 256 True
extern const Hashmap t_Hashmap_256_True;
// ^BlkMasterInfo
extern const RefT t_Ref_BlkMasterInfo;
// BlkPrevInfo 0
extern const BlkPrevInfo t_BlkPrevInfo_0;
// ^(BlkPrevInfo 0)
extern const RefT t_Ref_BlkPrevInfo_0;
// ^ExtBlkRef
extern const RefT t_Ref_ExtBlkRef;
// ^BlockInfo
extern const RefT t_Ref_BlockInfo;
// ^ValueFlow
extern const RefT t_Ref_ValueFlow;
// MERKLE_UPDATE ShardState
extern const MERKLE_UPDATE t_MERKLE_UPDATE_ShardState;
// ^(MERKLE_UPDATE ShardState)
extern const RefT t_Ref_MERKLE_UPDATE_ShardState;
// ^BlockExtra
extern const RefT t_Ref_BlockExtra;
// ^InMsgDescr
extern const RefT t_Ref_InMsgDescr;
// ^OutMsgDescr
extern const RefT t_Ref_OutMsgDescr;
// ^ShardAccountBlocks
extern const RefT t_Ref_ShardAccountBlocks;
// ^McBlockExtra
extern const RefT t_Ref_McBlockExtra;
// Maybe ^McBlockExtra
extern const Maybe t_Maybe_Ref_McBlockExtra;
// ^[$_ from_prev_blk:CurrencyCollection to_next_blk:CurrencyCollection imported:CurrencyCollection exported:CurrencyCollection ]
extern const RefT t_Ref_TYPE_1693;
// ^[$_ fees_imported:CurrencyCollection recovered:CurrencyCollection created:CurrencyCollection minted:CurrencyCollection ]
extern const RefT t_Ref_TYPE_1694;
// ## 3
extern const NatWidth t_natwidth_3;
// ^[$_ fees_collected:CurrencyCollection funds_created:CurrencyCollection ]
extern const RefT t_Ref_TYPE_1698;
// BinTree ShardDescr
extern const BinTree t_BinTree_ShardDescr;
// ^(BinTree ShardDescr)
extern const RefT t_Ref_BinTree_ShardDescr;
// HashmapE 32 ^(BinTree ShardDescr)
extern const HashmapE t_HashmapE_32_Ref_BinTree_ShardDescr;
// HashmapAugE 96 ShardFeeCreated ShardFeeCreated
extern const HashmapAugE t_HashmapAugE_96_ShardFeeCreated_ShardFeeCreated;
// Hashmap 32 ^Cell
extern const Hashmap t_Hashmap_32_Ref_Cell;
// ^(Hashmap 32 ^Cell)
extern const RefT t_Ref_Hashmap_32_Ref_Cell;
// HashmapAugE 32 KeyExtBlkRef KeyMaxLt
extern const HashmapAugE t_HashmapAugE_32_KeyExtBlkRef_KeyMaxLt;
// HashmapE 256 CreatorStats
extern const HashmapE t_HashmapE_256_CreatorStats;
// HashmapAugE 256 CreatorStats uint32
extern const HashmapAugE t_HashmapAugE_256_CreatorStats_uint32;
// ## 16
extern const NatWidth t_natwidth_16;
// Maybe ExtBlkRef
extern const Maybe t_Maybe_ExtBlkRef;
// ^WorkchainInstanceLedger
extern const RefT t_Ref_WorkchainInstanceLedger;
// ^[$_ flags:(## 16) {<= flags 1} validator_info:ValidatorInfo prev_blocks:OldMcBlocksInfo after_key_block:Bool last_key_block:(Maybe ExtBlkRef) block_create_stats:flags.0?BlockCreateStats workchain_instances:^WorkchainInstanceLedger ]
extern const RefT t_Ref_TYPE_1711;
// ^SignedCertificate
extern const RefT t_Ref_SignedCertificate;
// HashmapE 16 CryptoSignaturePair
extern const HashmapE t_HashmapE_16_CryptoSignaturePair;
// Maybe ^InMsg
extern const Maybe t_Maybe_Ref_InMsg;
// ^[$_ prev_blk_signatures:(HashmapE 16 CryptoSignaturePair) recover_create_msg:(Maybe ^InMsg) mint_msg:(Maybe ^InMsg) ]
extern const RefT t_Ref_TYPE_1719;
// Hashmap 16 ValidatorDescr
extern const Hashmap t_Hashmap_16_ValidatorDescr;
// HashmapE 16 ValidatorDescr
extern const HashmapE t_HashmapE_16_ValidatorDescr;
// Hashmap 32 True
extern const Hashmap t_Hashmap_32_True;
// ## 32
extern const NatWidth t_natwidth_32;
// ^ConfigProposalSetup
extern const RefT t_Ref_ConfigProposalSetup;
// Maybe uint256
extern const Maybe t_Maybe_uint256;
// ^ConfigProposal
extern const RefT t_Ref_ConfigProposal;
// HashmapE 16 True
extern const HashmapE t_HashmapE_16_True;
// ## 12
extern const NatWidth t_natwidth_12;
// ## 13
extern const NatWidth t_natwidth_13;
// HashmapE 32 WorkchainDescr
extern const HashmapE t_HashmapE_32_WorkchainDescr;
// Hashmap 32 StoragePrices
extern const Hashmap t_Hashmap_32_StoragePrices;
// ## 2
extern const NatWidth t_natwidth_2;
// HashmapE 8 uint32
extern const HashmapE t_HashmapE_8_uint32;
// ^NewConsensusConfig
extern const RefT t_Ref_NewConsensusConfig;
// Maybe ^NewConsensusConfig
extern const Maybe t_Maybe_Ref_NewConsensusConfig;
// ^ValidatorTempKey
extern const RefT t_Ref_ValidatorTempKey;
// HashmapE 256 ValidatorSignedTempKey
extern const HashmapE t_HashmapE_256_ValidatorSignedTempKey;
// Maybe uint32
extern const Maybe t_Maybe_uint32;
// HashmapE 288 Unit
extern const HashmapE t_HashmapE_288_Unit;
// HashmapE 256 PrecompiledSmc
extern const HashmapE t_HashmapE_256_PrecompiledSmc;
// HashmapE 256 uint256
extern const HashmapE t_HashmapE_256_uint256;
// ^JettonBridgePrices
extern const RefT t_Ref_JettonBridgePrices;
// ^BlockSignatures
extern const RefT t_Ref_BlockSignatures;
// Maybe ^BlockSignatures
extern const Maybe t_Maybe_Ref_BlockSignatures;
// ^TopBlockDescr
extern const RefT t_Ref_TopBlockDescr;
// HashmapE 96 ^TopBlockDescr
extern const HashmapE t_HashmapE_96_Ref_TopBlockDescr;
// MERKLE_PROOF Block
extern const MERKLE_PROOF t_MERKLE_PROOF_Block;
// ^(MERKLE_PROOF Block)
extern const RefT t_Ref_MERKLE_PROOF_Block;
// MERKLE_PROOF ShardState
extern const MERKLE_PROOF t_MERKLE_PROOF_ShardState;
// ^(MERKLE_PROOF ShardState)
extern const RefT t_Ref_MERKLE_PROOF_ShardState;
// ^ProducerInfo
extern const RefT t_Ref_ProducerInfo;
// ^ComplaintDescr
extern const RefT t_Ref_ComplaintDescr;
// ^ValidatorComplaint
extern const RefT t_Ref_ValidatorComplaint;
// int257
extern const Int t_int257;
// ## 10
extern const NatWidth t_natwidth_10;
// #<= 4
extern const NatLeq t_natleq_4;
// ^VmStackValue
extern const RefT t_Ref_VmStackValue;
// ## 24
extern const NatWidth t_natwidth_24;
// HashmapE 4 VmStackValue
extern const HashmapE t_HashmapE_4_VmStackValue;
// ^[$_ max_limit:int64 cur_limit:int64 credit:int64 ]
extern const RefT t_Ref_TYPE_1771;
// uint13
extern const UInt t_uint13;
// Maybe uint13
extern const Maybe t_Maybe_uint13;
// Maybe VmStack
extern const Maybe t_Maybe_VmStack;
// int16
extern const Int t_int16;
// Maybe int16
extern const Maybe t_Maybe_int16;
// ^VmCont
extern const RefT t_Ref_VmCont;
// ^DNSRecord
extern const RefT t_Ref_DNSRecord;
// HashmapE 256 ^DNSRecord
extern const HashmapE t_HashmapE_256_Ref_DNSRecord;
// ^MsgAddressInt
extern const RefT t_Ref_MsgAddressInt;
// bits512
extern const Bits t_bits512;
// ^bits512
extern const RefT t_Ref_bits512;
// Maybe ^bits512
extern const Maybe t_Maybe_Ref_bits512;
// ^ChanConfig
extern const RefT t_Ref_ChanConfig;
// ^ChanState
extern const RefT t_Ref_ChanState;
// ^DeliveryOriginV1
extern const RefT t_Ref_DeliveryOriginV1;
// ^DeliveryRouteV1
extern const RefT t_Ref_DeliveryRouteV1;
// ^DeliveryPayloadV1
extern const RefT t_Ref_DeliveryPayloadV1;
// Maybe MsgAddressInt
extern const Maybe t_Maybe_MsgAddressInt;

// declaration of type name registration function
extern bool register_simple_types(std::function<bool(const char*, const TLB*)> func);

} // namespace gen

} // namespace block
