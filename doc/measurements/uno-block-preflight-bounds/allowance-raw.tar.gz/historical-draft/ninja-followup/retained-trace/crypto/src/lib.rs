#[cfg(panic = "abort")]
compile_error!("uno-crypto requires panic=unwind for ABI containment");

pub mod ffi;
/// cbindgen:ignore
#[unsafe(no_mangle)]
pub extern "C" fn workchain_proof_trace_read(index: usize) -> u64 {
    bulletproofs::OPERATION_TRACE_COUNTS[index].load(core::sync::atomic::Ordering::Relaxed)
}
/// cbindgen:ignore
#[unsafe(no_mangle)]
pub extern "C" fn workchain_proof_trace_reset() {
    for value in &bulletproofs::OPERATION_TRACE_COUNTS {
        value.store(0, core::sync::atomic::Ordering::Relaxed);
    }
}
mod relation;
mod system_encryption;
pub mod statement;
pub use relation::verify_relation;

#[cfg(test)]
mod tests;
