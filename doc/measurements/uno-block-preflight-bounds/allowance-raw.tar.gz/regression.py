import pathlib,subprocess,json,re
p=pathlib.Path(__file__).parent;repo=pathlib.Path('/home/tomi/tos-m2');build=pathlib.Path('/tmp/uno-bounded-policy-private-build');out=p/'regression';out.mkdir(exist_ok=False)
def run(name,cmd):
 r=subprocess.run(list(map(str,cmd)),capture_output=True,cwd=build);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);return r
reg=run('registration',['ctest','--show-only=json-v1']);assert reg.returncode==0
regs=json.loads(reg.stdout)['tests'];worker=repo/'test/test-counter-disk-integration.cmake';mirror=out/'worker';mirror.mkdir();(mirror/worker.name).write_bytes(worker.read_bytes());life=(repo/'test/counter-fixture-lifecycle.cmake').read_text();needle='    file(REMOVE_RECURSE "${fixture}")';assert life.count(needle)==1
(mirror/'counter-fixture-lifecycle.cmake').write_text(life.replace(needle,'    file(ARCHIVE_CREATE OUTPUT "${fixture}.bounded.tar.gz" PATHS "${fixture}" FORMAT gnutar COMPRESSION GZip)\n'+needle))
selected=[t for t in regs if str(worker) in t['command'] or 'workchain-genesis-activation.py' in ' '.join(t['command']) or t['name'].startswith('test-workchain-') or t['name']=='test-smartcont']
quote=lambda x:'[==['+str(x)+']==]';driver=out/'ctest';driver.mkdir();lines=[]
for t in selected:
 cmd=list(t['command'])
 if str(worker) in cmd:cmd[cmd.index(str(worker))]=str(mirror/worker.name)
 if 'workchain-genesis-activation.py' in ' '.join(cmd):cmd+=['--evidence',str(out/t['name'])]
 if 'workchain-proof-trace.py' in ' '.join(cmd):cmd+=['--output',str(out/'proof-trace-raw')]
 lines.append('add_test('+quote(t['name'])+' '+' '.join(map(quote,cmd))+')')
 for v in t.get('properties',[]):
  val=v['value'];val=';'.join(map(str,val)) if isinstance(val,list) else val
  lines.append('set_tests_properties('+quote(t['name'])+' PROPERTIES '+quote(v['name'])+' '+quote(val)+')')
(driver/'CTestTestfile.cmake').write_text('\n'.join(lines)+'\n');report={'scope':'Current registered checks with retention-only lifecycle copy; default production source not altered. All results, including success fixture archives, retained.','selected':selected,'runs':[]}
report['excluded']=[]
report['historical_stop']='Prior draft excluded proof-operation-trace on Makefiles. This new Ninja batch includes it; old results are not inherited.'
for i,t in enumerate(selected):
 r=run(f'{i:02d}', ['ctest','--test-dir',driver,'-V','-j1','-R','^'+re.escape(t['name'])+'$','--no-tests=error','--output-junit',out/f'{i:02d}.xml']);report['runs'].append({'test':t['name'],'exit':r.returncode});(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(t['name'],r.returncode,flush=True)
 if r.returncode:raise SystemExit(1)
