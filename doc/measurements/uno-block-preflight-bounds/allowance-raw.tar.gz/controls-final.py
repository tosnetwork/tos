import pathlib,subprocess,shlex,hashlib,json
repo=pathlib.Path('/home/tomi/tos-m2');build=pathlib.Path('/tmp/uno-bounded-policy-private-build');out=pathlib.Path(__file__).parent/'controls-final';out.mkdir(exist_ok=False)
copy=out/'source';(copy/'crypto/block').mkdir(parents=True);(copy/'crypto/test').mkdir();assert copy.resolve()!=repo.resolve()
header='crypto/block/workchain-resource-policy.h';test='crypto/test/test-workchain-block.cpp';original=(repo/header).read_bytes();testbytes=(repo/test).read_bytes();(copy/header).write_bytes(original);(copy/test).write_bytes(testbytes)
commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands','test-workchain-block'],text=True).splitlines();(out/'commands.txt').write_text('\n'.join(commands))
cc=[x for x in commands if ' -c ' in x and x.endswith('/'+test)];assert len(cc)==1
compile=shlex.split(cc[0]);oldobj=compile[compile.index('-o')+1];obj=out/'test.o';binary=out/'test-workchain-block'
for flag,value in [('-o',str(obj)),('-MF',str(obj)+'.d'),('-MT',str(obj))]:compile[compile.index(flag)+1]=value
compile[compile.index('-c')+1]=str(copy/test);position=2 if pathlib.Path(compile[0]).name=='ccache' else 1;compile[position:position]=['-I'+str(copy/'crypto'),'-I'+str(repo/'crypto/test')]
links=[x for x in commands if ' -o test-workchain-block ' in x];assert len(links)==1
link=shlex.split(links[0]);assert link[:2]==[':','&&'] and link[-2:]==['&&',':'];link=link[2:-2];link=[str(obj) if x==oldobj else x for x in link];link[link.index('-o')+1]=str(binary)
sha=lambda x:hashlib.sha256(x).hexdigest()
report={'scope':'Six isolated codec mutations, NOT C2 accumulation or C3 live enforcement. Only the listed copied object/executable can carry mutations. Every restoration explicitly recompiles and relinks it.','header_sha256':sha(original),'test_sha256':sha(testbytes),'controls':[],'commands':[]}
def run(label,cmd):
 r=subprocess.run(cmd,cwd=build,capture_output=True);(out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);report['commands'].append({'label':label,'argv':cmd,'exit':r.returncode});(out/'report.json').write_text(json.dumps(report,indent=2));return r
def rebuild(label):
 assert run(label+'-compile',compile).returncode==0
 assert run(label+'-link',link).returncode==0
rebuild('baseline');assert run('baseline',[str(binary),'--filter','PreflightAllowanceWire']).returncode==0
s=original.decode();mutations=[
 ('tag-reason','prefix.prefetch_ulong(32) != gen::UnoV2ResourcePolicy::cons_tag[0]','false','unrecognized resource policy constructor tag'),
 ('missing-field-reason','prefix.size() < 128','false','missing or truncated preflight allowance'),
 ('encode-discard','root.preflight_allowance = value.preflight_allowance;','root.preflight_allowance = 0;','root.fetch_ulong(64)'),
 ('decode-discard','header.preflight_allowance};','0};','decoded.ok().preflight_allowance'),
 ('derive-from-result','root.preflight_allowance = value.preflight_allowance;','root.preflight_allowance = value.work_output.max_proof_units;','root.fetch_ulong(64)'),
 ('narrow-allowance','header.preflight_allowance};','static_cast<std::uint32_t>(header.preflight_allowance)};','decoded.ok().preflight_allowance')]
for name,before,after,reason in mutations:
 assert s.count(before)==1;(copy/header).write_text(s.replace(before,after));mutant=(copy/header).read_bytes();rebuild(name)
 result=run(name,[str(binary),'--filter','PreflightAllowanceWire']);assert result.returncode!=0 and reason.encode() in result.stderr,(name,result.stderr[-1500:])
 (copy/header).write_bytes(original);assert (copy/header).read_bytes()==original;rebuild(name+'-restore');assert run(name+'-restore',[str(binary),'--filter','PreflightAllowanceWire']).returncode==0
 assert (repo/header).read_bytes()==original and (repo/test).read_bytes()==testbytes
 report['controls'].append({'name':name,'required_failure':reason,'mutation_sha256':sha(mutant),'restored_sha256':sha(original),'actual_binary':str(binary)});(out/'report.json').write_text(json.dumps(report,indent=2));print(name,'caught/restored',flush=True)
