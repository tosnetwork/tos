from pathlib import Path
import subprocess,hashlib,json,gzip,collections,re
repo=Path('/home/tomi/tos-m2');copy=Path('/tmp/uno-genesis-domain-control');out=repo/'doc/measurements/uno-topic-domain-paths';assert out.is_dir()
git=lambda *a:subprocess.check_output(['git','-C',str(repo),*a]);sha=lambda b:hashlib.sha256(b).hexdigest()
commit=git('rev-parse','HEAD').decode().strip();script='scripts/check-no-removed-execution-domains.sh';target='test/uno-local-profile.py';original=git('show',commit+':'+target)
assert (repo/target).read_bytes()==(copy/target).read_bytes()==original
assert (repo/script).read_bytes()==(copy/script).read_bytes()==git('show',commit+':'+script)
def run(label,scanner,root):
 r=subprocess.run(['bash',str(scanner),str(root)],capture_output=True)
 for stream,data in [('stdout',r.stdout),('stderr',r.stderr)]: (out/(label+'.'+stream+'.log.gz')).write_bytes(gzip.compress(data,mtime=0))
 return r
prior=Path('/tmp/uno-topic-domain-prior.sh');prior.write_bytes(git('show','ba6e28971:'+script))
before=run('before',prior,copy);baseline=run('baseline',repo/script,repo)
assert before.returncode==1 and baseline.returncode==0 and baseline.stderr==b''
assert b'removed-execution-domain scan passed:' in baseline.stdout
added=b'\n# halo2\n';mutant=original+added;(copy/target).write_bytes(mutant)
red=run('retired-control',copy/script,copy);assert red.returncode==1
expected=f'{target}:{len(original.splitlines())+2}: retired implementation symbol: halo2: # halo2'
assert red.stderr.decode().splitlines()==[expected,'removed-execution-domain scan failed']
(copy/target).write_bytes(original);restored=run('restored',copy/script,copy)
assert restored.returncode==0 and restored.stdout==baseline.stdout and restored.stderr==baseline.stderr
assert (repo/target).read_bytes()==(copy/target).read_bytes()==original
classification=[];cache={}
for l in before.stderr.decode().splitlines():
 m=re.match(r'^([^:]+):(\d+):',l)
 if not m:continue
 p,n=m[1],int(m[2]);text=(copy/p).read_text().splitlines()[n-1]
 if p not in cache:
  r=subprocess.run(['git','-C',str(repo),'show','a27ff2c77:'+p],capture_output=True);cache[p]=r.stdout.decode(errors='replace').splitlines() if r.returncode==0 else []
 classification.append({'path':p,'line':n,'text':text,'present_verbatim_at_a27ff2c77':text in cache[p]})
r={'source_commit':commit,'scanner_sha256':sha((repo/script).read_bytes()),'baseline_source':'real B worktree; scanner and mutated input equal committed blobs; unrelated validator draft remains unchanged and is outside this evidence','control_copy':str(copy),'baseline_exit':baseline.returncode,'retired_exit':red.returncode,'restored_exit':restored.returncode,'restored_streams_byte_equal':True,'control':{'path':target,'original_sha256':sha(original),'copy_before_sha256':sha(original),'offset':len(original),'from':'','to':added.decode(),'mutant_sha256':sha(mutant),'restored_sha256':sha((copy/target).read_bytes()),'restore_audit_sha256':sha((copy/target).read_bytes()+added),'only_failure_diagnostic':expected},'before_classification':classification,'before_counts':{'total':len(classification),'verbatim_at_a27ff2c77':sum(x['present_verbatim_at_a27ff2c77'] for x in classification),'new_or_rewritten':sum(not x['present_verbatim_at_a27ff2c77'] for x in classification)},'scope':'Static scanner acceptance. Injected comment contains only the retired identifier, not either execution-domain identifier; failure cannot be attributed to the UNO/EVM fence. No word exemptions or directory-wide patterns added. No native target is involved.'}
(out/'report.json.gz').write_bytes(gzip.compress((json.dumps(r,indent=2)+'\n').encode(),mtime=0));(out/'reproduce.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'commit':commit,'exits':[before.returncode,baseline.returncode,red.returncode,restored.returncode],'before_counts':r['before_counts']},indent=2))
