"""Retained validator calibration acquisition; does not certify a gate result."""
import json, os, shutil, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIXTURE = Path('/tmp/uno-a2-registry-jqOjoDbi/fixture')
BINARY = ROOT / 'fresh-build/test-tos-collator'
label = sys.argv[1]
assert label in ('earlier', 'gate', 'reject', 'accept')
if label == 'accept':
    FIXTURE = Path('/tmp/uno-a2-registry-jqOjoDbi/singleton-input')
run = ROOT / (sys.argv[2] if len(sys.argv) > 2 else label)
run.mkdir()
shutil.copytree(FIXTURE / 'peer/db', run / 'db')
shutil.copyfile('/home/tomi/tos/doc/measurements/uno-validator-input-reachability/candidate.bin', run / 'candidate.bin')
if label == 'accept':
    shutil.copyfile(FIXTURE / 'idle1.candidate', run / 'candidate.bin')
if label == 'reject':
    data = bytearray((run / 'candidate.bin').read_bytes())
    data[88] ^= 1  # Bare blockIdExt file_hash; leave the BOC bytes intact.
    (run / 'candidate.bin').write_bytes(data)
symbols = [line.split()[-1] for line in subprocess.check_output(['nm', str(BINARY)], text=True).splitlines() if len(line.split()) == 3]
def one(predicate):
    matches = [s for s in symbols if predicate(s)]
    assert len(matches) == 1, matches
    return "*'" + matches[0] + "'"
sites = {
    'registry': one(lambda s: s.startswith('_ZNK') and '28validate_required_workchains' in s and '$_' not in s),
    'account_variant': one(lambda s: s.startswith('_ZZ') and '28validate_required_workchains' in s and s.endswith('clERKNS_31ResolvedWorkchainAccountBindingE')),
}
for key, owner, method in [('collator', 'Collator', 'do_collate_inner'), ('validator_config', 'ValidateQuery', 'fetch_config_params'), ('validator_ready', 'ValidateQuery', 'check_this_shard_mc_info'), ('validator_transactions', 'ValidateQuery', 'check_transactions')]:
    sites['downstream_' + key] = one(lambda s: s.startswith('_ZZ') and owner in s and method in s and s.endswith('clERKN5block31ResolvedWorkchainAccountBindingE'))
sites['transaction_check'] = one(lambda s: s.startswith('_ZN3tos9validator13ValidateQuery15CheckAccountTxs21check_one_transaction'))
source = ROOT / 'source/crypto/block/workchain-execution-dispatch.cpp'
lines = source.read_text().splitlines()
start = next(i for i, line in enumerate(lines) if 'td::Status WorkchainExecutionRegistry::validate_required_workchains(' in line)
line = next(i + 1 for i in range(start, len(lines)) if '"multi-account admission and replay are not connected"' in lines[i])
sites['account_refusal'] = str(source) + ':' + str(line)
(ROOT / 'sites.json').write_text(json.dumps(sites, indent=2))
shutil.copyfile('/home/tomi/tos/doc/measurements/uno-a2-validator-closed/observe.gdb', ROOT / 'observe.gdb')
prev = '(2,8000000000000000,0):' + (FIXTURE / 'counter-state.rhash').read_bytes().hex() + ':' + (FIXTURE / 'counter-state.fhash').read_bytes().hex()
cmd = ['gdb', '-q', '-nx', '--batch', '--return-child-result', '-x', str(ROOT / 'observe.gdb'), '--args', str(BINARY), '-C', str(FIXTURE / 'global.json'), '-D', str(run / 'db'), '-w', '2', '-T', prev, '--counter-increment', '1', '--account-binding-probe', str(run / 'calls.txt'), '--import-candidate', str(run / 'candidate.bin'), '--query-result', str(run / 'result'), '--export-candidate', str(run / 'unexpected-export')]
if label == 'earlier':
    cmd.append('--account-probe-config-failure')
if label == 'accept':
    index = cmd.index('--account-binding-probe')
    del cmd[index:index + 2]
(run / 'argv.json').write_text(json.dumps(cmd, indent=2))
with (run / 'run.log').open('xb') as output:
    result = subprocess.run(cmd, stdout=output, stderr=subprocess.STDOUT, env=dict(os.environ, A2_ROOT=str(ROOT), A2_TRACE=str(run / 'trace.json')), timeout=110)
print('Process exit (not classification):', result.returncode)
for path in sorted(run.glob('result.validation.*')):
    print(path.name, repr(path.read_text()))
