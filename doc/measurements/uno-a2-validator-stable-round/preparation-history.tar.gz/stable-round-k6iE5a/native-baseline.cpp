/*
    This file is part of TOS Blockchain Library.

    TOS Blockchain Library is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    TOS Blockchain Library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with TOS Blockchain Library.  If not, see <http://www.gnu.org/licenses/>.

    Copyright 2017-2020 Telegram Systems LLP
    Copyright 2025-2026 TOS Blockchain Teams
*/
#include "adnl/utils.hpp"
#include "common/checksum.h"
#include "td/utils/filesystem.h"
#include "td/utils/Time.h"
#include "db/celldb.hpp"
#include "downloaders/wait-block-data-disk.hpp"
#include "downloaders/wait-block-state-merge.hpp"
#include "downloaders/wait-block-state.hpp"
#include "td/utils/overloaded.h"
#include "tos/tos-io.hpp"

#include "fabric.h"
#include "manager-disk.hpp"
#include "manager.h"
#include "impl/out-msg-queue-proof.hpp"
#include "validator-group.hpp"

namespace tos {

namespace validator {

void ValidatorManagerImpl::log_collate_query_stats(CollationStats stats) {
  if (query_result_path_.empty() || collation_observation_closed_) return;
  // Evidence must be persisted before the result callback can exit the tool.
  // An absent stats message must not be interpreted as a zero observation.
  td::write_file(query_result_path_ + ".stats",
                 PSLICE() << "delivery=recorded\nvisited=" << (stats.account_binding_visited ? 1 : 0)
                          << "\nadapter=" << (stats.account_adapter_bound ? 1 : 0)
                          << "\nowners_before=" << stats.account_config_owners_before
                          << "\nowners_during=" << stats.account_config_owners_during
                          << "\nowners_after=" << stats.account_config_owners_after
                          << "\ntransactions=" << stats.transactions << "\n").ensure();
  // Separate lifecycle observations preserve the existing stats wire for old
  // tools, without implying that release happened inside the binding branch.
  td::write_file(query_result_path_ + ".binding",
                 PSLICE() << "retained_after_state=" << (stats.account_adapter_retained_after_state ? 1 : 0)
                          << "\nreleased=" << (stats.account_adapter_released ? 1 : 0) << "\n").ensure();
  // This interval includes the whole query up to the completed stats write,
  // not just message delivery. It is a conservative normal-run observation,
  // not an upper bound under arbitrary scheduler or storage delays.
  const double query_to_record = td::Clocks::monotonic() - collation_observation_started_;
  td::write_file(query_result_path_ + ".stats.timing",
                 PSLICE() << "query_to_record_seconds=" << query_to_record
                          << "\nwait_window_seconds=" << collation_stats_wait_seconds_
                          << "\nheadroom_ratio="
                          << (query_to_record > 0 ? collation_stats_wait_seconds_ / query_to_record : 0.0)
                          << "\n").ensure();
  collation_observation_closed_ = true;
  alarm_timestamp() = td::Timestamp::never();
  if (collation_stats_waiter_) collation_stats_waiter_.set_value(td::Unit());
}

void ValidatorManagerImpl::await_collation_stats(td::Promise<td::Unit> promise) {
  if (query_result_path_.empty() || collation_observation_closed_) {
    promise.set_value(td::Unit());
  } else {
    // This manager launches one collation query; there is one continuation.
    collation_stats_waiter_ = std::move(promise);
    // Offline observation deadline, not a protocol timeout. Early startup
    // failures can complete the result without ever emitting statistics.
    collation_wait_started_ = td::Clocks::monotonic();
    alarm_timestamp() = td::Timestamp::in(collation_stats_wait_seconds_);
  }
}

void ValidatorManagerImpl::alarm() {
  if (collation_stats_waiter_) {
    td::write_file(query_result_path_ + ".stats", "delivery=unconfirmed\n").ensure();
    td::write_file(query_result_path_ + ".stats.timing",
                   PSLICE() << "wait_elapsed_seconds=" << (td::Clocks::monotonic() - collation_wait_started_)
                            << "\nwait_window_seconds=" << collation_stats_wait_seconds_ << "\n").ensure();
    // A late message must not rewrite an already terminal observation.
    collation_observation_closed_ = true;
    collation_stats_waiter_.set_value(td::Unit());
  }
}

void ValidatorManagerImpl::validate_block_is_next_proof(BlockIdExt prev_block_id, BlockIdExt next_block_id,
                                                        td::BufferSlice proof, td::Promise<td::Unit> promise) {
  UNREACHABLE();
}

void ValidatorManagerImpl::validate_block_proof(BlockIdExt block_id, td::BufferSlice proof,
                                                td::Promise<td::Unit> promise) {
  auto pp = create_proof(block_id, std::move(proof));
  if (pp.is_error()) {
    promise.set_error(pp.move_as_error());
    return;
  }

  auto P = td::PromiseCreator::lambda([promise = std::move(promise)](td::Result<BlockHandle> R) mutable {
    if (R.is_error()) {
      promise.set_error(R.move_as_error());
    } else {
      promise.set_value(td::Unit());
    }
  });
  run_check_proof_query(block_id, pp.move_as_ok(), actor_id(this), td::Timestamp::in(2.0), std::move(P));
}

void ValidatorManagerImpl::validate_block_proof_link(BlockIdExt block_id, td::BufferSlice proof,
                                                     td::Promise<td::Unit> promise) {
  UNREACHABLE();
}

void ValidatorManagerImpl::validate_block(ReceivedBlock block, td::Promise<BlockHandle> promise) {
  UNREACHABLE();
}

void ValidatorManagerImpl::new_block_broadcast(BlockBroadcast broadcast, bool signatures_checked,
                                               BroadcastSource source,
                                               td::Promise<td::Unit> promise) {
  UNREACHABLE();
}

void ValidatorManagerImpl::validate_block_broadcast_signatures(BlockBroadcast broadcast,
                                                               td::Promise<td::Unit> promise) {
  UNREACHABLE();
}

void ValidatorManagerImpl::wait_state_by_prev_blocks(BlockIdExt block_id, std::vector<BlockIdExt> prev_blocks,
                                                     td::Promise<td::Ref<ShardState>> promise) {
  if (prev_blocks.empty() || prev_blocks.size() > 2) {
    promise.set_error(td::Status::Error("invalid prev blocks count for state request"));
    return;
  }

  if (prev_blocks.size() == 1) {
    LOG(DEBUG) << "Requesting state for single prev block " << prev_blocks[0].to_str() << " for " << block_id.to_str();
    wait_block_state_short(prev_blocks[0], 0, td::Timestamp::in(10.0), false, std::move(promise));
    return;
  }

  LOG(DEBUG) << "Requesting merged state for prev blocks " << prev_blocks[0].to_str() << " and "
             << prev_blocks[1].to_str() << " for " << block_id.to_str();
  wait_block_state_merge(prev_blocks[0], prev_blocks[1], 0, td::Timestamp::in(10.0), std::move(promise));
}

void ValidatorManagerImpl::wait_neighbor_msg_queue_proofs(
    ShardIdFull dst_shard, std::vector<BlockIdExt> blocks, td::Timestamp timeout,
    td::Promise<std::map<BlockIdExt, td::Ref<OutMsgQueueProof>>> promise) {
  if (out_msg_queue_importer_.empty()) {
    auto local_options = opts_;
    local_options.write().set_shard_check_function([](ShardIdFull, BlockSeqno) { return true; });
    out_msg_queue_importer_ = td::actor::create_actor<OutMsgQueueImporter>(
        "disk-outmsgqueueimporter", actor_id(this), std::move(local_options), last_masterchain_state_);
  }
  td::actor::send_closure(out_msg_queue_importer_, &OutMsgQueueImporter::get_neighbor_msg_queue_proofs,
                          dst_shard, std::move(blocks), timeout, std::move(promise));
}

void ValidatorManagerImpl::sync_complete(td::Promise<td::Unit> promise) {
  for (auto& raw : pending_ext_messages_) {
    auto parsed = create_ext_message(std::move(raw), last_masterchain_state_->get_ext_msg_limits());
    if (parsed.is_error()) {
      LOG(ERROR) << "invalid queued disk external message: " << parsed.move_as_error();
      std::exit(2);
    }
    ext_messages_.push_back(parsed.move_as_ok());
  }
  pending_ext_messages_.clear();
  started_ = true;

  //ShardIdFull shard_id{masterchainId, shardIdAll};
  auto shard_id = shard_to_generate_;

  auto block_id = block_to_generate_;

  std::vector<BlockIdExt> prev;
  if (!block_id.is_valid()) {
    if (shard_id.is_masterchain()) {
      prev = {last_masterchain_block_id_};
    } else {
      auto S = last_masterchain_state_->get_shard_from_config(shard_id);
      if (S.not_null()) {
        prev = {S->top_block_id()};
      } else {
        S = last_masterchain_state_->get_shard_from_config(shard_parent(shard_id));
        if (S.not_null()) {
          CHECK(S->before_split());
          prev = {S->top_block_id()};
        } else {
          S = last_masterchain_state_->get_shard_from_config(shard_child(shard_id, true));
          CHECK(S.not_null());
          CHECK(S->before_merge());
          auto S2 = last_masterchain_state_->get_shard_from_config(shard_child(shard_id, false));
          CHECK(S2.not_null());
          CHECK(S2->before_merge());
          prev = {S->top_block_id(), S2->top_block_id()};
        }
      }
    }
  } else {
    CHECK(block_id.shard_full() == shard_id);
    prev = {block_id};
  }

  //LOG(DEBUG) << "before get_validator_set";
  auto val_set = last_masterchain_state_->get_validator_set(shard_id);
  if (!import_candidate_.empty()) {
    auto read = td::read_file(import_candidate_);
    if (read.is_error()) {
      LOG(ERROR) << "cannot read imported candidate: " << read.error();
      std::exit(2);
    }
    auto decoded = fetch_tl_object<tos_api::db_candidate>(read.move_as_ok(), true);
    if (decoded.is_error()) {
      LOG(ERROR) << "cannot decode imported candidate: " << decoded.error();
      std::exit(2);
    }
    auto value = decoded.move_as_ok();
    if (!value->source_ || value->source_->get_id() != tos_api::pub_ed25519::ID || !value->id_) {
      LOG(ERROR) << "invalid imported candidate identity";
      std::exit(2);
    }
    auto id = create_block_id(value->id_);
    if (id.shard_full() != shard_id) {
      LOG(ERROR) << "imported candidate differs from requested shard";
      std::exit(2);
    }
    auto key = PublicKey{value->source_};
    auto hash = sha256_bits256(value->collated_data_);
    LOG(INFO) << "validating imported candidate " << id.to_str();
    validate_fake(BlockCandidate{Ed25519_PublicKey{key.ed25519_value().raw()}, id, hash,
                                 std::move(value->data_), std::move(value->collated_data_)},
                  std::move(prev), last_masterchain_block_id_, std::move(val_set));
    return;
  }
  //LOG(DEBUG) << "after get_validator_set: addr=" << (const void*)val_set.get();

  td::Promise<BlockCandidate> P = td::PromiseCreator::lambda(
      [SelfId = actor_id(this), last = last_masterchain_block_id_, val_set, prev,
       result_path = query_result_path_](td::Result<BlockCandidate> R) {
        // Disk-tool observation only. Own the path across the actor callback;
        // record the typed result before logging or moving the error.
        if (!result_path.empty()) {
          td::write_file(result_path, PSLICE() << "collate " << (R.is_ok() ? 0 : R.error().code()) << "\n").ensure();
          // Preserve the terminal typed result, not a potentially misleading
          // later log. A numeric zero alone does not identify Status success.
          td::write_file(result_path + ".kind", td::Slice(R.is_ok() ? "success\n" : "error\n")).ensure();
          td::write_file(result_path + ".message", R.is_ok() ? td::Slice{} : R.error().message()).ensure();
        }
        if (R.is_ok()) {
          auto v = R.move_as_ok();
          LOG(ERROR) << "created block " << v.id;
          td::actor::send_closure(SelfId, &ValidatorManagerImpl::validate_fake, std::move(v), std::move(prev), last,
                                  val_set);
        } else {
          LOG(ERROR) << "failed to create block: " << R.move_as_error();
          std::exit(2);
        }
      });

  if (!query_result_path_.empty()) {
    td::write_file(query_result_path_ + ".stats", "delivery=pending\n").ensure();
    collation_observation_started_ = td::Clocks::monotonic();
    // Join the two actor messages instead of assuming the statistics send
    // finishes before the result callback. Only the offline observer opts in.
    P = td::PromiseCreator::lambda(
        [SelfId = actor_id(this), continuation = std::move(P)](td::Result<BlockCandidate> result) mutable {
          td::actor::send_closure(
              SelfId, &ValidatorManagerImpl::await_collation_stats,
              td::PromiseCreator::lambda(
                  [continuation = std::move(continuation), result = std::move(result)](
                      td::Result<td::Unit> recorded) mutable {
                    recorded.ensure();
                    continuation.set_result(std::move(result));
                  }));
        });
  }

  LOG(ERROR) << "running collate query";
  if (local_id_.is_zero()) {
    //td::as<td::uint32>(created_by_.data() + 32 - 4) = ((unsigned)std::time(nullptr) >> 8);
  }
  Ed25519_PublicKey created_by{td::Bits256::zero()};
  td::as<td::uint32>(created_by.as_bits256().data() + 32 - 4) = ((unsigned)std::time(nullptr) >> 8);
  td::Ref<CollatorOptions> options;
  if (block_candidate_.not_null()) {
    // Disk-only block fixture: defer the second output to exercise queue recovery.
    options = td::make_ref<CollatorOptions>();
    options.write().defer_messages_after = 1;
  }
  run_collate_query(CollateParams{.shard = shard_id,
                                  .min_masterchain_block_id = last_masterchain_block_id_,
                                  .prev = prev,
                                  .creator = created_by,
                                  .validator_set = val_set,
                                  .collator_opts = std::move(options),
                                  .workchain_block_candidate = block_candidate_},
                    actor_id(this), {}, std::move(P));
}

void ValidatorManagerImpl::validate_fake(BlockCandidate candidate, std::vector<BlockIdExt> prev, BlockIdExt last,
                                         td::Ref<block::ValidatorSet> val_set) {
  if (!query_result_path_.empty()) {
    td::write_file(query_result_path_ + ".validation.delivery", "pending\n").ensure();
  }
  auto P = td::PromiseCreator::lambda([SelfId = actor_id(this), c = candidate.clone(), prev, last,
                                       val_set, result_path = query_result_path_](td::Result<ValidateCandidateResult> R) mutable {
    // Disk-tool observation only. Preserve the terminal variant before moving
    // it or logging: a local error and CandidateReject are different outcomes,
    // even though this tool exits with status 2 for both. Never overwrite the
    // collator sidecars when successful collation proceeds to validation.
    if (!result_path.empty()) {
      const auto prefix = result_path + ".validation";
      auto record = [&](td::Slice kind, td::Slice result, td::Slice message) {
        td::write_file(prefix + ".kind", kind).ensure();
        td::write_file(prefix + ".result", result).ensure();
        td::write_file(prefix + ".message", message).ensure();
        // Last write confirms the result callback was received and all three
        // typed fields were persisted; absence is not a zero-work observation.
        td::write_file(prefix + ".delivery", "recorded\n").ensure();
      };
      if (R.is_error()) {
        record("error\n", PSLICE() << "validate " << R.error().code() << "\n", R.error().message());
      } else {
        R.ok().visit(td::overloaded(
            [&](const CandidateAccept&) { record("accept\n", "validate accept\n", td::Slice{}); },
            [&](const CandidateReject& reject) { record("reject\n", "validate reject\n", reject.reason); }));
      }
    }
    if (R.is_ok()) {
      auto v = R.move_as_ok();
      v.visit(td::overloaded(
          [&](CandidateAccept) {
            td::actor::send_closure(SelfId, &ValidatorManagerImpl::write_fake, std::move(c), prev, last, val_set);
          },
          [&](CandidateReject reject) {
            LOG(ERROR) << "failed to create block: " << reject.reason;
            std::exit(2);
          }));
    } else {
      LOG(ERROR) << "failed to create block: " << R.move_as_error();
      std::exit(2);
    }
  });
  auto shard = candidate.id.shard_full();
  run_validate_query(std::move(candidate),
                     ValidateParams{.shard = shard,
                                    .min_masterchain_block_id = last,
                                    .prev = prev,
                                    .validator_set = std::move(val_set),
                                    .is_fake = true},
                     actor_id(this), td::Timestamp::in(10.0), std::move(P));
}

void ValidatorManagerImpl::write_fake(BlockCandidate candidate, std::vector<BlockIdExt> prev, BlockIdExt last,
                                      td::Ref<block::ValidatorSet> val_set) {
  if (!export_candidate_.empty()) {
    auto source = PublicKey{pubkeys::Ed25519{candidate.pubkey.as_bits256()}};
    auto bytes = create_serialize_tl_object<tos_api::db_candidate>(
        source.tl(), create_tl_block_id(candidate.id), candidate.data.clone(), candidate.collated_data.clone());
    auto status = td::write_file(export_candidate_, bytes.as_slice());
    if (status.is_error()) {
      LOG(ERROR) << "cannot export validated candidate: " << status;
      std::exit(2);
    }
  }
  auto P = td::PromiseCreator::lambda([SelfId = actor_id(this), id = candidate.id](td::Result<td::Unit> R) {
    if (R.is_ok()) {
      td::actor::send_closure(SelfId, &ValidatorManagerImpl::complete_fake, id);
    } else {
      LOG(ERROR) << "failed to create block: " << R.move_as_error();
      std::exit(2);
    }
  });
  auto data = create_block(candidate.id, std::move(candidate.data)).move_as_ok();

  run_fake_accept_block_query(candidate.id, data, prev, val_set, actor_id(this), std::move(P),
                              !candidate.id.is_masterchain());
}

void ValidatorManagerImpl::complete_fake(BlockIdExt block_id) {
  LOG(ERROR) << "success, block " << block_id << " = " << block_id.to_str() << " saved to disk";
  std::exit(0);
}

void ValidatorManagerImpl::get_next_block(BlockIdExt block_id, td::Promise<BlockHandle> promise) {
  UNREACHABLE();
}

void ValidatorManagerImpl::get_block_data(BlockHandle handle, td::Promise<td::BufferSlice> promise) {
  auto P = td::PromiseCreator::lambda([promise = std::move(promise)](td::Result<td::Ref<BlockData>> R) mutable {
    if (R.is_error()) {
      promise.set_error(R.move_as_error());
    } else {
      auto B = R.move_as_ok();
      promise.set_value(B->data());
    }
  });

  get_block_data_from_db(handle, std::move(P));
}

void ValidatorManagerImpl::check_zero_state_exists(BlockIdExt block_id, td::Promise<bool> promise) {
  td::actor::send_closure(db_, &Db::check_zero_state_file_exists, block_id, std::move(promise));
}
void ValidatorManagerImpl::get_zero_state(BlockIdExt block_id, td::Promise<td::BufferSlice> promise) {
  td::actor::send_closure(db_, &Db::get_zero_state_file, block_id, std::move(promise));
}

void ValidatorManagerImpl::get_persistent_state_size(BlockIdExt block_id, BlockIdExt masterchain_block_id,
                                                     PersistentStateType type, td::Promise<td::uint64> promise) {
  td::actor::send_closure(db_, &Db::get_persistent_state_file_size, block_id, masterchain_block_id, type,
                          std::move(promise));
}
void ValidatorManagerImpl::get_persistent_state(BlockIdExt block_id, BlockIdExt masterchain_block_id,
                                                PersistentStateType type, td::Promise<td::BufferSlice> promise) {
  td::actor::send_closure(db_, &Db::get_persistent_state_file, block_id, masterchain_block_id, type,
                          std::move(promise));
}

void ValidatorManagerImpl::get_block_proof(BlockHandle handle, td::Promise<td::BufferSlice> promise) {
  auto P = td::PromiseCreator::lambda([promise = std::move(promise)](td::Result<td::Ref<Proof>> R) mutable {
    if (R.is_error()) {
      promise.set_error(R.move_as_error());
    } else {
      auto B = R.move_as_ok();
      promise.set_value(B->data());
    }
  });

  td::actor::send_closure(db_, &Db::get_block_proof, handle, std::move(P));
}

void ValidatorManagerImpl::get_key_block_proof(BlockIdExt block_id, td::Promise<td::BufferSlice> promise) {
  auto P = td::PromiseCreator::lambda([promise = std::move(promise)](td::Result<td::Ref<Proof>> R) mutable {
    if (R.is_error()) {
      promise.set_error(R.move_as_error());
    } else {
      auto B = R.move_as_ok();
      promise.set_value(B->data());
    }
  });

  td::actor::send_closure(db_, &Db::get_key_block_proof, block_id, std::move(P));
}

void ValidatorManagerImpl::get_key_block_proof_link(BlockIdExt block_id, td::Promise<td::BufferSlice> promise) {
  auto P = td::PromiseCreator::lambda(
      [promise = std::move(promise), block_id, db = db_.get()](td::Result<td::Ref<Proof>> R) mutable {
        if (R.is_error()) {
          // Round 158 + 159 LOW fix: fallback queries the proof-LINK
          // table, not the full-proof table again.  Round 158 fixed
          // the call-site target but kept the inner lambda's
          // result type as Result<Ref<Proof>>; Db::get_key_block_
          // proof_link returns Result<Ref<ProofLink>>, so the lambda
          // result type must match.  The live manager at
          // manager.cpp:498-508 uses ProofLink here.
          auto P = td::PromiseCreator::lambda([promise = std::move(promise)](td::Result<td::Ref<ProofLink>> R) mutable {
            if (R.is_error()) {
              promise.set_error(R.move_as_error());
            } else {
              auto B = R.move_as_ok();
              promise.set_value(B->data());
            }
          });

          td::actor::send_closure(db, &Db::get_key_block_proof_link, block_id, std::move(P));
        } else {
          auto B = R.move_as_ok()->export_as_proof_link().move_as_ok();
          promise.set_value(B->data());
        }
      });

  td::actor::send_closure(db_, &Db::get_key_block_proof, block_id, std::move(P));
}

td::actor::Task<> ValidatorManagerImpl::new_external_message_broadcast(td::BufferSlice data, int priority,
                                                                        td::optional<PublicKeyHash> source_peer) {
  // Disk-replay manager treats source_peer as informational only here.
  (void)source_peer;
  if (last_masterchain_state_.is_null()) {
    pending_ext_messages_.push_back(std::move(data));
    co_return td::Unit{};
  }
  auto msg = co_await create_ext_message(std::move(data), last_masterchain_state_->get_ext_msg_limits());
  ext_messages_.emplace_back(std::move(msg));
  co_return td::Unit{};
}

void ValidatorManagerImpl::new_ihr_message(td::BufferSlice data) {
  auto R = create_ihr_message(std::move(data));
  if (R.is_ok()) {
    ihr_messages_.emplace_back(R.move_as_ok());
  }
}

void ValidatorManagerImpl::new_shard_block_description_broadcast(BlockIdExt block_id, CatchainSeqno cc_seqno,
                                                                 td::BufferSlice data) {
  if (!last_masterchain_block_handle_) {
    shard_blocks_raw_.push_back(std::move(data));
    return;
  }
  auto P = td::PromiseCreator::lambda([SelfId = actor_id(this)](td::Result<td::Ref<ShardTopBlockDescription>> R) {
    if (R.is_error()) {
      LOG(WARNING) << "dropping invalid new shard block description: " << R.move_as_error();
      td::actor::send_closure(SelfId, &ValidatorManagerImpl::dec_pending_new_blocks);
    } else {
      // LOG(DEBUG) << "run_validate_shard_block_description() completed successfully";
      td::actor::send_closure(SelfId, &ValidatorManagerImpl::add_shard_block_description, R.move_as_ok());
    }
  });
  ++pending_new_shard_block_descr_;
  // LOG(DEBUG) << "new run_validate_shard_block_description()";
  run_validate_shard_block_description(std::move(data), last_masterchain_block_handle_, last_masterchain_state_,
                                       actor_id(this), td::Timestamp::in(2.0), std::move(P), true);
}

void ValidatorManagerImpl::add_shard_block_description(td::Ref<ShardTopBlockDescription> desc) {
  if (desc->may_be_valid(last_masterchain_block_handle_, last_masterchain_state_)) {
    shard_blocks_.insert(std::move(desc));
  }
  dec_pending_new_blocks();
}

void ValidatorManagerImpl::dec_pending_new_blocks() {
  if (!--pending_new_shard_block_descr_ && !waiting_new_shard_block_descr_.empty()) {
    std::vector<td::Ref<ShardTopBlockDescription>> res{shard_blocks_.begin(), shard_blocks_.end()};
    auto promises = std::move(waiting_new_shard_block_descr_);
    waiting_new_shard_block_descr_.clear();
    for (auto &promise : promises) {
      promise.set_result(res);
    }
  }
}

void ValidatorManagerImpl::wait_block_state(BlockHandle handle, td::uint32 priority, td::Timestamp timeout,
                                            bool wait_store, td::Promise<td::Ref<ShardState>> promise) {
  auto it = wait_state_.find(handle->id());
  if (it == wait_state_.end()) {
    auto P = td::PromiseCreator::lambda([SelfId = actor_id(this), handle](td::Result<td::Ref<ShardState>> R) {
      td::actor::send_closure(SelfId, &ValidatorManagerImpl::finished_wait_state, handle->id(), std::move(R));
    });
    auto id = td::actor::create_actor<WaitBlockState>("waitstate", handle, 0, opts_, last_masterchain_state_,
                                                      actor_id(this), td::Timestamp::in(10.0),
                                                      td::Promise<td::Ref<ShardState>>{}, std::move(P))
                  .release();
    wait_state_[handle->id()].actor_ = id;
    it = wait_state_.find(handle->id());
  }

  it->second.waiting_.emplace_back(
      std::pair<td::Timestamp, td::Promise<td::Ref<ShardState>>>(timeout, std::move(promise)));
  td::actor::send_closure(it->second.actor_, &WaitBlockState::update_timeout, timeout, 0);
}

void ValidatorManagerImpl::wait_block_state_short(BlockIdExt block_id, td::uint32 priority, td::Timestamp timeout,
                                                  bool wait_store, td::Promise<td::Ref<ShardState>> promise) {
  auto P = td::PromiseCreator::lambda(
      [=, SelfId = actor_id(this), promise = std::move(promise)](td::Result<BlockHandle> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
          return;
        }
        td::actor::send_closure(SelfId, &ValidatorManagerImpl::wait_block_state, R.move_as_ok(), 0, timeout, wait_store,
                                std::move(promise));
      });
  get_block_handle(block_id, true, std::move(P));
}

void ValidatorManagerImpl::wait_block_data(BlockHandle handle, td::uint32 priority, td::Timestamp timeout,
                                           td::Promise<td::Ref<BlockData>> promise) {
  auto it = wait_block_data_.find(handle->id());
  if (it == wait_block_data_.end()) {
    auto P = td::PromiseCreator::lambda([SelfId = actor_id(this), handle](td::Result<td::Ref<BlockData>> R) {
      td::actor::send_closure(SelfId, &ValidatorManagerImpl::finished_wait_data, handle->id(), std::move(R));
    });
    auto id = td::actor::create_actor<WaitBlockDataDisk>("waitdata", handle, actor_id(this), td::Timestamp::in(10.0),
                                                         std::move(P))
                  .release();
    wait_block_data_[handle->id()].actor_ = id;
    it = wait_block_data_.find(handle->id());
  }

  it->second.waiting_.emplace_back(
      std::pair<td::Timestamp, td::Promise<td::Ref<BlockData>>>(timeout, std::move(promise)));
  td::actor::send_closure(it->second.actor_, &WaitBlockDataDisk::update_timeout, timeout);
}

void ValidatorManagerImpl::wait_block_data_short(BlockIdExt block_id, td::uint32 priority, td::Timestamp timeout,
                                                 td::Promise<td::Ref<BlockData>> promise) {
  auto P = td::PromiseCreator::lambda(
      [SelfId = actor_id(this), timeout, promise = std::move(promise)](td::Result<BlockHandle> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
          return;
        }
        td::actor::send_closure(SelfId, &ValidatorManagerImpl::wait_block_data, R.move_as_ok(), 0, timeout,
                                std::move(promise));
      });
  get_block_handle(block_id, true, std::move(P));
}

void ValidatorManagerImpl::wait_block_state_merge(BlockIdExt left_id, BlockIdExt right_id, td::uint32 priority,
                                                  td::Timestamp timeout, td::Promise<td::Ref<ShardState>> promise) {
  td::actor::create_actor<WaitBlockStateMerge>("merge", left_id, right_id, 0, actor_id(this), timeout,
                                               std::move(promise))
      .release();
}

void ValidatorManagerImpl::wait_prev_block_state(BlockHandle handle, td::uint32 priority, td::Timestamp timeout,
                                                 td::Promise<td::Ref<ShardState>> promise) {
  CHECK(handle);
  CHECK(!handle->is_zero());
  if (!handle->merge_before()) {
    auto shard = handle->id().shard_full();
    auto prev_shard = handle->one_prev(true).shard_full();
    if (shard == prev_shard) {
      wait_block_state_short(handle->one_prev(true), 0, timeout, true, std::move(promise));
    } else {
      CHECK(shard_parent(shard) == prev_shard);
      bool left = shard_child(prev_shard, true) == shard;
      auto P =
          td::PromiseCreator::lambda([promise = std::move(promise), left](td::Result<td::Ref<ShardState>> R) mutable {
            if (R.is_error()) {
              promise.set_error(R.move_as_error());
            } else {
              auto s = R.move_as_ok();
              auto r = s->split();
              if (r.is_error()) {
                promise.set_error(r.move_as_error());
              } else {
                auto v = r.move_as_ok();
                promise.set_value(left ? std::move(v.first) : std::move(v.second));
              }
            }
          });
      wait_block_state_short(handle->one_prev(true), 0, timeout, true, std::move(P));
    }
  } else {
    wait_block_state_merge(handle->one_prev(true), handle->one_prev(false), 0, timeout, std::move(promise));
  }
}

void ValidatorManagerImpl::wait_block_proof(BlockHandle handle, td::Timestamp timeout,
                                            td::Promise<td::Ref<Proof>> promise) {
  td::actor::send_closure(db_, &Db::get_block_proof, handle, std::move(promise));
}

void ValidatorManagerImpl::wait_block_proof_short(BlockIdExt block_id, td::Timestamp timeout,
                                                  td::Promise<td::Ref<Proof>> promise) {
  auto P = td::PromiseCreator::lambda(
      [SelfId = actor_id(this), timeout, promise = std::move(promise)](td::Result<BlockHandle> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
          return;
        }
        td::actor::send_closure(SelfId, &ValidatorManagerImpl::wait_block_proof, R.move_as_ok(), timeout,
                                std::move(promise));
      });
  get_block_handle(block_id, true, std::move(P));
}

void ValidatorManagerImpl::wait_block_proof_link(BlockHandle handle, td::Timestamp timeout,
                                                 td::Promise<td::Ref<ProofLink>> promise) {
  td::actor::send_closure(db_, &Db::get_block_proof_link, std::move(handle), std::move(promise));
}

void ValidatorManagerImpl::wait_block_proof_link_short(BlockIdExt block_id, td::Timestamp timeout,
                                                       td::Promise<td::Ref<ProofLink>> promise) {
  auto P = td::PromiseCreator::lambda(
      [SelfId = actor_id(this), timeout, promise = std::move(promise)](td::Result<BlockHandle> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
          return;
        }
        td::actor::send_closure(SelfId, &ValidatorManagerImpl::wait_block_proof_link, R.move_as_ok(), timeout,
                                std::move(promise));
      });
  get_block_handle(block_id, true, std::move(P));
}

void ValidatorManagerImpl::wait_block_signatures(BlockHandle handle, td::Timestamp timeout,
                                                 td::Promise<td::Ref<block::BlockSignatureSet>> promise) {
  td::actor::send_closure(db_, &Db::get_block_signatures, handle, std::move(promise));
}

void ValidatorManagerImpl::wait_block_signatures_short(BlockIdExt block_id, td::Timestamp timeout,
                                                       td::Promise<td::Ref<block::BlockSignatureSet>> promise) {
  auto P = td::PromiseCreator::lambda(
      [SelfId = actor_id(this), timeout, promise = std::move(promise)](td::Result<BlockHandle> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
          return;
        }
        td::actor::send_closure(SelfId, &ValidatorManagerImpl::wait_block_signatures, R.move_as_ok(), timeout,
                                std::move(promise));
      });
  get_block_handle(block_id, true, std::move(P));
}

void ValidatorManagerImpl::wait_block_message_queue(BlockHandle handle, td::uint32 priority, td::Timestamp timeout,
                                                    td::Promise<td::Ref<MessageQueue>> promise) {
  auto P = td::PromiseCreator::lambda([promise = std::move(promise)](td::Result<td::Ref<ShardState>> R) mutable {
    if (R.is_error()) {
      promise.set_error(R.move_as_error());
    } else {
      auto state = R.move_as_ok();
      promise.set_result(state->message_queue());
    }
  });

  wait_block_state(handle, 0, timeout, true, std::move(P));
}

void ValidatorManagerImpl::wait_block_message_queue_short(BlockIdExt block_id, td::uint32 priority,
                                                          td::Timestamp timeout,
                                                          td::Promise<td::Ref<MessageQueue>> promise) {
  auto P = td::PromiseCreator::lambda(
      [SelfId = actor_id(this), timeout, promise = std::move(promise)](td::Result<BlockHandle> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
          return;
        }
        td::actor::send_closure(SelfId, &ValidatorManagerImpl::wait_block_message_queue, R.move_as_ok(), 0, timeout,
                                std::move(promise));
      });
  get_block_handle(block_id, true, std::move(P));
}

void ValidatorManagerImpl::get_external_messages(ShardIdFull shard, std::unique_ptr<ExtMsgCallback> callback) {
  if (callback) {
    auto task = [](std::vector<td::Ref<ExtMessage>> messages,
                   std::unique_ptr<ExtMsgCallback> callback) -> td::actor::Task<> {
      for (const auto &x : messages) {
        co_await callback->queue.try_push(std::make_pair(x, 0));
      }
      callback->queue.close();
      co_return td::Unit{};
    };
    task(ext_messages_, std::move(callback)).start().detach();
  }
}

void ValidatorManagerImpl::get_ihr_messages(ShardIdFull shard, td::Promise<std::vector<td::Ref<IhrMessage>>> promise) {
  promise.set_result(ihr_messages_);
}

void ValidatorManagerImpl::get_shard_blocks_for_collator(
    BlockIdExt masterchain_block_id, td::Promise<std::vector<td::Ref<ShardTopBlockDescription>>> promise) {
  if (!last_masterchain_block_handle_) {
    promise.set_result(std::vector<td::Ref<ShardTopBlockDescription>>{});
    return;
  }
  if (!shard_blocks_raw_.empty()) {
    for (auto &raw : shard_blocks_raw_) {
      new_shard_block_description_broadcast(BlockIdExt{}, 0, std::move(raw));
    }
    shard_blocks_raw_.clear();
  }
  if (!pending_new_shard_block_descr_) {
    promise.set_result(std::vector<td::Ref<ShardTopBlockDescription>>{shard_blocks_.begin(), shard_blocks_.end()});
  } else {
    // LOG(DEBUG) << "postponed get_shard_blocks query because pending_new_shard_block_descr_=" << pending_new_shard_block_descr_;
    waiting_new_shard_block_descr_.push_back(std::move(promise));
  }
}

void ValidatorManagerImpl::complete_external_messages(std::vector<ExtMessage::Hash> to_delay,
                                                      std::vector<ExtMessage::Hash> to_delete) {
}

void ValidatorManagerImpl::cleanup_applied_external_messages(BlockHandle handle, td::Ref<BlockData> block) {
}

void ValidatorManagerImpl::complete_ihr_messages(std::vector<IhrMessage::Hash> to_delay,
                                                 std::vector<IhrMessage::Hash> to_delete) {
}

void ValidatorManagerImpl::get_block_data_from_db(ConstBlockHandle handle, td::Promise<td::Ref<BlockData>> promise) {
  td::actor::send_closure(db_, &Db::get_block_data, handle, std::move(promise));
}

void ValidatorManagerImpl::get_block_data_from_db_short(BlockIdExt block_id, td::Promise<td::Ref<BlockData>> promise) {
  auto P =
      td::PromiseCreator::lambda([db = db_.get(), promise = std::move(promise)](td::Result<BlockHandle> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
        } else {
          auto handle = R.move_as_ok();
          td::actor::send_closure(db, &Db::get_block_data, std::move(handle), std::move(promise));
        }
      });
  get_block_handle(block_id, false, std::move(P));
}

void ValidatorManagerImpl::get_shard_state_from_db(ConstBlockHandle handle, td::Promise<td::Ref<ShardState>> promise) {
  td::actor::send_closure(db_, &Db::get_block_state, handle, std::move(promise));
}

void ValidatorManagerImpl::get_shard_state_from_db_short(BlockIdExt block_id,
                                                         td::Promise<td::Ref<ShardState>> promise) {
  auto P =
      td::PromiseCreator::lambda([db = db_.get(), promise = std::move(promise)](td::Result<BlockHandle> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
        } else {
          auto handle = R.move_as_ok();
          td::actor::send_closure(db, &Db::get_block_state, std::move(handle), std::move(promise));
        }
      });
  get_block_handle(block_id, false, std::move(P));
}

void ValidatorManagerImpl::get_block_candidate_from_db(PublicKey source, BlockIdExt id,
                                                       FileHash collated_data_file_hash,
                                                       td::Promise<BlockCandidate> promise) {
  td::actor::send_closure(db_, &Db::get_block_candidate, source, id, collated_data_file_hash, std::move(promise));
}

void ValidatorManagerImpl::get_candidate_data_by_block_id_from_db(BlockIdExt id, td::Promise<td::BufferSlice> promise) {
  td::actor::send_closure(db_, &Db::get_block_candidate_by_block_id, id,
                          promise.wrap([](BlockCandidate &&b) { return std::move(b.data); }));
}

void ValidatorManagerImpl::get_block_proof_from_db(ConstBlockHandle handle, td::Promise<td::Ref<Proof>> promise) {
  td::actor::send_closure(db_, &Db::get_block_proof, std::move(handle), std::move(promise));
}

void ValidatorManagerImpl::get_block_proof_from_db_short(BlockIdExt block_id, td::Promise<td::Ref<Proof>> promise) {
  auto P =
      td::PromiseCreator::lambda([db = db_.get(), promise = std::move(promise)](td::Result<BlockHandle> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
        } else {
          auto handle = R.move_as_ok();
          td::actor::send_closure(db, &Db::get_block_proof, std::move(handle), std::move(promise));
        }
      });
  get_block_handle(block_id, false, std::move(P));
}

void ValidatorManagerImpl::get_block_proof_link_from_db(ConstBlockHandle handle,
                                                        td::Promise<td::Ref<ProofLink>> promise) {
  td::actor::send_closure(db_, &Db::get_block_proof_link, std::move(handle), std::move(promise));
}

void ValidatorManagerImpl::get_block_proof_link_from_db_short(BlockIdExt block_id,
                                                              td::Promise<td::Ref<ProofLink>> promise) {
  auto P =
      td::PromiseCreator::lambda([db = db_.get(), promise = std::move(promise)](td::Result<BlockHandle> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
        } else {
          auto handle = R.move_as_ok();
          td::actor::send_closure(db, &Db::get_block_proof_link, std::move(handle), std::move(promise));
        }
      });
  get_block_handle(block_id, false, std::move(P));
}

void ValidatorManagerImpl::get_block_by_lt_from_db(AccountIdPrefixFull account, LogicalTime lt,
                                                   td::Promise<ConstBlockHandle> promise) {
  td::actor::send_closure(db_, &Db::get_block_by_lt, account, lt, std::move(promise));
}

void ValidatorManagerImpl::get_block_by_unix_time_from_db(AccountIdPrefixFull account, UnixTime ts,
                                                          td::Promise<ConstBlockHandle> promise) {
  td::actor::send_closure(db_, &Db::get_block_by_unix_time, account, ts, std::move(promise));
}

void ValidatorManagerImpl::get_block_by_seqno_from_db(AccountIdPrefixFull account, BlockSeqno seqno,
                                                      td::Promise<ConstBlockHandle> promise) {
  td::actor::send_closure(db_, &Db::get_block_by_seqno, account, seqno, std::move(promise));
}

void ValidatorManagerImpl::finished_wait_state(BlockIdExt block_id, td::Result<td::Ref<ShardState>> R) {
  auto it = wait_state_.find(block_id);
  if (it != wait_state_.end()) {
    if (R.is_error()) {
      auto S = R.move_as_error();
      for (auto &X : it->second.waiting_) {
        X.second.set_error(S.clone());
      }
    } else {
      auto r = R.move_as_ok();
      for (auto &X : it->second.waiting_) {
        X.second.set_result(r);
      }
    }
    wait_state_.erase(it);
  }
}

void ValidatorManagerImpl::finished_wait_data(BlockIdExt block_id, td::Result<td::Ref<BlockData>> R) {
  auto it = wait_block_data_.find(block_id);
  if (it != wait_block_data_.end()) {
    if (R.is_error()) {
      auto S = R.move_as_error();
      for (auto &X : it->second.waiting_) {
        X.second.set_error(S.clone());
      }
    } else {
      auto r = R.move_as_ok();
      for (auto &X : it->second.waiting_) {
        X.second.set_result(r);
      }
    }
    wait_block_data_.erase(it);
  }
}

// Phase B audit (Step 6): identical conclusion to the full validator
// manager (manager.cpp). set_block_state / store_block_state_part /
// set_block_state_from_data{,_bulk} on the disk-only variant are
// pure `send_closure` passthroughs to the Db actor — no
// `load_cell_slice` / `load_cell` is invoked on the
// `td::Ref<ShardState>` or `td::Ref<vm::Cell>` parameter at this
// layer. A hash-only `CellDbExtCell`-backed root therefore flows
// through these boundaries without forcing children to materialize.
void ValidatorManagerImpl::set_block_state(BlockHandle handle, td::Ref<ShardState> state, vm::StoreCellHint hint,
                                           td::Promise<td::Ref<ShardState>> promise) {
  td::actor::send_closure(db_, &Db::store_block_state, handle, state, std::move(hint), std::move(promise));
}

void ValidatorManagerImpl::store_block_state_part(BlockId effective_block, td::Ref<vm::Cell> cell,
                                                  td::Promise<td::Ref<vm::DataCell>> promise) {
  td::actor::send_closure(db_, &Db::store_block_state_part, effective_block, cell, std::move(promise));
}

void ValidatorManagerImpl::set_block_state_from_data(BlockHandle handle, td::Ref<BlockData> block,
                                                     td::Promise<td::Ref<ShardState>> promise) {
  td::actor::send_closure(db_, &Db::store_block_state_from_data, handle, block, std::move(promise));
}

void ValidatorManagerImpl::set_block_state_from_data_bulk(std::vector<td::Ref<BlockData>> blocks,
                                                          td::Promise<td::Unit> promise) {
  td::actor::send_closure(db_, &Db::store_block_state_from_data_bulk, std::move(blocks), std::move(promise));
}

void ValidatorManagerImpl::get_cell_db_reader(td::Promise<std::shared_ptr<vm::CellDbReader>> promise) {
  td::actor::send_closure(db_, &Db::get_cell_db_reader, std::move(promise));
}

void ValidatorManagerImpl::create_celldb_streaming_writer_unsafe_for_tests_only(
    td::Promise<std::unique_ptr<CellDbStreamingWriter>> promise) {
  // Test-only. Production state-sync uses
  // `import_persistent_state_streaming`. Cross-actor direct KV access
  // is unsafe; do not call from a production path (audit P1-5).
  //
  // Manager-disk variant: same routing chain as the full validator
  // manager (manager.cpp) — db_ is a RootDb actor and forwards into
  // CellDb -> CellDbIn::create_streaming_writer_unsafe_for_tests_only_async.
  // The disk-only variant runs the same persistent-state download
  // path during bootstrap, so the Phase B catch-up wiring is
  // identical.
  td::actor::send_closure(db_, &Db::create_celldb_streaming_writer_unsafe_for_tests_only, std::move(promise));
}

void ValidatorManagerImpl::import_persistent_state_streaming(
    PersistentStateImportRequest request, td::Promise<PersistentStateImportResult> promise) {
  // tos26 P1-4: actor-local persistent-state import. Mirror of the
  // full validator manager (manager.cpp): forward to the Db actor
  // (RootDb), which routes the request through CellDb to CellDbIn
  // where the entire begin_batch / parse / verify-root / commit
  // lifecycle runs inside the serialized actor loop.
  td::actor::send_closure(db_, &Db::import_persistent_state_streaming, std::move(request),
                          std::move(promise));
}

void ValidatorManagerImpl::store_persistent_state_file(BlockIdExt block_id, BlockIdExt masterchain_block_id,
                                                       PersistentStateType type, td::BufferSlice state,
                                                       td::Promise<td::Unit> promise) {
  td::actor::send_closure(db_, &Db::store_persistent_state_file, block_id, masterchain_block_id, type, std::move(state),
                          std::move(promise));
}

void ValidatorManagerImpl::store_persistent_state_file_gen(BlockIdExt block_id, BlockIdExt masterchain_block_id,
                                                           PersistentStateType type,
                                                           std::function<td::Status(td::FileFd &)> write_data,
                                                           td::Promise<td::Unit> promise) {
  td::actor::send_closure(db_, &Db::store_persistent_state_file_gen, block_id, masterchain_block_id, type,
                          std::move(write_data), std::move(promise));
}

void ValidatorManagerImpl::store_zero_state_file(BlockIdExt block_id, td::BufferSlice state,
                                                 td::Promise<td::Unit> promise) {
  td::actor::send_closure(db_, &Db::store_zero_state_file, block_id, std::move(state), std::move(promise));
}

void ValidatorManagerImpl::store_zero_state_file_gen(BlockIdExt block_id,
                                                     std::function<td::Status(td::FileFd &)> write_data,
                                                     td::Promise<td::Unit> promise) {
  td::actor::send_closure(db_, &Db::store_zero_state_file_gen, block_id, std::move(write_data), std::move(promise));
}

void ValidatorManagerImpl::set_block_data(BlockHandle handle, td::Ref<BlockData> data, td::Promise<td::Unit> promise) {
  auto P = td::PromiseCreator::lambda(
      [SelfId = actor_id(this), promise = std::move(promise), handle](td::Result<td::Unit> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
        } else {
          handle->set_received();
          handle->flush(SelfId, handle, std::move(promise));
        }
      });

  td::actor::send_closure(db_, &Db::store_block_data, handle, std::move(data), std::move(P));
}

void ValidatorManagerImpl::set_block_proof(BlockHandle handle, td::Ref<Proof> proof, td::Promise<td::Unit> promise) {
  auto P = td::PromiseCreator::lambda(
      [SelfId = actor_id(this), promise = std::move(promise), handle](td::Result<td::Unit> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
        } else {
          promise.set_value(td::Unit());
        }
      });

  td::actor::send_closure(db_, &Db::store_block_proof, handle, std::move(proof), std::move(P));
}

void ValidatorManagerImpl::set_block_proof_link(BlockHandle handle, td::Ref<ProofLink> proof,
                                                td::Promise<td::Unit> promise) {
  auto P = td::PromiseCreator::lambda(
      [SelfId = actor_id(this), handle, promise = std::move(promise)](td::Result<td::Unit> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
        } else {
          promise.set_value(td::Unit());
        }
      });
  td::actor::send_closure(db_, &Db::store_block_proof_link, handle, std::move(proof), std::move(P));
}

void ValidatorManagerImpl::set_block_signatures(BlockHandle handle, td::Ref<block::BlockSignatureSet> signatures,
                                                Ref<block::ValidatorSet> vset, td::Promise<td::Unit> promise) {
  auto P = td::PromiseCreator::lambda(
      [SelfId = actor_id(this), promise = std::move(promise), handle](td::Result<td::Unit> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
        } else {
          promise.set_value(td::Unit());
        }
      });

  td::actor::send_closure(db_, &Db::store_block_signatures, handle, std::move(signatures), std::move(vset),
                          std::move(P));
}

void ValidatorManagerImpl::set_next_block(BlockIdExt block_id, BlockIdExt next, td::Promise<td::Unit> promise) {
  auto P = td::PromiseCreator::lambda(
      [SelfId = actor_id(this), next, promise = std::move(promise)](td::Result<BlockHandle> R) mutable {
        if (R.is_error()) {
          promise.set_error(R.move_as_error());
        } else {
          auto handle = R.move_as_ok();
          handle->set_next(next);
          if (handle->need_flush()) {
            handle->flush(SelfId, handle, std::move(promise));
          } else {
            promise.set_value(td::Unit());
          }
        }
      });
  get_block_handle(block_id, true, std::move(P));
}

void ValidatorManagerImpl::set_block_candidate(BlockIdExt id, BlockCandidate candidate, CatchainSeqno cc_seqno,
                                               td::uint32 validator_set_hash, bool cache_only,
                                               td::Promise<td::Unit> promise) {
  if (cache_only) {
    promise.set_value(td::Unit{});
    return;
  }
  td::actor::send_closure(db_, &Db::store_block_candidate, std::move(candidate), std::move(promise));
}

void ValidatorManagerImpl::send_block_candidate_broadcast(BlockIdExt id, CatchainSeqno cc_seqno,
                                                          td::uint32 validator_set_hash, td::BufferSlice data,
                                                          int mode) {
  callback_->send_block_candidate(id, cc_seqno, validator_set_hash, std::move(data), mode);
}

void ValidatorManagerImpl::write_handle(BlockHandle handle, td::Promise<td::Unit> promise) {
  td::actor::send_closure(db_, &Db::store_block_handle, std::move(handle), std::move(promise));
}

void ValidatorManagerImpl::new_block_cont(BlockHandle handle, td::Ref<ShardState> state,
                                          td::Promise<td::Unit> promise) {
  handle->set_processed();
  if (state->get_shard().is_masterchain() && handle->id().id.seqno > last_masterchain_seqno_) {
    CHECK(handle->id().id.seqno == last_masterchain_seqno_ + 1);
    last_masterchain_seqno_ = handle->id().id.seqno;
    last_masterchain_state_ = td::Ref<MasterchainState>{state};
    last_masterchain_block_id_ = handle->id();
    last_masterchain_block_handle_ = handle;

    update_shards();
    update_shard_blocks();

    td::actor::send_closure(db_, &Db::update_init_masterchain_block, last_masterchain_block_id_, std::move(promise));
  } else {
    promise.set_value(td::Unit());
  }
}

void ValidatorManagerImpl::new_block(BlockHandle handle, td::Ref<ShardState> state, td::Promise<td::Unit> promise) {
  if (handle->is_applied()) {
    return new_block_cont(std::move(handle), std::move(state), std::move(promise));
  } else {
    auto P = td::PromiseCreator::lambda([SelfId = actor_id(this), handle, state = std::move(state),
                                         promise = std::move(promise)](td::Result<td::Unit> R) mutable {
      if (R.is_error()) {
        promise.set_error(R.move_as_error());
      } else {
        td::actor::send_closure(SelfId, &ValidatorManagerImpl::new_block_cont, std::move(handle), std::move(state),
                                std::move(promise));
      }
    });
    td::actor::send_closure(db_, &Db::archive, handle, std::move(P));
  }
}

void ValidatorManagerImpl::get_block_handle(BlockIdExt id, bool force, td::Promise<BlockHandle> promise) {
  auto handle = handles_.get(id);
  if (handle) {
    promise.set_value(std::move(handle));
    return;
  }
  auto P = td::PromiseCreator::lambda(
      [id, force, promise = std::move(promise), SelfId = actor_id(this)](td::Result<BlockHandle> R) mutable {
        BlockHandle handle;
        if (R.is_error()) {
          auto S = R.move_as_error();
          if (S.code() == ErrorCode::notready && force) {
            handle = create_empty_block_handle(id);
          } else {
            promise.set_error(std::move(S));
            return;
          }
        } else {
          handle = R.move_as_ok();
        }
        td::actor::send_closure(SelfId, &ValidatorManagerImpl::register_block_handle, std::move(handle),
                                std::move(promise));
      });

  td::actor::send_closure(db_, &Db::get_block_handle, id, std::move(P));
}

void ValidatorManagerImpl::register_block_handle(BlockHandle handle, td::Promise<BlockHandle> promise) {
  auto id = handle->id();
  auto registration = handles_.insert_or_get(id, std::move(handle));
  if (registration.inserted) {
    handles_.sweep_expired(handle_sweep_insert_budget_);
  }
  promise.set_value(std::move(registration.value));
}

void ValidatorManagerImpl::get_top_masterchain_state(td::Promise<td::Ref<MasterchainState>> promise) {
  promise.set_result(last_masterchain_state_);
}

void ValidatorManagerImpl::get_top_masterchain_block(td::Promise<BlockIdExt> promise) {
  promise.set_result(last_masterchain_block_id_);
}

void ValidatorManagerImpl::get_top_masterchain_state_block(
    td::Promise<std::pair<td::Ref<MasterchainState>, BlockIdExt>> promise) {
  promise.set_result(
      std::pair<td::Ref<MasterchainState>, BlockIdExt>{last_masterchain_state_, last_masterchain_block_id_});
}

void ValidatorManagerImpl::get_last_liteserver_state_block(
    td::Promise<std::pair<td::Ref<MasterchainState>, BlockIdExt>> promise) {
  return get_top_masterchain_state_block(std::move(promise));
}

void ValidatorManagerImpl::send_get_block_request(BlockIdExt id, td::uint32 priority,
                                                  td::Promise<ReceivedBlock> promise) {
  UNREACHABLE();
}

void ValidatorManagerImpl::send_get_zero_state_request(BlockIdExt id, td::uint32 priority,
                                                       td::Promise<fullnode::DownloadedPersistentState> promise) {
  UNREACHABLE();
}

void ValidatorManagerImpl::send_get_persistent_state_request(BlockIdExt id, BlockIdExt masterchain_block_id,
                                                             PersistentStateType type, td::uint32 priority,
                                                             td::Promise<fullnode::DownloadedPersistentState> promise) {
  UNREACHABLE();
}

void ValidatorManagerImpl::send_top_shard_block_description(td::Ref<ShardTopBlockDescription> desc) {
  callback_->send_shard_block_info(desc->block_id(), desc->catchain_seqno(), desc->serialize());
}

void ValidatorManagerImpl::start_up() {
  db_ = create_db_actor(actor_id(this), db_root_, opts_);

  auto P = td::PromiseCreator::lambda([SelfId = actor_id(this)](td::Result<ValidatorManagerInitResult> R) {
    R.ensure();
    td::actor::send_closure(SelfId, &ValidatorManagerImpl::started, R.move_as_ok());
  });

  validator_manager_init(opts_, actor_id(this), db_.get(), std::move(P));
}

void ValidatorManagerImpl::started(ValidatorManagerInitResult R) {
  LOG(DEBUG) << "started()";
  last_masterchain_block_handle_ = std::move(R.handle);
  last_masterchain_block_id_ = last_masterchain_block_handle_->id();
  last_masterchain_seqno_ = last_masterchain_block_id_.id.seqno;
  last_masterchain_state_ = std::move(R.state);

  //new_masterchain_block();

  callback_->initial_read_complete(last_masterchain_block_handle_);
}

void ValidatorManagerImpl::update_shards() {
}

void ValidatorManagerImpl::update_shard_blocks() {
  if (!last_masterchain_block_handle_) {
    return;
  }
  if (!shard_blocks_raw_.empty()) {
    for (auto &raw : shard_blocks_raw_) {
      new_shard_block_description_broadcast(BlockIdExt{}, 0, std::move(raw));
    }
    shard_blocks_raw_.clear();
  }
  {
    auto it = shard_blocks_.begin();
    while (it != shard_blocks_.end()) {
      auto &B = *it;
      if (!B->may_be_valid(last_masterchain_block_handle_, last_masterchain_state_)) {
        auto it2 = it++;
        shard_blocks_.erase(it2);
      } else {
        ++it;
      }
    }
  }
  {
    auto it = out_shard_blocks_.begin();
    while (it != out_shard_blocks_.end()) {
      auto &B = *it;
      if (!B->may_be_valid(last_masterchain_block_handle_, last_masterchain_state_)) {
        auto it2 = it++;
        out_shard_blocks_.erase(it2);
      } else {
        ++it;
      }
    }
  }
}

ValidatorSessionId ValidatorManagerImpl::get_validator_set_id(ShardIdFull shard, td::Ref<block::ValidatorSet> val_set) {
  return create_hash_tl_object<tos_api::tosNode_sessionId>(shard.workchain, shard.shard, val_set->get_catchain_seqno(),
                                                           td::Bits256::zero());
}

void ValidatorManagerImpl::update_shard_client_state(BlockIdExt masterchain_block_id, td::Promise<td::Unit> promise) {
  td::actor::send_closure(db_, &Db::update_shard_client_state, masterchain_block_id, std::move(promise));
}

void ValidatorManagerImpl::get_shard_client_state(bool from_db, td::Promise<BlockIdExt> promise) {
  td::actor::send_closure(db_, &Db::get_shard_client_state, std::move(promise));
}

void ValidatorManagerImpl::try_get_static_file(FileHash file_hash, td::Promise<td::BufferSlice> promise) {
  td::actor::send_closure(db_, &Db::try_get_static_file, file_hash, std::move(promise));
}

td::actor::ActorOwn<ValidatorManagerInterface> ValidatorManagerDiskFactory::create(
    PublicKeyHash id, td::Ref<ValidatorManagerOptions> opts, ShardIdFull shard, BlockIdExt shard_top_block_id,
    std::string db_root, td::Ref<vm::Cell> block_candidate, std::string export_candidate, std::string import_candidate,
    std::string query_result_path) {
  return td::actor::create_actor<validator::ValidatorManagerImpl>("manager", id, std::move(opts), shard,
                                                                  shard_top_block_id, db_root, std::move(block_candidate),
                                                                  std::move(export_candidate), std::move(import_candidate),
                                                                  std::move(query_result_path));
}

}  // namespace validator

}  // namespace tos
